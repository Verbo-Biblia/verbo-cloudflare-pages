"""La ventana que ve la congregación (proyector, TV o segunda pantalla)."""

from gi.repository import Gdk, GLib, Gtk

from . import NOMBRE
from .idioma import _
from .lienzo import Lienzo


def monitores():
    pantalla = Gdk.Display.get_default()
    lista = pantalla.get_monitors()
    return [lista.get_item(i) for i in range(lista.get_n_items())]


def nombre_monitor(monitor):
    geometria = monitor.get_geometry()
    descripcion = monitor.get_description() or monitor.get_model() or monitor.get_connector() or _("Pantalla")
    return f"{descripcion} ({geometria.width}×{geometria.height})"


def id_monitor(monitor):
    return monitor.get_connector() or monitor.get_description() or ""


# Cuando no hay otra pantalla, la proyección queda como ventana pequeña: nunca cubre la pantalla del operador.
TAMANO_PEQUENO = (640, 360)
# Conectores de la pantalla propia de una notebook: se prefiere el televisor o proyector (HDMI, DisplayPort…).
INTERNOS = ("eDP", "LVDS", "DSI")


def es_interno(monitor):
    return (monitor.get_connector() or "").startswith(INTERNOS)


class VentanaProyeccion(Gtk.Window):
    def __init__(self, aplicacion, escena, al_tecla):
        super().__init__(application=aplicacion, title=_("{app} — Proyección").format(app=NOMBRE))
        self.add_css_class("ventana-proyeccion")
        self.set_default_size(*TAMANO_PEQUENO)
        self.set_child(Lienzo(escena))
        self._al_tecla = al_tecla
        self._ocultar_id = 0

        teclas = Gtk.EventControllerKey()
        teclas.connect("key-pressed", self._tecla)
        self.add_controller(teclas)

        doble = Gtk.GestureClick()
        doble.connect("pressed", self._clic)
        self.add_controller(doble)

        movimiento = Gtk.EventControllerMotion()
        movimiento.connect("motion", self._movio_raton)
        self.add_controller(movimiento)
        self._movio_raton()

    def colocar(self, monitor):
        """Pantalla completa en el monitor indicado; sin monitor, ventana pequeña."""
        if monitor is not None:
            self.fullscreen_on_monitor(monitor)
        else:
            self.ventana_pequena()
        self.present()

    def ventana_pequena(self):
        self.set_default_size(*TAMANO_PEQUENO)
        if self.is_maximized():
            self.unmaximize()
        self.unfullscreen()

    def _tecla(self, _controlador, tecla, _codigo, estado):
        if tecla == Gdk.KEY_F11:
            self.unfullscreen() if self.is_fullscreen() else self.fullscreen()
            return True
        return self._al_tecla(tecla, estado)

    def _clic(self, _gesto, veces, _x, _y):
        if veces == 2:
            self.unfullscreen() if self.is_fullscreen() else self.fullscreen()

    def _movio_raton(self, *_):
        self.set_cursor(None)
        if self._ocultar_id:
            GLib.source_remove(self._ocultar_id)
        self._ocultar_id = GLib.timeout_add(1500, self._ocultar_cursor)

    def _ocultar_cursor(self):
        self._ocultar_id = 0
        self.set_cursor(Gdk.Cursor.new_from_name("none", None))
        return GLib.SOURCE_REMOVE

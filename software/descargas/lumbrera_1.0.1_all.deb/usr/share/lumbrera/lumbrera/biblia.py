"""Biblias locales (mismo formato que el proyector web) y lectura de citas."""

import json
import re
from dataclasses import dataclass
from functools import lru_cache

from . import rutas
from .cancion import Diapositiva, sin_acentos

# Nombres en portugués para reconocer citas aunque no haya Biblia en ese idioma.
NOMBRES_PT = [
    "Gênesis", "Êxodo", "Levítico", "Números", "Deuteronômio", "Josué", "Juízes", "Rute", "1 Samuel", "2 Samuel",
    "1 Reis", "2 Reis", "1 Crônicas", "2 Crônicas", "Esdras", "Neemias", "Ester", "Jó", "Salmos", "Provérbios",
    "Eclesiastes", "Cânticos", "Isaías", "Jeremias", "Lamentações", "Ezequiel", "Daniel", "Oseias", "Joel", "Amós",
    "Obadias", "Jonas", "Miqueias", "Naum", "Habacuque", "Sofonias", "Ageu", "Zacarias", "Malaquias", "Mateus",
    "Marcos", "Lucas", "João", "Atos", "Romanos", "1 Coríntios", "2 Coríntios", "Gálatas", "Efésios", "Filipenses",
    "Colossenses", "1 Tessalonicenses", "2 Tessalonicenses", "1 Timóteo", "2 Timóteo", "Tito", "Filemom", "Hebreus",
    "Tiago", "1 Pedro", "2 Pedro", "1 João", "2 João", "3 João", "Judas", "Apocalipse",
]
# Abreviaturas comunes que no salen solas del nombre completo.
ABREVIATURAS = {"sal": 19, "sl": 19, "ps": 19, "psa": 19, "pr": 20, "prov": 20, "cnt": 22, "cant": 22, "song": 22,
                "jn": 43, "jo": 43, "joh": 43, "mt": 40, "mr": 41, "mc": 41, "mk": 41, "lc": 42, "lk": 42,
                "hch": 44, "at": 44, "ac": 44, "ro": 45, "rm": 45, "ap": 66, "rev": 66, "jud": 65, "jds": 65,
                "flp": 50, "fil": 50, "php": 50, "flm": 57, "phm": 57, "stg": 59, "tg": 59, "sant": 59,
                "is": 23, "jr": 24, "ez": 26, "dn": 27, "os": 28, "jl": 29, "am": 30, "gn": 1, "ex": 2,
                "lv": 3, "nm": 4, "dt": 5, "jos": 6, "jue": 7, "jz": 7, "rt": 8, "job": 18, "jb": 18}


@dataclass
class Libro:
    numero: int
    id: str
    nombre: str
    archivo: str


@dataclass
class Version:
    id: str
    nombre: str
    abreviatura: str
    idioma: str
    licencia: str
    carpeta: object
    libros: list

    def libro(self, numero):
        return next((libro for libro in self.libros if libro.numero == numero), None)


def _cargar_version(carpeta):
    with open(carpeta / "manifest.json", encoding="utf-8") as archivo:
        datos = json.load(archivo)
    libros = [Libro(int(b["number"]), b.get("id", ""), b["name"], b["file"]) for b in datos.get("books", [])]
    return Version(datos.get("id") or carpeta.name, datos.get("name") or carpeta.name,
                   datos.get("abbreviation") or datos.get("name") or carpeta.name, datos.get("language", ""),
                   datos.get("license", ""), carpeta, libros)


@lru_cache(maxsize=1)
def versiones():
    encontradas = {}
    for base in (rutas.BIBLIAS, rutas.USUARIO_BIBLIAS):
        if not base.is_dir():
            continue
        for carpeta in sorted(base.iterdir()):
            if (carpeta / "manifest.json").is_file():
                try:
                    version = _cargar_version(carpeta)
                    encontradas[version.id] = version
                except (OSError, ValueError, KeyError):
                    continue
    orden = {"es": 0, "pt": 1, "en": 2}
    return sorted(encontradas.values(), key=lambda v: (orden.get(v.idioma, 3), v.nombre))


def version(identificador):
    return next((v for v in versiones() if v.id == identificador), None)


@lru_cache(maxsize=12)
def _capitulos(carpeta, archivo):
    with open(carpeta / archivo, encoding="utf-8") as f:
        return json.load(f).get("chapters", {})


# Las Biblias antiguas empiezan cada capítulo con la primera palabra en mayúsculas («EN el principio»),
# como en la Biblia impresa. En pantalla se ve raro, así que se corrige; «JEHOVÁ es…» no se toca.
_MAYUSCULA_INICIAL = re.compile(r"^([A-ZÁÉÍÓÚÑ])([A-ZÁÉÍÓÚÑ]{1,3})(?=[\s,;:.]+[a-záéíóúñ])")


def _texto(valor):
    texto = valor if isinstance(valor, str) else (valor.get("text", "") if isinstance(valor, dict) else "")
    return _MAYUSCULA_INICIAL.sub(lambda m: m.group(1) + m.group(2).lower(), texto)


def cantidad_capitulos(ver, numero_libro):
    libro = ver.libro(numero_libro)
    if not libro:
        return 0
    return max((int(c) for c in _capitulos(ver.carpeta, libro.archivo)), default=0)


def versiculos(ver, numero_libro, capitulo):
    """Lista de (número, texto) del capítulo."""
    libro = ver.libro(numero_libro)
    if not libro:
        return []
    capitulo_datos = _capitulos(ver.carpeta, libro.archivo).get(str(capitulo), {})
    return sorted(((int(n), _texto(v)) for n, v in capitulo_datos.items()), key=lambda par: par[0])


def diapositivas_capitulo(ver_a, ver_b, numero_libro, capitulo, desde=None, hasta=None):
    """Una diapositiva por versículo. Con dos versiones, la segunda va debajo."""
    principal = dict(versiculos(ver_a, numero_libro, capitulo))
    segunda = dict(versiculos(ver_b, numero_libro, capitulo)) if ver_b else {}
    libro_a = ver_a.libro(numero_libro)
    nombre = libro_a.nombre if libro_a else ""
    siglas = ver_a.abreviatura + (f" · {ver_b.abreviatura}" if ver_b else "")
    resultado = []
    for numero in sorted(set(principal) | set(segunda)):
        if (desde and numero < desde) or (hasta and numero > hasta):
            continue
        resultado.append(Diapositiva(f"v. {numero}", principal.get(numero, ""), segunda.get(numero, "") if ver_b else "",
                                     f"{nombre} {capitulo}:{numero} · {siglas}"))
    return resultado


# ------------------------------------------------------------- citas

def rangos(numeros):
    """[16, 17, 18, 20] → «16-18, 20»."""
    partes = []
    for numero in sorted(set(numeros)):
        if partes and numero == partes[-1][1] + 1:
            partes[-1][1] = numero
        else:
            partes.append([numero, numero])
    return ", ".join(str(a) if a == b else f"{a}-{b}" for a, b in partes)


def _clave(nombre):
    return re.sub(r"[^a-z0-9]", "", sin_acentos(nombre))


@lru_cache(maxsize=1)
def _indice_nombres():
    indice = {}
    for ver in versiones():
        for libro in ver.libros:
            indice.setdefault(_clave(libro.nombre), libro.numero)
            indice.setdefault(_clave(libro.id), libro.numero)
    for numero, nombre in enumerate(NOMBRES_PT, start=1):
        indice.setdefault(_clave(nombre), numero)
    return indice


def _buscar_libro(texto):
    clave = _clave(texto)
    if not clave:
        return None
    if clave in ABREVIATURAS:
        return ABREVIATURAS[clave]
    indice = _indice_nombres()
    if clave in indice:
        return indice[clave]
    prefijos = sorted((len(nombre), numero) for nombre, numero in indice.items() if nombre.startswith(clave))
    if prefijos:
        return prefijos[0][1]
    # Letras en orden («1cor», «flp»): mismo inicio y el resto aparece en orden.
    patron = re.compile(".*".join(map(re.escape, clave)))
    candidatos = sorted((len(nombre), numero) for nombre, numero in indice.items()
                        if nombre[0] == clave[0] and patron.match(nombre))
    return candidatos[0][1] if candidatos else None


_CITA = re.compile(r"^\s*(?P<libro>(?:[1-3]\s*)?[^\d]+?)\.?\s*(?P<cap>\d+)?(?:\s*[:.,\s]\s*(?P<v1>\d+)"
                   r"(?:\s*[-–]\s*(?P<v2>\d+))?)?\s*$")


def leer_cita(texto):
    """«Juan 3:16-18» → (43, 3, 16, 18). Devuelve None si no se entiende."""
    coincidencia = _CITA.match(texto or "")
    if not coincidencia:
        return None
    libro = _buscar_libro(coincidencia.group("libro"))
    if not libro:
        return None
    capitulo = int(coincidencia.group("cap") or 1)
    v1 = int(coincidencia.group("v1")) if coincidencia.group("v1") else None
    v2 = int(coincidencia.group("v2")) if coincidencia.group("v2") else v1
    return libro, capitulo, v1, v2

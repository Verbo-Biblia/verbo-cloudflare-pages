"""Columna izquierda, pestaña Canciones: buscar en tus canciones o en internet."""

from gi.repository import Adw, Gdk, GObject, Gtk

from .idioma import _


def boton_icono(icono, ayuda, al_pulsar, *clases):
    boton = Gtk.Button(icon_name=icono, tooltip_text=ayuda, valign=Gtk.Align.CENTER)
    boton.add_css_class("flat")
    for clase in clases:
        boton.add_css_class(clase)
    boton.connect("clicked", lambda *_: al_pulsar())
    return boton


class PanelCanciones(Gtk.Box):
    __gsignals__ = {
        "abrir": (GObject.SignalFlags.RUN_FIRST, None, (object,)),
        "agregar": (GObject.SignalFlags.RUN_FIRST, None, (object,)),
        "editar": (GObject.SignalFlags.RUN_FIRST, None, (object,)),
        "buscar-web": (GObject.SignalFlags.RUN_FIRST, None, (str,)),
    }

    def __init__(self, biblioteca):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.biblioteca = biblioteca
        self.set_margin_start(10)
        self.set_margin_end(10)
        self.set_margin_bottom(10)

        fila = Gtk.Box(spacing=6)
        self.buscador = Gtk.SearchEntry(placeholder_text=_("Buscar canción…"), hexpand=True)
        self.buscador.connect("search-changed", lambda *_: self.actualizar())
        self.buscador.connect("activate", self._al_enter)
        fila.append(self.buscador)
        self.append(fila)

        self.lista = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self.lista.add_css_class("navigation-sidebar")
        self.lista.connect("row-activated", self._fila_activada)
        desplazable = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        desplazable.set_child(self.lista)

        self.vacio = Adw.StatusPage(icon_name="eb-musica-symbolic", title=_("Aún no tienes canciones"),
                                    description=_("Escribe el nombre de una canción arriba para buscarla en "
                                                  "internet. Para escribir o editar canciones abre "
                                                  "Configuración › Cancionero."))
        self.vacio.add_css_class("compact")

        self.pila = Gtk.Stack()
        self.pila.add_named(desplazable, "lista")
        self.pila.add_named(self.vacio, "vacio")
        self.append(self.pila)

        biblioteca.al_cambiar(self.actualizar)
        self.actualizar()

    def _al_enter(self, *_):
        primera = self.lista.get_row_at_index(0)
        if primera is not None:
            self._fila_activada(self.lista, primera)

    def _fila_activada(self, _lista, fila):
        if getattr(fila, "cancion", None) is not None:
            self.emit("abrir", fila.cancion)
        elif getattr(fila, "consulta_web", None):
            self.emit("buscar-web", fila.consulta_web)

    def actualizar(self):
        consulta = self.buscador.get_text().strip()
        self.lista.remove_all()
        canciones = self.biblioteca.buscar(consulta)
        for cancion in canciones:
            self.lista.append(self._fila_cancion(cancion))
        if consulta:
            self.lista.append(self._fila_web(consulta))
        hay_algo = bool(canciones) or bool(consulta)
        self.pila.set_visible_child_name("lista" if hay_algo else "vacio")

    def _fila_cancion(self, cancion):
        fila = Gtk.ListBoxRow()
        fila.cancion = cancion
        caja = Gtk.Box(spacing=6)
        textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True, valign=Gtk.Align.CENTER)
        titulo = Gtk.Label(label=cancion.titulo, xalign=0, ellipsize=3)
        titulo.add_css_class("heading")
        textos.append(titulo)
        if cancion.autor:
            autor = Gtk.Label(label=cancion.autor, xalign=0, ellipsize=3)
            autor.add_css_class("dim-label")
            autor.add_css_class("caption")
            textos.append(autor)
        caja.append(textos)
        caja.append(boton_icono("list-add-symbolic", _("Agregar al orden del culto"),
                                lambda: self.emit("agregar", cancion)))
        fila.set_child(caja)
        # Se puede arrastrar al orden del culto.
        fuente = Gtk.DragSource(actions=Gdk.DragAction.COPY)
        fuente.connect("prepare", lambda *_: Gdk.ContentProvider.new_for_value(f"lumbrera:cancion:{cancion.id}"))
        fuente.connect("drag-begin", lambda f, _a: f.set_icon(Gtk.WidgetPaintable.new(titulo), 0, 0))
        fila.add_controller(fuente)
        return fila

    def _fila_web(self, consulta):
        fila = Gtk.ListBoxRow()
        fila.consulta_web = consulta
        caja = Gtk.Box(spacing=10)
        caja.append(Gtk.Image(icon_name="system-search-symbolic"))
        textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True)
        titulo = Gtk.Label(label=_("Buscar en internet"), xalign=0)
        titulo.add_css_class("heading")
        textos.append(titulo)
        detalle = Gtk.Label(label=f"«{consulta}»", xalign=0, ellipsize=3)
        detalle.add_css_class("caption")
        textos.append(detalle)
        caja.append(textos)
        fila.set_child(caja)
        fila.add_css_class("fila-web")
        return fila

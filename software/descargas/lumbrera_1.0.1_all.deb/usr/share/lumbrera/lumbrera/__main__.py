import sys


def _importar_para_todos(archivos):
    from . import idioma, rutas
    from .importar import importar_para_todos
    idioma.iniciar(None)
    if not archivos:
        print("Uso: sudo lumbrera --importar-para-todos ARCHIVO…", file=sys.stderr)
        return 2
    for archivo in archivos:
        try:
            cantidad, total = importar_para_todos(archivo)
        except PermissionError:
            print(f"Sin permiso para escribir {rutas.COMPARTIDAS}: hay que usar sudo.", file=sys.stderr)
            return 1
        print(f"{archivo}: {cantidad} canciones. Cancionero de todos los usuarios: {total} canciones "
              f"({rutas.COMPARTIDAS}).")
    return 0


if len(sys.argv) > 1 and sys.argv[1] == "--importar-para-todos":
    sys.exit(_importar_para_todos(sys.argv[2:]))

from .app import main  # noqa: E402

sys.exit(main())

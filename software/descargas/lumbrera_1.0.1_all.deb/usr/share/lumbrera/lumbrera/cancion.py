"""Canciones y pantallas (diapositivas).

La letra se guarda como un solo texto. Una línea en blanco separa cada
parte. Si la primera línea de una parte es un nombre como «Coro»,
«Puente» o «Estrofa 2», se usa como etiqueta y no se proyecta. Una parte
que solo dice «Coro» repite el último coro escrito.
"""

import math
import re
import time
import unicodedata
import uuid
from dataclasses import dataclass, field

from .idioma import _

_NOMBRES = (
    r"coro|estribillo|chorus|refr[aã]o|refrain|puente|bridge|ponte|estrofa|estrofe|verso|verse|"
    r"pre[- ]?coro|pre[- ]?chorus|pr[ée][- ]?refr[aã]o|intro|introducci[oó]n|introdu[cç][aã]o|"
    r"final|ending|outro|tag|coda|interludio|interl[uú]dio|interlude|vamp"
)
_ETIQUETA = re.compile(
    rf"^\s*[\[(]?\s*(?P<nombre>{_NOMBRES})(?P<resto>(?:[\s\d.:×xX()#-]|final)*)[\])]?\s*:?\s*$",
    re.IGNORECASE,
)


def sin_acentos(texto):
    descompuesto = unicodedata.normalize("NFD", str(texto or ""))
    return "".join(c for c in descompuesto if unicodedata.category(c) != "Mn").lower()


@dataclass
class Diapositiva:
    etiqueta: str
    texto: str
    texto2: str = ""
    referencia: str = ""

    def a_dict(self):
        return {"etiqueta": self.etiqueta, "texto": self.texto, "texto2": self.texto2,
                "referencia": self.referencia}

    @classmethod
    def desde_dict(cls, datos):
        return cls(str(datos.get("etiqueta", "")), str(datos.get("texto", "")),
                   str(datos.get("texto2", "")), str(datos.get("referencia", "")))


@dataclass
class Parte:
    etiqueta: str | None
    texto: str


def es_etiqueta(linea):
    return _ETIQUETA.match(linea or "") is not None


def _limpiar_etiqueta(linea):
    texto = linea.strip().strip("[]():").strip()
    return texto[:1].upper() + texto[1:]


def _clave_etiqueta(etiqueta):
    coincidencia = _ETIQUETA.match(etiqueta or "")
    return sin_acentos(coincidencia.group("nombre")) if coincidencia else sin_acentos(etiqueta)


def partes(letra):
    bloques = re.split(r"\n\s*\n+", str(letra or "").replace("\r\n", "\n").replace("\r", "\n").strip())
    resultado = []
    ultimas = {}
    for bloque in bloques:
        lineas = [linea.rstrip() for linea in bloque.strip("\n").split("\n")]
        lineas = [linea for linea in lineas if linea.strip()]
        if not lineas:
            continue
        etiqueta = None
        if es_etiqueta(lineas[0]):
            etiqueta = _limpiar_etiqueta(lineas[0])
            lineas = lineas[1:]
        texto = "\n".join(linea.strip() for linea in lineas)
        if etiqueta and not texto:
            texto = ultimas.get(_clave_etiqueta(etiqueta), "")
            if not texto:
                continue
        if etiqueta:
            ultimas[_clave_etiqueta(etiqueta)] = texto
        resultado.append(Parte(etiqueta, texto))
    return resultado


def _repartir(lineas, maximo):
    if maximo <= 0 or len(lineas) <= maximo:
        return [lineas]
    cantidad = math.ceil(len(lineas) / maximo)
    tam = math.ceil(len(lineas) / cantidad)
    return [lineas[i:i + tam] for i in range(0, len(lineas), tam)]


def diapositivas(letra, max_lineas=0):
    resultado = []
    numero = 0
    lista = partes(letra)
    # La parte sin nombre que más se repite es el coro. Si empatan, la que aparece después
    # (las canciones casi siempre empiezan con una estrofa).
    sin_nombre = [p.texto for p in lista if not p.etiqueta]
    veces = {texto: sin_nombre.count(texto) for texto in sin_nombre}
    candidatas = [texto for texto, n in veces.items() if n > 1]
    coro = max(candidatas, key=lambda texto: (veces[texto], sin_nombre.index(texto)), default=None)
    repetidas = {coro} if coro else set()
    for parte in lista:
        if parte.etiqueta:
            etiqueta = parte.etiqueta
        elif parte.texto in repetidas:
            etiqueta = _("Coro")
        else:
            numero += 1
            etiqueta = _("Estrofa {n}").format(n=numero)
        trozos = _repartir(parte.texto.split("\n"), max_lineas)
        for i, trozo in enumerate(trozos):
            nombre = etiqueta if len(trozos) == 1 else f"{etiqueta} ({i + 1}/{len(trozos)})"
            resultado.append(Diapositiva(nombre, "\n".join(trozo)))
    return resultado


@dataclass
class Cancion:
    titulo: str
    autor: str = ""
    letra: str = ""
    id: str = field(default_factory=lambda: f"c-{uuid.uuid4().hex[:12]}")
    creada: float = field(default_factory=time.time)
    modificada: float = field(default_factory=time.time)

    def diapositivas(self, max_lineas=0):
        return diapositivas(self.letra, max_lineas)

    def a_dict(self):
        return {"id": self.id, "titulo": self.titulo, "autor": self.autor, "letra": self.letra,
                "creada": self.creada, "modificada": self.modificada}

    @classmethod
    def desde_dict(cls, datos):
        """Acepta el formato propio y el respaldo del proyector web (estrofas + coro)."""
        letra = datos.get("letra")
        if not isinstance(letra, str):
            estrofas = [str(e).strip() for e in datos.get("estrofas") or [] if str(e).strip()]
            coro = str(datos.get("coro") or "").strip()
            bloques = []
            for i, estrofa in enumerate(estrofas):
                bloques.append(estrofa)
                if coro:
                    bloques.append(f"{_('Coro')}\n{coro}" if i == 0 else _("Coro"))
            letra = "\n\n".join(bloques)
        ahora = time.time()
        return cls(
            titulo=str(datos.get("titulo") or "").strip() or _("Sin título"),
            autor=str(datos.get("autor") or "").strip(),
            letra=letra,
            id=str(datos.get("id") or f"c-{uuid.uuid4().hex[:12]}"),
            creada=float(datos.get("creada") or ahora),
            modificada=float(datos.get("modificada") or ahora),
        )

    def a_respaldo_web(self):
        return {"id": self.id, "titulo": self.titulo, "autor": self.autor or "-", "coro": "",
                "estrofas": [d.texto for d in self.diapositivas()] or [self.titulo]}

"""El orden del culto: la lista de lo que se va a proyectar, en orden."""

import uuid
from pathlib import Path

from gi.repository import Adw, Gdk, Gio, GLib, GObject, Gtk

from . import almacen, rutas
from .cancion import Cancion, Diapositiva
from .idioma import _
from .panel_canciones import boton_icono

ICONOS = {"cancion": "eb-musica-symbolic", "pasaje": "eb-biblia-symbolic",
          "imagen": "eb-imagen-symbolic", "video": "eb-video-symbolic",
          "audio": "eb-audio-symbolic"}
EXTENSIONES = {
    "imagen": ("*.png", "*.jpg", "*.jpeg", "*.webp", "*.gif", "*.bmp", "*.svg"),
    "video": ("*.mp4", "*.webm", "*.mkv", "*.mov", "*.avi", "*.m4v", "*.ogv"),
    "audio": ("*.mp3", "*.ogg", "*.oga", "*.wav", "*.flac", "*.m4a", "*.opus", "*.aac"),
}


def tipo_de_archivo(ruta):
    extension = "*" + Path(ruta).suffix.lower()
    return next((tipo for tipo, extensiones in EXTENSIONES.items() if extension in extensiones), None)


class PanelOrden(Gtk.Box):
    __gsignals__ = {"elegir": (GObject.SignalFlags.RUN_FIRST, None, (int,))}

    def __init__(self, biblioteca, ventana):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.biblioteca = biblioteca
        self.ventana = ventana
        datos = almacen.leer_json(rutas.ORDEN, {})
        datos = datos if isinstance(datos, dict) else {}
        self.elementos = datos.get("elementos", [])
        self.nombre = datos.get("nombre", "")  # nombre del culto guardado (vacío si no se ha guardado)
        self.ruta = datos.get("ruta", "")  # archivo donde se guardó por última vez
        self.actual = -1

        cabecera = Gtk.Box(spacing=6, margin_start=4)
        textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True, valign=Gtk.Align.CENTER)
        titulo = Gtk.Label(label=_("Orden del culto"), xalign=0)
        titulo.add_css_class("heading")
        textos.append(titulo)
        self.etiqueta_nombre = Gtk.Label(xalign=0, ellipsize=3)
        self.etiqueta_nombre.add_css_class("caption")
        self.etiqueta_nombre.add_css_class("dim-label")
        textos.append(self.etiqueta_nombre)
        cabecera.append(textos)
        self.cuenta = Gtk.Label()
        self.cuenta.add_css_class("dim-label")
        self.cuenta.add_css_class("caption")
        cabecera.append(self.cuenta)

        guardar = Gtk.Button(action_name="win.culto-guardar", tooltip_text=_("Guardar el culto (Ctrl + S)"))
        guardar.set_child(Adw.ButtonContent(icon_name="document-save-symbolic", label=_("Guardar")))
        guardar.add_css_class("flat")
        cabecera.append(guardar)
        menu = Gio.Menu()
        seccion = Gio.Menu()
        seccion.append(_("Nuevo culto"), "win.culto-nuevo")
        seccion.append(_("Abrir culto…"), "win.culto-abrir")
        seccion.append(_("Guardar"), "win.culto-guardar")
        seccion.append(_("Guardar como…"), "win.culto-guardar-como")
        menu.append_section(None, seccion)
        seccion = Gio.Menu()
        seccion.append(_("Agregar imagen, video o audio…"), "win.orden-agregar-archivo")
        menu.append_section(None, seccion)
        cabecera.append(Gtk.MenuButton(icon_name="view-more-symbolic", menu_model=menu, css_classes=["flat"],
                                       tooltip_text=_("Más opciones")))
        self.append(cabecera)

        self.lista = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, valign=Gtk.Align.START)
        self.lista.add_css_class("boxed-list")
        self.lista.add_css_class("lista-orden")
        self.lista.connect("row-activated", lambda _l, fila: self.emit("elegir", fila.get_index()))
        self.vacio = Gtk.Label(label=_("Arrastra aquí canciones, versículos, imágenes, videos o audios, o usa los "
                                       "botones +."),
                               wrap=True, justify=Gtk.Justification.CENTER, margin_top=18, margin_bottom=18,
                               margin_start=12, margin_end=12)
        self.vacio.add_css_class("dim-label")
        self.vacio.set_valign(Gtk.Align.START)
        desplazable = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        desplazable.set_child(self.lista)
        self.pila = Gtk.Stack(vexpand=True)
        self.pila.add_named(desplazable, "lista")
        self.pila.add_named(self.vacio, "vacio")
        self.append(self.pila)

        # Se puede soltar aquí: versículos marcados, canciones de la lista y archivos del computador.
        self.al_soltar_texto = None  # función(texto) → bool, la pone la ventana
        destino = Gtk.DropTarget.new(GObject.TYPE_NONE, Gdk.DragAction.COPY)
        destino.set_gtypes([Gdk.FileList.__gtype__, GObject.TYPE_STRING])
        destino.connect("drop", self._soltar)
        destino.connect("enter", lambda *_: self.add_css_class("soltando") or Gdk.DragAction.COPY)
        destino.connect("leave", lambda *_: self.remove_css_class("soltando"))
        self.add_controller(destino)
        self.actualizar()

    # ------------------------------------------------------------ datos

    def _guardar(self):
        """Copia automática: el orden se recupera aunque el programa se cierre."""
        almacen.escribir_json(rutas.ORDEN, {"version": 1, "nombre": self.nombre, "ruta": self.ruta,
                                            "elementos": self.elementos})

    # ------------------------------------------------------------ guardar y abrir cultos

    def guardar_en(self, ruta, nombre):
        """Guarda el culto en un archivo .lumbrera, con la letra de cada canción para abrirlo en otro equipo."""
        elementos = []
        for elemento in self.elementos:
            copia = dict(elemento)
            if copia["tipo"] == "cancion":
                cancion = self.biblioteca.obtener(copia.get("cancion"))
                if cancion:
                    copia["copia"] = cancion.a_dict()
            elementos.append(copia)
        almacen.escribir_json(Path(ruta), {"programa": "Lumbrera", "tipo": "culto", "version": 1, "nombre": nombre,
                                           "elementos": elementos})
        self.ruta, self.nombre = str(ruta), nombre
        self._guardar()
        self.actualizar()

    def abrir(self, ruta):
        datos = almacen.leer_json(Path(ruta), None)
        if not isinstance(datos, dict) or not isinstance(datos.get("elementos"), list):
            raise ValueError("no es un culto de Lumbrera")
        self.elementos = [e for e in datos["elementos"] if isinstance(e, dict) and e.get("tipo")]
        self.nombre = datos.get("nombre") or Path(ruta).stem
        self.ruta = str(ruta)
        self.actual = -1
        self._guardar()
        self.actualizar()

    def nuevo(self):
        self.elementos, self.nombre, self.ruta, self.actual = [], "", "", -1
        self._guardar()
        self.actualizar()

    def agregar_cancion(self, cancion):
        self._agregar({"tipo": "cancion", "cancion": cancion.id, "titulo": cancion.titulo, "subtitulo": cancion.autor})

    def agregar_pasaje(self, titulo, diapositivas):
        subtitulo = diapositivas[0].referencia.split(" · ", 1)[-1] if diapositivas else ""
        self._agregar({"tipo": "pasaje", "titulo": titulo, "subtitulo": subtitulo,
                       "diapositivas": [d.a_dict() for d in diapositivas]})

    def agregar_archivo(self, ruta):
        tipo = tipo_de_archivo(ruta)
        if not tipo:
            return False
        self._agregar({"tipo": tipo, "ruta": str(ruta), "titulo": Path(ruta).name,
                       "subtitulo": {"imagen": _("Imagen"), "video": _("Video"), "audio": _("Audio")}[tipo]})
        return True

    def _agregar(self, elemento):
        elemento["id"] = uuid.uuid4().hex[:10]
        self.elementos.append(elemento)
        self._guardar()
        self.actualizar()

    def diapositivas(self, indice, max_lineas=0):
        elemento = self.elementos[indice]
        if elemento["tipo"] == "cancion":
            cancion = self.biblioteca.obtener(elemento.get("cancion"))
            if cancion is None and isinstance(elemento.get("copia"), dict):
                cancion = Cancion.desde_dict(elemento["copia"])  # culto abierto en otro equipo
            return cancion.diapositivas(max_lineas) if cancion else []
        if elemento["tipo"] == "pasaje":
            return [Diapositiva.desde_dict(d) for d in elemento.get("diapositivas", [])]
        return []

    def mover(self, indice, cambio):
        destino = indice + cambio
        if not 0 <= destino < len(self.elementos):
            return
        self.elementos[indice], self.elementos[destino] = self.elementos[destino], self.elementos[indice]
        if self.actual in (indice, destino):
            self.actual = destino if self.actual == indice else indice
        self._guardar()
        self.actualizar()

    def quitar(self, indice):
        del self.elementos[indice]
        if self.actual == indice:
            self.actual = -1
        elif self.actual > indice:
            self.actual -= 1
        self._guardar()
        self.actualizar()

    def vaciar(self):
        self.elementos = []
        self.actual = -1
        self._guardar()
        self.actualizar()

    def marcar_actual(self, indice):
        self.actual = indice
        self.actualizar()

    # ------------------------------------------------------------ vista

    def actualizar(self):
        self.lista.remove_all()
        cantidad = len(self.elementos)
        self.cuenta.set_label(_("1 elemento") if cantidad == 1 else _("{n} elementos").format(n=cantidad))
        self.etiqueta_nombre.set_label(self.nombre or _("Sin guardar"))
        for i, elemento in enumerate(self.elementos):
            self.lista.append(self._fila(i, elemento))
        self.pila.set_visible_child_name("lista" if self.elementos else "vacio")

    def _fila(self, indice, elemento):
        fila = Adw.ActionRow(title=GLib.markup_escape_text(elemento.get("titulo", "")),
                             subtitle=GLib.markup_escape_text(elemento.get("subtitulo", "")), activatable=True)
        fila.set_title_lines(1)
        fila.set_subtitle_lines(1)
        icono = Gtk.Image(icon_name=ICONOS.get(elemento["tipo"], "eb-texto-symbolic"))
        fila.add_prefix(icono)
        if (elemento["tipo"] == "cancion" and not self.biblioteca.obtener(elemento.get("cancion"))
                and not elemento.get("copia")):
            fila.set_subtitle(_("Esta canción ya no está en tu lista"))
        if indice == self.actual:
            fila.add_css_class("orden-actual")
        controles = Gtk.Box(spacing=0, valign=Gtk.Align.CENTER)
        controles.add_css_class("controles-orden")
        controles.append(boton_icono("go-up-symbolic", _("Subir"), lambda: self.mover(indice, -1)))
        controles.append(boton_icono("go-down-symbolic", _("Bajar"), lambda: self.mover(indice, 1)))
        controles.append(boton_icono("window-close-symbolic", _("Quitar del orden"), lambda: self.quitar(indice)))
        fila.add_suffix(controles)
        return fila

    def _soltar(self, _destino, valor, _x, _y):
        self.remove_css_class("soltando")
        if isinstance(valor, str):
            return bool(self.al_soltar_texto and self.al_soltar_texto(valor))
        agregados = 0
        for archivo in valor.get_files():
            if archivo.get_path() and self.agregar_archivo(archivo.get_path()):
                agregados += 1
        return agregados > 0


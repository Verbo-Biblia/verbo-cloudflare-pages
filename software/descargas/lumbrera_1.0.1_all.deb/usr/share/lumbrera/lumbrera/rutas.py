"""Dónde vive cada cosa: datos que trae el programa y datos del usuario."""

import os
from pathlib import Path

PAQUETE = Path(__file__).resolve().parent

# Instalado: /usr/share/lumbrera/{lumbrera,datos}. En desarrollo: la carpeta del proyecto.
DATOS = PAQUETE.parent / "datos"
BIBLIAS = DATOS / "biblias"
IDIOMAS = DATOS / "idiomas"
ICONOS = DATOS / "iconos"


def _xdg(variable, defecto):
    valor = os.environ.get(variable)
    return Path(valor) if valor else Path.home() / defecto


USUARIO_DATOS = _xdg("XDG_DATA_HOME", ".local/share") / "lumbrera"
USUARIO_CONFIG = _xdg("XDG_CONFIG_HOME", ".config") / "lumbrera"
USUARIO_BIBLIAS = USUARIO_DATOS / "biblias"
CANCIONES = USUARIO_DATOS / "canciones.json"
ORDEN = USUARIO_DATOS / "orden-del-culto.json"
AJUSTES = USUARIO_CONFIG / "ajustes.json"
# Cancionero para todos los usuarios del equipo. Lo llena el administrador con «sudo lumbrera
# --importar-para-todos ARCHIVO»; cada usuario lo ve junto a sus propias canciones, sin poder cambiarlo.
COMPARTIDAS = Path(os.environ.get("LUMBRERA_COMPARTIDAS") or "/usr/local/share/lumbrera/canciones.json")


def preparar():
    USUARIO_DATOS.mkdir(parents=True, exist_ok=True)
    USUARIO_CONFIG.mkdir(parents=True, exist_ok=True)

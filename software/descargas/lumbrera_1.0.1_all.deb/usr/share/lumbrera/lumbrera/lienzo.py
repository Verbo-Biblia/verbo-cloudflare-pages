"""Dibuja la escena: fondo, texto con sombra y multimedia. Sirve para la proyección y la vista previa."""

import cairo
from gi.repository import GLib, Graphene, Gsk, Gtk, Pango, PangoCairo

from .escena import color_rgb

DURACION_TRANSICION = 0.35  # segundos


class Lienzo(Gtk.Overlay):
    def __init__(self, escena):
        super().__init__()
        self.escena = escena
        self.set_overflow(Gtk.Overflow.HIDDEN)
        self.add_css_class("lienzo")

        self._base = Gtk.DrawingArea()
        self._base.set_draw_func(self._dibujar_base)
        self.set_child(self._base)

        self._fondo = Gtk.Picture(can_shrink=True, content_fit=Gtk.ContentFit.COVER)
        self._fondo.set_can_target(False)
        self.add_overlay(self._fondo)

        self._texto = Gtk.DrawingArea()
        self._texto.set_can_target(False)
        self._texto.set_draw_func(self._dibujar_texto)
        self.add_overlay(self._texto)

        self._medio = Gtk.Picture(can_shrink=True, content_fit=Gtk.ContentFit.CONTAIN)
        self._medio.set_can_target(False)
        self._medio.add_css_class("lienzo-medio")
        self.add_overlay(self._medio)

        self._anterior = None  # (diapositiva, modo) que se desvanece
        self._progreso = 1.0
        self._inicio = 0
        self._tic = None
        self._id_senal = escena.connect("cambio", self._al_cambiar)
        self.connect("destroy", lambda *_: escena.disconnect(self._id_senal))
        self._actualizar_imagenes()

    # ------------------------------------------------------------ cambios

    def _al_cambiar(self, _escena, que):
        if que == "contenido" and self.escena.estilo["transicion"] and self.get_mapped():
            self._anterior = self._visible_ahora
            self._progreso = 0.0
            self._inicio = 0
            if self._tic is None:
                self._tic = self.add_tick_callback(self._avanzar)
        self._actualizar_imagenes()
        self._base.queue_draw()
        self._texto.queue_draw()

    def _avanzar(self, _widget, reloj):
        ahora = reloj.get_frame_time()
        if not self._inicio:
            self._inicio = ahora
        self._progreso = min(1.0, (ahora - self._inicio) / 1e6 / DURACION_TRANSICION)
        self._texto.queue_draw()
        if self._progreso >= 1.0:
            self._anterior = None
            self._tic = None
            return GLib.SOURCE_REMOVE
        return GLib.SOURCE_CONTINUE

    @property
    def _visible_ahora(self):
        e = self.escena
        return (e.diapositiva if e.modo == "texto" else None, e.modo)

    def _actualizar_imagenes(self):
        e = self.escena
        negro = e.modo == "negro"
        self._fondo.set_paintable(None if negro else e.fondo_imagen)
        self._fondo.set_visible(bool(e.fondo_imagen) and not negro)
        es_medio = e.modo == "medio" and e.medio is not None
        self._medio.set_paintable(e.medio if es_medio else None)
        self._medio.set_visible(es_medio)

    # ------------------------------------------------------------ dibujo

    def _dibujar_base(self, _area, cr, ancho, alto):
        e = self.escena
        if e.modo == "negro" or e.fondo.get("tipo") not in ("color", "degradado"):
            cr.set_source_rgb(0, 0, 0)
        elif e.fondo["tipo"] == "degradado":
            c1, c2 = e.fondo["valor"][:2]
            degradado = cairo.LinearGradient(0, 0, ancho * 0.35, alto)
            degradado.add_color_stop_rgb(0, *color_rgb(c1))
            degradado.add_color_stop_rgb(1, *color_rgb(c2))
            cr.set_source(degradado)
        else:
            cr.set_source_rgb(*color_rgb(e.fondo["valor"]))
        cr.paint()

    def _dibujar_texto(self, _area, cr, ancho, alto):
        e = self.escena
        if ancho < 2 or alto < 2:
            return
        hay_imagen = e.fondo_imagen is not None and e.modo == "texto"
        if hay_imagen:
            cr.set_source_rgba(0, 0, 0, 0.38)
            cr.paint()
        if self._anterior is not None and self._progreso < 1.0:
            diapositiva, modo = self._anterior
            if modo == "texto" and diapositiva:
                self._pintar(cr, ancho, alto, diapositiva, 1.0 - self._progreso)
            if e.modo == "texto" and e.diapositiva:
                self._pintar(cr, ancho, alto, e.diapositiva, self._progreso)
        elif e.modo == "texto" and e.diapositiva:
            self._pintar(cr, ancho, alto, e.diapositiva, 1.0)

    def _layout(self, cr, texto, fuente, tamano, ancho):
        layout = PangoCairo.create_layout(cr)
        descripcion = Pango.FontDescription.from_string(fuente)
        descripcion.set_absolute_size(max(1, tamano) * Pango.SCALE)
        layout.set_font_description(descripcion)
        layout.set_width(int(ancho * Pango.SCALE))
        layout.set_wrap(Pango.WrapMode.WORD_CHAR)
        layout.set_alignment(Pango.Alignment.CENTER)
        layout.set_line_spacing(1.12)
        layout.set_text(texto, -1)
        return layout

    def _sombra_y_texto(self, cr, layout, x, y, rgb, alpha, radio):
        cr.set_source_rgba(0, 0, 0, 0.22 * alpha)
        for dx, dy in ((radio, radio * 1.6), (-radio, radio * 1.6), (0, radio * 2.4)):
            cr.move_to(x + dx, y + dy)
            PangoCairo.show_layout(cr, layout)
        cr.move_to(x, y)
        PangoCairo.layout_path(cr, layout)
        cr.set_source_rgba(0, 0, 0, 0.55 * alpha)
        cr.set_line_width(max(1.0, radio * 0.9))
        cr.set_line_join(cairo.LINE_JOIN_ROUND)
        cr.stroke()
        cr.set_source_rgba(*rgb, alpha)
        cr.move_to(x, y)
        PangoCairo.show_layout(cr, layout)

    def _pintar(self, cr, ancho, alto, diapositiva, alpha):
        estilo = self.escena.estilo
        texto = diapositiva.texto or ""
        texto2 = diapositiva.texto2 or ""
        if estilo["mayusculas"]:
            texto, texto2 = texto.upper(), texto2.upper()
        mostrar_ref = estilo["referencia"] and bool(diapositiva.referencia)
        margen = ancho * 0.07
        util_ancho = ancho - 2 * margen
        util_alto = alto * (0.80 if mostrar_ref else 0.88)
        tamano = alto * estilo["tamano"] / 100
        if texto2:
            tamano *= 0.78
        minimo = alto * 0.022
        while True:
            layout = self._layout(cr, texto, estilo["fuente"], tamano, util_ancho)
            alto1 = layout.get_pixel_extents()[1].height
            layout2 = None
            alto2 = separacion = 0
            if texto2:
                layout2 = self._layout(cr, texto2, estilo["fuente"], tamano * 0.88, util_ancho)
                alto2 = layout2.get_pixel_extents()[1].height
                separacion = tamano * 0.9
            total = alto1 + separacion + alto2
            if total <= util_alto or tamano <= minimo:
                break
            tamano = max(minimo, tamano * 0.92)
        y = (alto * (0.92 if mostrar_ref else 1.0) - total) / 2
        radio = max(1.0, tamano * 0.045)
        self._sombra_y_texto(cr, layout, margen, y, (1, 1, 1), alpha, radio)
        if layout2:
            cr.set_source_rgba(1, 1, 1, 0.25 * alpha)
            cr.rectangle(ancho * 0.42, y + alto1 + separacion / 2 - 1, ancho * 0.16, max(1.0, alto * 0.002))
            cr.fill()
            self._sombra_y_texto(cr, layout2, margen, y + alto1 + separacion, (0.96, 0.89, 0.72), alpha, radio)
        if mostrar_ref:
            ref = self._layout(cr, diapositiva.referencia, estilo["fuente"], alto * 0.034, util_ancho)
            alto_ref = ref.get_pixel_extents()[1].height
            self._sombra_y_texto(cr, ref, margen, alto * 0.955 - alto_ref, (1, 1, 1), 0.85 * alpha,
                                 max(1.0, alto * 0.0015))


class Proporcion(Gtk.Widget):
    """Mantiene a su hijo en 16:9 a todo el ancho disponible (igual en GTK 4.14 y en los más nuevos)."""

    def __init__(self, hijo, relacion=16 / 9):
        super().__init__()
        self.relacion = relacion
        self.hijo = hijo
        hijo.set_parent(self)

    def do_get_request_mode(self):
        return Gtk.SizeRequestMode.HEIGHT_FOR_WIDTH

    def do_measure(self, orientacion, para):
        if orientacion == Gtk.Orientation.HORIZONTAL:
            return 160, 320, -1, -1
        alto = int((para if para > 0 else 320) / self.relacion)
        return alto, alto, -1, -1

    def do_size_allocate(self, ancho, alto, linea_base):
        self.hijo.allocate(ancho, alto, linea_base, None)

    def do_dispose(self):
        if self.hijo is not None:
            self.hijo.unparent()
            self.hijo = None


class Encuadre(Gtk.Widget):
    """Acomoda a su hijo en 16:9, centrado, dentro del espacio que le den, sin pedir más ancho del necesario."""

    def __init__(self, hijo, relacion=16 / 9):
        super().__init__()
        self.relacion = relacion
        self.hijo = hijo
        hijo.set_parent(self)
        self.set_hexpand(True)
        self.set_vexpand(True)

    def do_measure(self, orientacion, _para):
        if orientacion == Gtk.Orientation.HORIZONTAL:
            return 192, 320, -1, -1
        return 108, 180, -1, -1

    def do_size_allocate(self, ancho, alto, _linea_base):
        w = min(ancho, int(alto * self.relacion))
        h = int(w / self.relacion)
        transformacion = Gsk.Transform().translate(_punto((ancho - w) / 2, 0))
        self.hijo.allocate(w, h, -1, transformacion)

    def do_dispose(self):
        if self.hijo is not None:
            self.hijo.unparent()
            self.hijo = None


def _punto(x, y):
    punto = Graphene.Point()
    punto.x, punto.y = x, y
    return punto

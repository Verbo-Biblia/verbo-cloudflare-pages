"""Lista de pantallas (estrofas o versículos) de lo elegido, al estilo de VideoPsalm: una fila compacta por pantalla.

Clic en una fila = mostrarla. El + de cada fila la agrega al orden del culto.
«Elegir varios» permite marcar varias (con Mayús, un tramo seguido) y agregarlas juntas.
"""

from gi.repository import Adw, Gdk, GLib, GObject, Gtk

from . import NOMBRE
from .idioma import _


class VistaDiapositivas(Gtk.Box):
    __gsignals__ = {
        "proyectar": (GObject.SignalFlags.RUN_FIRST, None, (int,)),
        "agregar-todo": (GObject.SignalFlags.RUN_FIRST, None, ()),
        # índices de las pantallas que se agregan juntas al orden
        "agregar": (GObject.SignalFlags.RUN_FIRST, None, (object,)),
        "editar": (GObject.SignalFlags.RUN_FIRST, None, ()),
    }

    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.diapositivas = []
        self._filas = []
        self._con_mayus = False
        self._ultimo_marcado = None

        cabecera = Gtk.Box(spacing=6, margin_start=12, margin_end=8, margin_top=8, margin_bottom=6)
        cabecera.add_css_class("cabecera-diapositivas")
        textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True, valign=Gtk.Align.CENTER)
        self.titulo = Gtk.Label(xalign=0, ellipsize=3)
        self.titulo.add_css_class("title-3")
        self.subtitulo = Gtk.Label(xalign=0, ellipsize=3)
        self.subtitulo.add_css_class("dim-label")
        self.subtitulo.add_css_class("caption")
        textos.append(self.titulo)
        textos.append(self.subtitulo)
        cabecera.append(textos)
        self.boton_editar = self._boton("document-edit-symbolic", _("Editar"), _("Cambiar la letra de esta canción"),
                                        lambda: self.emit("editar"))
        cabecera.append(self.boton_editar)
        self.boton_varios = Gtk.ToggleButton(valign=Gtk.Align.CENTER,
                                             tooltip_text=_("Marcar varias y agregarlas juntas al orden del culto"))
        self.boton_varios.set_child(Adw.ButtonContent(icon_name="eb-varios-symbolic", label=_("Elegir varios")))
        self.boton_varios.add_css_class("flat")
        self.boton_varios.connect("toggled", lambda *_: self._cambio_modo_varios())
        cabecera.append(self.boton_varios)
        self.boton_agregar = self._boton("list-add-symbolic", _("Todo al orden"), _("Agregar todo al orden del culto"),
                                         lambda: self.emit("agregar-todo"))
        cabecera.append(self.boton_agregar)
        self.cabecera = cabecera
        self.append(cabecera)

        self.lista = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, valign=Gtk.Align.START)
        self.lista.add_css_class("lista-diapositivas")
        self.lista.connect("row-activated", lambda _l, fila: self._fila_activada(fila))
        clic = Gtk.GestureClick(propagation_phase=Gtk.PropagationPhase.CAPTURE)
        clic.connect("pressed", self._al_presionar)
        self.lista.add_controller(clic)
        self.desplazable = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        self.desplazable.set_child(self.lista)

        self.vacio = Adw.StatusPage(icon_name="com.verbobiblia.Lumbrera", title=NOMBRE,
                                    description=_("Elige algo del orden del culto o una canción de la lista.\n"
                                                  "Haz clic en una pantalla para mostrarla."))
        self.vacio.add_css_class("compact")
        self.pila = Gtk.Stack(vexpand=True)
        self.pila.add_named(self.vacio, "vacio")
        self.pila.add_named(self.desplazable, "lista")
        self.append(self.pila)

        self.barra_varios = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_UP)
        barra = Gtk.Box(spacing=8, margin_start=12, margin_end=8, margin_bottom=8, margin_top=6)
        ayuda = Gtk.Label(label=_("Toca para marcar. Con Mayús marcas un tramo seguido."), xalign=0, hexpand=True,
                          wrap=True)
        ayuda.add_css_class("dim-label")
        ayuda.add_css_class("caption")
        barra.append(ayuda)
        cancelar = Gtk.Button(label=_("Cancelar"))
        cancelar.connect("clicked", lambda *_: self.boton_varios.set_active(False))
        barra.append(cancelar)
        self.boton_agregar_varios = Gtk.Button()
        self.boton_agregar_varios.add_css_class("suggested-action")
        self.boton_agregar_varios.connect("clicked", lambda *_: self._agregar_marcados())
        barra.append(self.boton_agregar_varios)
        self.barra_varios.set_child(barra)
        self.append(self.barra_varios)
        self.mostrar([], "", "")

    @staticmethod
    def _boton(icono, texto, ayuda, accion):
        boton = Gtk.Button(valign=Gtk.Align.CENTER, tooltip_text=ayuda)
        boton.set_child(Adw.ButtonContent(icon_name=icono, label=texto))
        boton.add_css_class("flat")
        boton.connect("clicked", lambda *_: accion())
        return boton

    # ------------------------------------------------------------ contenido

    def mostrar(self, diapositivas, titulo, subtitulo, es_cancion=False, se_puede_agregar=True):
        self.diapositivas = diapositivas
        self.boton_varios.set_active(False)
        self.titulo.set_label(titulo)
        self.subtitulo.set_label(subtitulo or "")
        self.subtitulo.set_visible(bool(subtitulo))
        self.boton_editar.set_visible(False)  # se edita en Configuración › Cancionero
        self.boton_agregar.set_visible(se_puede_agregar and bool(diapositivas))
        self.boton_varios.set_visible(len(diapositivas) > 1)
        self.cabecera.set_visible(bool(diapositivas))
        self.lista.remove_all()
        self._filas = []
        for diapositiva in diapositivas:
            fila = self._fila(diapositiva)
            self._filas.append(fila)
            self.lista.append(fila)
        self.pila.set_visible_child_name("lista" if diapositivas else "vacio")
        self.desplazable.get_vadjustment().set_value(0)

    def _fila(self, diapositiva):
        fila = Gtk.ListBoxRow()
        caja = Gtk.Box(spacing=8)
        caja.add_css_class("fila-diapositiva")
        fila.marca = Gtk.CheckButton(visible=False, valign=Gtk.Align.START)
        fila.marca.set_can_target(False)  # se marca tocando la fila
        fila.marca.connect("toggled", lambda *_: self._actualizar_cuenta())
        caja.append(fila.marca)
        etiqueta = Gtk.Label(label=diapositiva.etiqueta, xalign=0, yalign=0, width_chars=9, max_width_chars=12,
                             ellipsize=3)
        etiqueta.add_css_class("etiqueta-diapositiva")
        caja.append(etiqueta)
        textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, hexpand=True)
        texto = Gtk.Label(label=diapositiva.texto, xalign=0, wrap=True, lines=5, ellipsize=3)
        texto.set_wrap_mode(2)
        texto.add_css_class("texto-diapositiva")
        textos.append(texto)
        if diapositiva.texto2:
            texto2 = Gtk.Label(label=diapositiva.texto2, xalign=0, wrap=True, lines=3, ellipsize=3)
            texto2.set_wrap_mode(2)
            texto2.add_css_class("dim-label")
            texto2.add_css_class("caption")
            textos.append(texto2)
        caja.append(textos)
        fila.mas = Gtk.Button(icon_name="list-add-symbolic", tooltip_text=_("Agregar al orden del culto"),
                              valign=Gtk.Align.START)
        fila.mas.add_css_class("flat")
        fila.mas.add_css_class("boton-mas")
        fila.mas.connect("clicked", lambda *_: self.emit("agregar", [self._filas.index(fila)]))
        caja.append(fila.mas)
        fila.set_child(caja)
        return fila

    def marcar_en_vivo(self, indice):
        for i, fila in enumerate(self._filas):
            if i == indice:
                fila.add_css_class("en-vivo")
            else:
                fila.remove_css_class("en-vivo")
        if 0 <= indice < len(self._filas):
            self._hacer_visible(self._filas[indice])

    def enfocar(self, indice):
        if 0 <= indice < len(self._filas):
            self._filas[indice].grab_focus()

    def _hacer_visible(self, fila):
        def mover():
            punto = fila.compute_point(self.lista, _punto(0, 0))
            if punto is None or not punto[0]:
                return GLib.SOURCE_REMOVE
            y = punto[1].y
            ajuste = self.desplazable.get_vadjustment()
            alto_fila = fila.get_height()
            if y < ajuste.get_value():
                ajuste.set_value(y)
            elif y + alto_fila > ajuste.get_value() + ajuste.get_page_size():
                ajuste.set_value(y + alto_fila - ajuste.get_page_size())
            return GLib.SOURCE_REMOVE

        GLib.idle_add(mover)

    # ------------------------------------------------------------ varios a la vez

    def _al_presionar(self, gesto, *_):
        self._con_mayus = bool(gesto.get_current_event_state() & Gdk.ModifierType.SHIFT_MASK)

    def _fila_activada(self, fila):
        indice = self._filas.index(fila)
        if not self.boton_varios.get_active():
            self.emit("proyectar", indice)
            return
        if self._con_mayus and self._ultimo_marcado is not None:
            desde, hasta = sorted((self._ultimo_marcado, indice))
            for otra in self._filas[desde:hasta + 1]:
                otra.marca.set_active(True)
        else:
            fila.marca.set_active(not fila.marca.get_active())
        if fila.marca.get_active():
            self._ultimo_marcado = indice

    def _cambio_modo_varios(self):
        activo = self.boton_varios.get_active()
        for fila in self._filas:
            fila.marca.set_visible(activo)
            fila.mas.set_visible(not activo)
            if not activo:
                fila.marca.set_active(False)
        self._ultimo_marcado = None
        self.barra_varios.set_reveal_child(activo)
        self._actualizar_cuenta()

    def marcar_tramo(self, desde, hasta):
        """Deja marcadas las filas desde..hasta (por ejemplo, el rango de una cita)."""
        self.boton_varios.set_active(True)
        for fila in self._filas[desde:hasta + 1]:
            fila.marca.set_active(True)
        self._ultimo_marcado = hasta

    def _marcados(self):
        return [i for i, fila in enumerate(self._filas) if fila.marca.get_active()]

    def _actualizar_cuenta(self):
        cantidad = len(self._marcados())
        if cantidad == 0:
            texto = _("Marca las que quieras")
        elif cantidad == 1:
            texto = _("Agregar 1 al orden")
        else:
            texto = _("Agregar {n} al orden").format(n=cantidad)
        self.boton_agregar_varios.set_label(texto)
        self.boton_agregar_varios.set_sensitive(cantidad > 0)

    def _agregar_marcados(self):
        marcados = self._marcados()
        if marcados:
            self.emit("agregar", marcados)
            self.boton_varios.set_active(False)


def _punto(x, y):
    from gi.repository import Graphene
    punto = Graphene.Point()
    punto.x, punto.y = x, y
    return punto

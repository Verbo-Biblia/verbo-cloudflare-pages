"""Lo que está en pantalla ahora mismo. La proyección y la vista previa lo dibujan igual."""

from gi.repository import Gdk, GObject, Gtk

from . import rutas

FONDOS = [
    ("negro", "Negro", {"tipo": "color", "valor": "#000000"}),
    ("noche", "Noche", {"tipo": "degradado", "valor": ["#0b1424", "#1d3354"]}),
    ("vino", "Vino", {"tipo": "degradado", "valor": ["#1d0a10", "#4a1726"]}),
    ("bosque", "Bosque", {"tipo": "degradado", "valor": ["#07150f", "#163a2b"]}),
    ("violeta", "Violeta", {"tipo": "degradado", "valor": ["#140c22", "#36214f"]}),
    ("tierra", "Tierra", {"tipo": "degradado", "valor": ["#1a1309", "#47331a"]}),
    ("grafito", "Grafito", {"tipo": "degradado", "valor": ["#121417", "#2e333b"]}),
]

# Fotos que trae el programa (datos/fondos). El nombre se traduce al mostrarlo.
NOMBRES_IMAGENES = {"amanecer": "Amanecer", "montanas": "Montañas", "luz": "Luz", "trigal": "Trigal",
                    "estrellas": "Estrellas"}


def fondos_de_imagen():
    carpeta = rutas.DATOS / "fondos"
    resultado = []
    for clave, nombre in NOMBRES_IMAGENES.items():
        ruta = carpeta / f"{clave}.jpg"
        if ruta.is_file():
            resultado.append((clave, nombre, {"tipo": "imagen", "valor": str(ruta)}))
    return resultado


def color_rgb(hexadecimal):
    color = Gdk.RGBA()
    if not color.parse(hexadecimal or "#000"):
        color.parse("#000")
    return color.red, color.green, color.blue


class Escena(GObject.Object):
    """modo: «vacio» (solo fondo), «texto», «negro» o «medio» (imagen o video encima de todo)."""

    __gsignals__ = {"cambio": (GObject.SignalFlags.RUN_FIRST, None, (str,))}

    def __init__(self, ajustes):
        super().__init__()
        self.ajustes = ajustes
        self.modo = "vacio"
        self.diapositiva = None
        self.fondo = {"tipo": "color", "valor": "#000000"}
        self.fondo_imagen = None  # Gdk.Paintable para imagen o video de fondo
        self.medio = None  # Gdk.Paintable de la imagen o video al frente
        self.medio_tipo = None
        self.medio_ruta = None
        self.audio = None
        self.audio_ruta = None
        self.poner_fondo(ajustes["fondo"], guardar=False)

    # ----------------------------------------------------- estilo

    @property
    def estilo(self):
        a = self.ajustes
        return {"fuente": a["fuente"], "tamano": float(a["tamano"]), "referencia": bool(a["mostrar_referencia"]),
                "transicion": bool(a["transicion"]), "mayusculas": bool(a["mayusculas"])}

    def estilo_cambiado(self):
        self.emit("cambio", "estilo")

    # ----------------------------------------------------- contenido

    def mostrar(self, diapositiva):
        self._ocultar_medio_visual()
        self.diapositiva = diapositiva
        self.modo = "texto"
        self.emit("cambio", "contenido")

    def negro(self):
        self._ocultar_medio_visual()
        self.modo = "negro"
        self.emit("cambio", "contenido")

    def vaciar(self):
        self._ocultar_medio_visual()
        self.modo = "vacio"
        self.diapositiva = None
        self.emit("cambio", "contenido")

    # ----------------------------------------------------- fondo

    def poner_fondo(self, fondo, guardar=True):
        anterior = self.fondo_imagen
        self.fondo = dict(fondo)
        self.fondo_imagen = None
        tipo = self.fondo.get("tipo")
        try:
            if tipo == "imagen":
                self.fondo_imagen = Gdk.Texture.new_from_filename(self.fondo["valor"])
            elif tipo == "video":
                video = Gtk.MediaFile.new_for_filename(self.fondo["valor"])
                video.set_loop(True)
                video.set_muted(True)
                video.play()
                self.fondo_imagen = video
        except Exception:
            self.fondo = {"tipo": "color", "valor": "#000000"}
        if isinstance(anterior, Gtk.MediaStream):
            anterior.pause()
        if guardar:
            self.ajustes["fondo"] = self.fondo
        self.emit("cambio", "fondo")

    # ----------------------------------------------------- multimedia

    def _ocultar_medio_visual(self):
        if isinstance(self.medio, Gtk.MediaStream):
            self.medio.pause()
        self.medio = None
        self.medio_tipo = None
        self.medio_ruta = None

    def mostrar_medio(self, ruta, tipo):
        """tipo: «imagen» o «video». Se ve encima de todo."""
        if self.medio_ruta == ruta and self.modo == "medio":
            if isinstance(self.medio, Gtk.MediaStream):
                self.medio.play()
            return
        self._ocultar_medio_visual()
        if tipo == "imagen":
            self.medio = Gdk.Texture.new_from_filename(ruta)
        else:
            self.medio = Gtk.MediaFile.new_for_filename(ruta)
            self.medio.set_volume(float(self.ajustes["volumen"]))
            self.medio.play()
        self.medio_tipo = tipo
        self.medio_ruta = ruta
        self.modo = "medio"
        self.emit("cambio", "contenido")

    def reproducir_audio(self, ruta):
        if self.audio_ruta != ruta:
            if self.audio:
                self.audio.pause()
            self.audio = Gtk.MediaFile.new_for_filename(ruta)
            self.audio_ruta = ruta
        self.audio.set_volume(float(self.ajustes["volumen"]))
        self.audio.play()
        self.emit("cambio", "medio")

    def flujo_activo(self):
        """El audio o video que responde a Reproducir/Pausa."""
        if isinstance(self.medio, Gtk.MediaStream):
            return self.medio
        return self.audio

    def poner_volumen(self, valor):
        self.ajustes["volumen"] = valor
        for flujo in (self.medio, self.audio):
            if isinstance(flujo, Gtk.MediaStream):
                flujo.set_volume(valor)

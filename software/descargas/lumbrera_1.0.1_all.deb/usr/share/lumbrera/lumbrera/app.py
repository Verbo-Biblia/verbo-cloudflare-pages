"""Arranque del programa."""

import sys

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Pango", "1.0")
gi.require_version("PangoCairo", "1.0")
gi.require_version("Graphene", "1.0")
gi.require_version("Gsk", "4.0")
gi.require_version("GdkPixbuf", "2.0")

from gi.repository import GLib  # noqa: E402

from . import ID_APP, NOMBRE, VERSION, almacen, idioma, rutas  # noqa: E402

# En X11 (Linux Mint) el panel reconoce la ventana por este nombre; sin él aparecería como «python3».
GLib.set_prgname(ID_APP)

from gi.repository import Adw, Gdk, Gio, Gtk  # noqa: E402

from .idioma import _  # noqa: E402


class Aplicacion(Adw.Application):
    def __init__(self):
        super().__init__(application_id=ID_APP, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        GLib.set_application_name(NOMBRE)
        self.ventana = None

    def do_startup(self):
        Adw.Application.do_startup(self)
        rutas.preparar()
        primera_vez = not rutas.AJUSTES.exists()
        self.ajustes = almacen.Ajustes()
        idioma.iniciar(self.ajustes["idioma"] or None)
        if primera_vez:
            self.ajustes["biblia_a"] = {"pt": "bpm", "en": "bsb"}.get(idioma.actual(), "rv-verbo")
        self.biblioteca = almacen.Biblioteca()

        from .escena import Escena
        self.escena = Escena(self.ajustes)

        pantalla = Gdk.Display.get_default()
        Gtk.IconTheme.get_for_display(pantalla).add_search_path(str(rutas.ICONOS))
        Gtk.Window.set_default_icon_name(ID_APP)
        self._cargar_estilo(pantalla)

        for nombre, funcion in (("preferencias", self._preferencias), ("atajos", self._atajos),
                                ("importar", self._importar), ("exportar", self._exportar),
                                ("acerca", self._acerca), ("salir", self.quit)):
            accion = Gio.SimpleAction.new(nombre, None)
            accion.connect("activate", lambda _a, _p, f=funcion: f())
            self.add_action(accion)
        self.set_accels_for_action("app.salir", ["<Control>q"])
        self.set_accels_for_action("app.preferencias", ["<Control>comma"])
        self.set_accels_for_action("win.proyectar", ["F5"])
        self.set_accels_for_action("win.nueva-cancion", ["<Control>n"])
        self.set_accels_for_action("win.buscar", ["<Control>f"])
        self.set_accels_for_action("win.culto-guardar", ["<Control>s"])
        self.set_accels_for_action("win.culto-guardar-como", ["<Control><Shift>s"])
        self.set_accels_for_action("win.culto-abrir", ["<Control>o"])

    def _cargar_estilo(self, pantalla):
        # Desde libadwaita 1.6 los colores se definen con variables CSS; antes, con @define-color.
        con_variables = (Adw.get_major_version(), Adw.get_minor_version()) >= (1, 6)

        def proveedores(*nombres):
            lista = []
            for nombre in nombres:
                proveedor = Gtk.CssProvider()
                proveedor.load_from_path(str(rutas.DATOS / nombre))
                lista.append(proveedor)
            return lista

        claros = proveedores("estilo.css", *(["estilo-variables.css"] if con_variables else []))
        oscuros = proveedores("estilo-oscuro.css", *(["estilo-oscuro-variables.css"] if con_variables else []))
        for proveedor in claros:
            Gtk.StyleContext.add_provider_for_display(pantalla, proveedor, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        estilo = Adw.StyleManager.get_default()

        def aplicar_oscuro(*_):
            for proveedor in oscuros:
                if estilo.get_dark():
                    Gtk.StyleContext.add_provider_for_display(pantalla, proveedor,
                                                              Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
                else:
                    Gtk.StyleContext.remove_provider_for_display(pantalla, proveedor)

        estilo.connect("notify::dark", aplicar_oscuro)
        aplicar_oscuro()

    def do_activate(self):
        if self.ventana is None:
            from .ventana import VentanaPrincipal
            self.ventana = VentanaPrincipal(self)
        self.ventana.present()

    def do_shutdown(self):
        Adw.Application.do_shutdown(self)

    # ------------------------------------------------------------ menú

    def _preferencias(self):
        self.ventana.configuracion()

    def _atajos(self):
        filas = [
            ("→  /  Espacio  /  Av Pág", _("Siguiente pantalla")),
            ("←  /  Re Pág", _("Pantalla anterior")),
            ("B", _("Pantalla negra (otra vez para volver)")),
            ("Esc", _("Quitar el texto (queda el fondo)")),
            ("F5", _("Abrir o cerrar la proyección")),
            ("F11", _("Pantalla completa (en la ventana de proyección)")),
            ("Ctrl + N", _("Canción nueva")),
            ("Ctrl + F", _("Buscar canción")),
            ("Ctrl + S", _("Guardar (en el editor)")),
        ]
        texto = "\n".join(f"<b>{GLib.markup_escape_text(t)}</b>   {GLib.markup_escape_text(d)}" for t, d in filas)
        dialogo = Adw.AlertDialog(heading=_("Atajos de teclado"), body=texto, body_use_markup=True)
        dialogo.add_response("ok", _("Entendido"))
        dialogo.present(self.ventana)

    def _filtro_json(self):
        filtro = Gtk.FileFilter(name=_("Copias de canciones (JSON)"))
        filtro.add_suffix("json")
        filtros = Gio.ListStore.new(Gtk.FileFilter)
        filtros.append(filtro)
        return filtros

    def _importar(self):
        from .importar import EXTENSIONES_CHORDPRO, EXTENSIONES_SONGBOOKPRO, importar_archivo

        filtro = Gtk.FileFilter(name=_("Canciones (SongbookPro, ChordPro o copia de Lumbrera)"))
        for extension in sorted(EXTENSIONES_SONGBOOKPRO | EXTENSIONES_CHORDPRO | {".json"}):
            filtro.add_suffix(extension[1:])
        filtros = Gio.ListStore.new(Gtk.FileFilter)
        filtros.append(filtro)
        dialogo = Gtk.FileDialog(title=_("Importar canciones"), filters=filtros)

        def elegidos(dialogo, resultado):
            try:
                archivos = dialogo.open_multiple_finish(resultado)
            except GLib.Error:
                return
            total, fallidos = 0, 0
            for i in range(archivos.get_n_items()):
                try:
                    total += importar_archivo(self.biblioteca, archivos.get_item(i).get_path())
                except Exception:
                    fallidos += 1
            if total:
                self.ventana._avisar(_("Se importaron {n} canciones, sin acordes.").format(n=total))
            elif fallidos:
                self.ventana._avisar(_("Ese archivo no tiene canciones que se puedan leer."))

        dialogo.open_multiple(self.ventana, None, elegidos)

    def _exportar(self):
        fecha = GLib.DateTime.new_now_local().format("%Y-%m-%d")
        dialogo = Gtk.FileDialog(title=_("Guardar copia de las canciones"), filters=self._filtro_json(),
                                 initial_name=_("canciones-lumbrera-{fecha}.json").format(fecha=fecha))

        def elegido(dialogo, resultado):
            try:
                ruta = dialogo.save_finish(resultado).get_path()
            except GLib.Error:
                return
            cantidad = self.biblioteca.exportar(ruta)
            self.ventana._avisar(_("Copia guardada con {n} canciones.").format(n=cantidad))

        dialogo.save(self.ventana, None, elegido)

    def _acerca(self):
        """«Acerca de Lumbrera»: la lámpara y el logo de Verbo, juntos."""
        dialogo = Adw.Dialog(title=_("Acerca de {app}").format(app=NOMBRE), content_width=480)
        vista = Adw.ToolbarView()
        vista.add_top_bar(Adw.HeaderBar(show_title=False))
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin_start=32, margin_end=32,
                       margin_bottom=32, halign=Gtk.Align.CENTER)
        iconos = Gtk.Box(spacing=18, halign=Gtk.Align.CENTER, margin_bottom=10)
        lampara = Gtk.Image(icon_name=ID_APP, pixel_size=104)
        iconos.append(lampara)
        verbo = Gtk.Image.new_from_file(str(rutas.ICONOS / "verbo-borde.png"))
        verbo.set_pixel_size(104)
        iconos.append(verbo)
        caja.append(iconos)
        nombre = Gtk.Label(label=NOMBRE)
        nombre.add_css_class("title-1")
        caja.append(nombre)
        sub = Gtk.Label(label=_("Proyector para iglesias"))
        sub.add_css_class("title-4")
        caja.append(sub)
        version = Gtk.Label(label=_("Versión {v}").format(v=VERSION))
        version.add_css_class("dim-label")
        caja.append(version)
        verbo_texto = Gtk.Label(label=_("Un proyecto de Verbo"), margin_top=10)
        verbo_texto.add_css_class("heading")
        caja.append(verbo_texto)
        cita = Gtk.Label(label=_("«Lámpara es a mis pies tu palabra, y lumbrera a mi camino».\nSalmos 119:105"),
                         justify=Gtk.Justification.CENTER, wrap=True, margin_top=6)
        cita.add_css_class("dim-label")
        caja.append(cita)
        enlaces = Adw.PreferencesGroup(title=_("Más de Verbo"), margin_top=18)
        for titulo, subtitulo, icono, url in (
                (_("Página de Verbo"), "verbobiblia.com", "eb-web-symbolic", "https://verbobiblia.com"),
                (_("Verbo para Linux"), _("Estudio bíblico para la computadora. Descárgala gratis."),
                 "eb-proyectar-symbolic", "https://verbobiblia.com/verbo-desktop/"),
                (_("Verbo para Android"), _("Estudio bíblico en el celular, en Google Play."),
                 "eb-celular-symbolic", "https://play.google.com/store/apps/details?id=com.verbobiblia.app")):
            fila = Adw.ActionRow(title=titulo, subtitle=subtitulo, activatable=True, tooltip_text=url)
            fila.add_prefix(Gtk.Image(icon_name=icono))
            fila.add_suffix(Gtk.Image(icon_name="adw-external-link-symbolic"))
            fila.connect("activated", lambda _f, u=url: Gtk.UriLauncher.new(u).launch(self.ventana, None, None))
            enlaces.add(fila)
        caja.append(enlaces)
        desplazable = Gtk.ScrolledWindow(propagate_natural_height=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        desplazable.set_child(caja)
        vista.set_content(desplazable)
        dialogo.set_child(vista)
        dialogo.present(self.ventana)


def main():
    return Aplicacion().run(sys.argv)

"""Búsqueda de letras en internet y limpieza de textos (internet y PDF).

Consulta varias fuentes al mismo tiempo y junta los resultados:
  - LRCLIB (trae la letra en la misma respuesta)
  - Genius
  - musica.com (muy completa en alabanza en español)
  - Letras.com (solo para abrir en el navegador: no permite descargas automáticas)
Todo usa la biblioteca estándar de Python; no hace falta instalar nada.
"""

import html
import json
import re
import shutil
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from html.parser import HTMLParser

from . import VERSION
from .cancion import es_etiqueta, sin_acentos

AGENTE_APP = f"Lumbrera/{VERSION} (proyector de letras para iglesias)"
AGENTE_NAVEGADOR = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/129.0 Safari/537.36")
ESPERA = 12


@dataclass
class Resultado:
    titulo: str
    artista: str
    fuente: str
    album: str = ""
    letra: str = ""
    url: str = ""
    solo_navegador: bool = False
    puntaje: float = 0.0
    _descargar: object = field(default=None, repr=False)

    def obtener_letra(self):
        """Devuelve la letra ya limpia. Puede tardar (descarga).

        Si la página de este resultado falla, busca la misma canción en las otras fuentes (plan B).
        Lanza SinConexion si no hay internet, o devuelve "" si nadie tiene la letra.
        """
        if not self.letra and self._descargar:
            try:
                self.letra = self._descargar() or ""
            except (urllib.error.URLError, TimeoutError, OSError) as error:
                if not _hay_conexion():
                    raise SinConexion() from error
                self.letra = ""
            except Exception:
                self.letra = ""
        if not self.letra.strip():
            self.letra = _plan_b(self.titulo, self.artista)
        return normalizar_letra(self.letra)


class SinConexion(Exception):
    """No hay internet (no es culpa de una página en particular)."""


def _hay_conexion():
    try:
        _pedir("https://lrclib.net/api/search?q=test", espera=6)
        return True
    except Exception:
        return False


def _plan_b(titulo, artista):
    """Busca la misma canción en LRCLIB y en Genius y devuelve la primera letra que encuentre."""
    clave = re.sub(r"\W+", "", sin_acentos(limpiar_titulo(titulo)))
    consulta = f"{limpiar_titulo(titulo)} {artista}".strip()
    for fuente in (_lrclib, _genius):
        try:
            for resultado in fuente(consulta):
                if re.sub(r"\W+", "", sin_acentos(limpiar_titulo(resultado.titulo))) != clave:
                    continue
                letra = resultado.letra or (resultado._descargar() if resultado._descargar else "")
                if letra and letra.strip():
                    return letra
        except Exception:
            continue
    return ""


def _pedir(url, agente=AGENTE_APP, encabezados=None, espera=ESPERA):
    pedido = urllib.request.Request(url, headers={"User-Agent": agente, "Accept-Language": "es,pt;q=0.9,en;q=0.8",
                                                  **(encabezados or {})})
    with urllib.request.urlopen(pedido, timeout=espera) as respuesta:
        crudo = respuesta.read()
        juego = respuesta.headers.get_content_charset() or "utf-8"
    return crudo.decode(juego, errors="replace")


def _pedir_json(url, **kwargs):
    return json.loads(_pedir(url, **kwargs))


# --------------------------------------------------------------- fuentes

def _lrclib(consulta):
    datos = _pedir_json("https://lrclib.net/api/search?q=" + urllib.parse.quote(consulta),
                        encabezados={"Lrclib-Client": AGENTE_APP})
    resultados = []
    for r in datos if isinstance(datos, list) else []:
        letra = r.get("plainLyrics") or r.get("syncedLyrics") or ""
        if r.get("instrumental") or not letra.strip():
            continue
        resultados.append(Resultado(r.get("trackName") or "", r.get("artistName") or "", "LRCLIB",
                                    album=r.get("albumName") or "", letra=letra))
    return resultados


class _LectorGenius(HTMLParser):
    """Saca el texto de los bloques data-lyrics-container de una página de Genius."""

    VACIOS = {"br", "img", "hr", "input", "meta", "link", "wbr", "area", "source"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.partes = []
        self._pila = []  # (etiqueta, dentro_letra, excluida)

    def _estado(self):
        return self._pila[-1][1:] if self._pila else (False, False)

    def handle_starttag(self, etiqueta, atributos):
        atributos = dict(atributos)
        dentro, excluida = self._estado()
        if atributos.get("data-lyrics-container") == "true":
            dentro = True
            if self.partes:
                self.partes.append("\n")
        if dentro and atributos.get("data-exclude-from-selection") == "true":
            excluida = True
        if etiqueta == "br":
            if dentro and not excluida:
                self.partes.append("\n")
            return
        if etiqueta not in self.VACIOS:
            self._pila.append((etiqueta, dentro, excluida))

    def handle_endtag(self, etiqueta):
        for i in range(len(self._pila) - 1, -1, -1):
            if self._pila[i][0] == etiqueta:
                del self._pila[i:]
                return

    def handle_data(self, datos):
        dentro, excluida = self._estado()
        if dentro and not excluida:
            self.partes.append(datos)


def _genius(consulta):
    datos = _pedir_json("https://genius.com/api/search/multi?q=" + urllib.parse.quote(consulta),
                        agente=AGENTE_NAVEGADOR)
    resultados = []
    vistos = set()
    for seccion in (datos.get("response") or {}).get("sections") or []:
        for hit in seccion.get("hits") or []:
            if hit.get("type") != "song":
                continue
            r = hit.get("result") or {}
            url = r.get("url") or ""
            if not url or url in vistos or r.get("instrumental"):
                continue
            vistos.add(url)

            def descargar(u=url):
                lector = _LectorGenius()
                lector.feed(_pedir(u, agente=AGENTE_NAVEGADOR, espera=20))
                return "".join(lector.partes)

            artista = (r.get("primary_artist") or {}).get("name") or r.get("artist_names") or ""
            resultados.append(Resultado(r.get("title") or "", artista, "Genius", url=url, _descargar=descargar))
    return resultados[:10]


def _texto_html(fragmento):
    fragmento = re.sub(r"<br\s*/?>", "\n", fragmento, flags=re.I)
    fragmento = re.sub(r"</p\s*>", "\n\n", fragmento, flags=re.I)
    return html.unescape(re.sub(r"<[^>]+>", "", fragmento))


def _musica_com(consulta):
    pagina = _pedir("https://www.musica.com/letras.asp?q=" + urllib.parse.quote(consulta), agente=AGENTE_NAVEGADOR)
    patron = re.compile(r'<a href="(https://www\.musica\.com/letras\.asp\?letra=\d+)"><b>(.*?)</b><br>(.*?)</a>',
                        re.S)
    resultados = []
    vistos = set()
    for url, artista, titulo in patron.findall(pagina):
        if url in vistos:
            continue
        vistos.add(url)

        def descargar(u=url):
            texto = _pedir(u, agente=AGENTE_NAVEGADOR, espera=20)
            bloque = re.search(r'<div id="letra"[^>]*>(.*?)</div>', texto, re.S)
            if not bloque:
                return ""
            contenido = re.sub(r"<h2>.*?</h2>", "", bloque.group(1), flags=re.S)
            contenido = re.sub(r"^\s*<p>\s*<strong>.*?</strong>\s*</p>", "", contenido, flags=re.S)
            return _texto_html(contenido)

        resultados.append(Resultado(_texto_html(titulo).strip(), _texto_html(artista).strip(), "musica.com",
                                    url=url, _descargar=descargar))
    return resultados[:10]


def _letras_com(consulta):
    crudo = _pedir("https://solr.sscdn.co/letras/m1/?wt=json&q=" + urllib.parse.quote(consulta),
                   agente=AGENTE_NAVEGADOR)
    crudo = crudo.strip()
    if not crudo.startswith("{"):
        crudo = crudo[crudo.find("(") + 1:crudo.rfind(")")]
    resultados = []
    for doc in (json.loads(crudo).get("response") or {}).get("docs") or []:
        if str(doc.get("t")) != "2" or not doc.get("dns") or not doc.get("url"):
            continue
        url = f"https://www.letras.com/{doc['dns']}/{doc['url']}/"
        resultados.append(Resultado(doc.get("txt") or "", doc.get("art") or "", "Letras.com", url=url,
                                    solo_navegador=True))
    return resultados[:6]


# lyrics.ovh se quitó en 2026-10: su servicio de letras responde «no encontrado» para todo.
FUENTES = [_lrclib, _genius, _musica_com, _letras_com]


def _puntuar(resultado, palabras):
    titulo = sin_acentos(f"{resultado.titulo} {resultado.artista}")
    aciertos = sum(1 for p in palabras if p in titulo)
    puntaje = aciertos / max(1, len(palabras)) * 10
    if sin_acentos(resultado.titulo) and sin_acentos(resultado.titulo) in " ".join(palabras):
        puntaje += 3
    if resultado.letra:
        puntaje += 1.5
    if resultado.solo_navegador:
        puntaje -= 4
    return puntaje


def _se_parece(resultado, palabras):
    """Descarta lo que no tiene nada que ver: alguna palabra de la búsqueda debe estar en el título."""
    titulo = sin_acentos(resultado.titulo)
    significativas = [p for p in palabras if len(p) > 2] or palabras
    return any(p in titulo for p in significativas)


def buscar(consulta, al_avanzar=None):
    """Busca en todas las fuentes a la vez. Devuelve (resultados, fuentes_con_error)."""
    consulta = " ".join(consulta.split())
    palabras = sin_acentos(consulta).split()
    resultados, errores = [], []
    with ThreadPoolExecutor(max_workers=len(FUENTES)) as grupo:
        tareas = {grupo.submit(fuente, consulta): fuente.__name__.strip("_") for fuente in FUENTES}
        for tarea in as_completed(tareas):
            try:
                resultados.extend(tarea.result())
            except Exception:  # una fuente caída no detiene a las demás
                errores.append(tareas[tarea])
            if al_avanzar:
                al_avanzar(len(resultados))
    unicos = {}
    for resultado in resultados:
        if not resultado.titulo or not _se_parece(resultado, palabras):
            continue
        resultado.puntaje = _puntuar(resultado, palabras)
        clave = (sin_acentos(resultado.artista).strip(), re.sub(r"\W+", "", sin_acentos(resultado.titulo)),
                 resultado.solo_navegador)
        if clave not in unicos or resultado.puntaje > unicos[clave].puntaje:
            unicos[clave] = resultado
    ordenados = sorted(unicos.values(), key=lambda r: -r.puntaje)
    return ordenados[:30], errores


# --------------------------------------------------------------- limpieza

_SECCION = (r"verse|verso|estrofa|estrofe|chorus|coro|estribillo|refr[aã]o|bridge|puente|ponte|pre[- ]?chorus|"
            r"pre[- ]?coro|pr[ée][- ]?refr[aã]o|intro|outro|ending|final|tag|interludio|interlude")


def limpiar_titulo(titulo):
    return re.sub(r"\s*[(\[][^)\]]*(remaster|live|en vivo|ao vivo|version|versión|edit|mix)[^)\]]*[)\]]\s*$",
                  "", str(titulo or ""), flags=re.I).strip()


def normalizar_letra(texto):
    letra = str(texto or "").replace("\r\n", "\n").replace("\r", "\n")
    letra = re.sub(r"\[\d{1,2}:\d{2}(?:[.:]\d+)?\]", "", letra)  # tiempos LRC
    letra = re.sub(r"^\s*\[(?:ar|al|ti|by|offset|length|re|ve):[^\]]*\]\s*$", "", letra, flags=re.I | re.M)
    # Encabezados [Coro], [Verse 1: Nombre], Coro: … pasan a ser etiquetas en su propia parte.
    letra = re.sub(rf"^\s*\[\s*({_SECCION})([^\]:]*)(?::[^\]]*)?\]\s*$",
                   lambda m: f"\n\n{m.group(1).capitalize()}{m.group(2).rstrip()}", letra, flags=re.I | re.M)
    letra = re.sub(rf"^\s*({_SECCION})(\s*\d*)\s*[:.…]*[ \t]*$",
                   lambda m: f"\n\n{m.group(1).capitalize()}{m.group(2)}", letra, flags=re.I | re.M)
    # Otras notas entre corchetes ([Letra de …], [Instrumental]) no se proyectan.
    letra = re.sub(r"^\s*\[[^\]\n]*\]\s*$", "", letra, flags=re.M)
    lineas = [linea.strip() for linea in letra.split("\n")]
    letra = re.sub(r"\n{3,}", "\n\n", "\n".join(lineas)).strip()
    # Una etiqueta sola seguida de línea en blanco se une con su texto.
    letra = re.sub(r"^(.+)\n\n(?=\S)", lambda m: m.group(1) + "\n" if es_etiqueta(m.group(1)) else m.group(0),
                   letra, flags=re.M)
    # Si todo viene en un solo bloque largo, se arma en grupos de 4 líneas.
    if "\n\n" not in letra:
        lineas = [linea for linea in letra.split("\n") if linea.strip()]
        if len(lineas) > 8:
            letra = "\n\n".join("\n".join(lineas[i:i + 4]) for i in range(0, len(lineas), 4))
    return letra


_ACORDE = re.compile(r"^(?:[A-G](?:#|b)?(?:m|maj|min|dim|aug|sus|add)?\d*(?:\/[A-G](?:#|b)?)?|N\.?C\.?|"
                     r"[-/|:xX0-9()]+)$")
# Acordes escritos a mano: pegados («FF7M», «EmAm»), con bajo suelto («/D#»), con extensiones («Aadd9/E»,
# «G#7/5-», «Fm#») o en solfeo («RE7», «SOL»).
_NOTA = r"(?:[A-G](?:#|b)?|(?:DO|RE|MI|FA|SOL|LA|SI)(?:#|b)?)"
_UN_ACORDE = rf"{_NOTA}(?:maj|min|dim|aug|sus|add|m|M|º|°|\+)*\d*(?:(?:maj|sus|add|M|b|#|-|\+)\d*)*#?"
_CON_BAJO = rf"{_UN_ACORDE}(?:/(?:{_NOTA}m?#?|\d+-?|sus\d*))?"
_ACORDE_SOLO = re.compile(rf"^(?:/{_NOTA}#?|{_CON_BAJO}|sus\d*)$")
_ACORDES_PEGADOS = re.compile(rf"^(?:{_CON_BAJO}){{2,}}$")
_SOLFEO = re.compile(r"^(?:DO|RE|MI|FA|SOL|LA|SI)(?:#|b)?$")
# Rótulos para músicos delante de los acordes («Intro:», «Interlude (x6):», «Repite:», «Arreglo:»).
_ROTULO_MUSICOS = re.compile(r"^(?:intro|instrumental|interlude|interludio|intermedio|repite|repetir|estribillo|"
                             r"arreglo|outro|solo|tag|turnaround|riff|flauta|guitarra|piano|\(?x\d+\)?|\d+)[:.]?$",
                             re.I)
# Notas para músicos entre paréntesis: «(Riff 1)», «(Instrumental)».
_NOTA_MUSICOS = re.compile(r"^\((?:riff|instrumental|intro|solo|interlude|interludio|intermedio)\b[^)]*\)$", re.I)


def _es_acorde(parte):
    if _ACORDE.match(parte):
        return True
    parte = parte.strip(".,;/")
    if "-" in parte.strip("-") and not parte.startswith("("):  # «Bm-F#m-E-Esus4-E»
        return all(_es_acorde(p) for p in parte.split("-") if p)
    if parte.startswith("(") and parte.endswith(")"):
        return all(_es_acorde(p) for p in re.split(r"[-/]", parte[1:-1]) if p)
    base, _parentesis, resto = parte.partition("(")  # «D(A-B)»
    if resto:
        return _es_acorde(base) and _es_acorde("(" + resto)
    if _ACORDE_SOLO.match(parte):
        return True
    # Pegados solo si se nota que son acordes («EmAm», «FF7M»); así «DA» o «DEBE» en mayúsculas no cuentan.
    return bool(_ACORDES_PEGADOS.match(parte)) and bool(re.search(r"[\d#m]", parte))


def parece_linea_de_acordes(linea):
    partes = re.sub(r"\.-", " ", str(linea or "")).replace("|", " | ").replace(":", ": ").split()
    if not partes:
        return False
    if _NOTA_MUSICOS.match(" ".join(partes)):
        return True
    acordes = [p for p in partes if not _ROTULO_MUSICOS.match(p)]
    if all(_SOLFEO.match(p) for p in acordes):
        return False  # «SI», «LA LA LA»: puede ser letra
    if len(acordes) == len(partes):
        if len(partes) > 1 and partes[0].endswith(":") and re.fullmatch(_SECCION, partes[0][:-1], re.I):
            acordes = partes[1:]  # «Bridge: Ab»: la tonalidad de la sección, para los músicos
        return all(_es_acorde(p) for p in acordes)
    # Con rótulo, tiene que haber acordes de verdad (si no, «Intro:» sola es una etiqueta, no se toca aquí).
    return bool(acordes) and all(_es_acorde(p) for p in acordes)


def quitar_acordes(texto):
    texto = re.sub(r"\[[^\]\n]*\]", "", str(texto or ""))
    lineas = [linea.rstrip() for linea in texto.split("\n") if not parece_linea_de_acordes(linea)]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(lineas)).strip()


def pdf_disponible():
    return shutil.which("pdftotext") is not None


def texto_de_pdf(ruta):
    """Devuelve (titulo_sugerido, autor_sugerido, letra)."""
    proceso = subprocess.run(["pdftotext", "-enc", "UTF-8", str(ruta), "-"], capture_output=True, timeout=60)
    if proceso.returncode != 0:
        raise RuntimeError(proceso.stderr.decode("utf-8", "replace").strip() or "pdftotext falló")
    texto = proceso.stdout.decode("utf-8", "replace").replace("\f", "\n\n")
    texto = quitar_acordes(texto)
    if not texto.strip():
        raise ValueError("sin texto")
    lineas = texto.split("\n")
    titulo = autor = ""
    tono = next((i for i, linea in enumerate(lineas[:5]) if re.match(r"^\s*(tonalidad|tono|tom|key)\s*:", linea, re.I)),
                -1)
    if tono >= 1:
        titulo = lineas[0].strip()
        autor = " ".join(linea.strip() for linea in lineas[1:tono]).strip()
        texto = "\n".join(lineas[tono + 1:])
    return titulo, autor, normalizar_letra(texto)

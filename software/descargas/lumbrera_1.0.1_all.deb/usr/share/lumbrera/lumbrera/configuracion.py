"""Configuración: cancionero (editar canciones), Biblias, pantalla e idioma.

La ventana principal queda solo para el culto; todo lo que se prepara antes está aquí.
"""

import threading

from gi.repository import Adw, Gio, GLib, Gtk, Pango

from .editor import EditorCancion

from . import biblia, idioma, rutas
from .idioma import _
from .proyeccion import id_monitor, monitores, nombre_monitor


class Configuracion(Gtk.Box):
    """Ocupa toda la ventana: secciones a la izquierda y mucho espacio para trabajar a la derecha."""

    def __init__(self, ventana):
        super().__init__()
        self.ventana = ventana
        self.ajustes = ventana.ajustes
        self.escena = ventana.escena
        self.biblioteca = ventana.biblioteca

        self.secciones = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, hexpand=True)
        menu = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        menu.add_css_class("navigation-sidebar")
        menu.add_css_class("menu-configuracion")
        for nombre, titulo, icono, pagina in (
                ("cancionero", _("Cancionero"), "eb-musica-symbolic", self._pagina_cancionero()),
                ("ajustes", _("Ajustes"), "eb-ajustes-symbolic", self._pagina_ajustes())):
            self.secciones.add_named(pagina, nombre)
            fila = Gtk.ListBoxRow()
            fila.nombre = nombre
            caja = Gtk.Box(spacing=12, margin_top=6, margin_bottom=6, margin_start=6)
            caja.append(Gtk.Image(icon_name=icono))
            caja.append(Gtk.Label(label=titulo, xalign=0))
            fila.set_child(caja)
            menu.append(fila)
        menu.connect("row-selected", lambda _m, fila: fila and self.secciones.set_visible_child_name(fila.nombre))
        self.menu = menu
        lateral = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin_top=10, margin_start=8, margin_end=8)
        lateral.set_size_request(210, -1)
        lateral.add_css_class("columna-biblioteca")
        lateral.append(menu)
        lateral.append(Gtk.Box(vexpand=True))
        lateral.append(self._firma_verbo())
        self.append(lateral)
        self.append(self.secciones)
        menu.select_row(menu.get_row_at_index(0))
        self.biblioteca.al_cambiar(self._llenar_canciones)

    def _firma_verbo(self):
        """Logo de Verbo en una esquina: Lumbrera es un proyecto de Verbo."""
        boton = Gtk.Button(tooltip_text=_("Acerca de {app}").format(app="Lumbrera"), margin_bottom=12)
        boton.add_css_class("flat")
        boton.add_css_class("firma-verbo")
        caja = Gtk.Box(spacing=10)
        logo = Gtk.Image.new_from_file(str(rutas.ICONOS / "verbo-borde.png"))
        logo.set_pixel_size(34)
        caja.append(logo)
        textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, valign=Gtk.Align.CENTER)
        arriba = Gtk.Label(label=_("Un proyecto de"), xalign=0)
        arriba.add_css_class("caption")
        arriba.add_css_class("dim-label")
        textos.append(arriba)
        nombre = Gtk.Label(label="Verbo", xalign=0)
        nombre.add_css_class("heading")
        textos.append(nombre)
        caja.append(textos)
        boton.set_child(caja)
        boton.connect("clicked", lambda *_: self.ventana.get_application().activate_action("acerca", None))
        return boton

    def ir_a(self, nombre):
        for i in range(2):
            fila = self.menu.get_row_at_index(i)
            if fila and fila.nombre == nombre:
                self.menu.select_row(fila)

    # ================================================================ cancionero

    def _pagina_cancionero(self):
        caja = Gtk.Box()

        lista = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin_start=12, margin_end=12,
                        margin_top=12, margin_bottom=12)
        lista.set_size_request(300, -1)
        nueva = Gtk.Button()
        nueva.set_child(Adw.ButtonContent(icon_name="list-add-symbolic", label=_("Nueva canción")))
        nueva.add_css_class("suggested-action")
        nueva.connect("clicked", lambda *_: self.editor.cargar(None))
        lista.append(nueva)
        internet = Gtk.Button()
        internet.set_child(Adw.ButtonContent(icon_name="system-search-symbolic",
                                             label=_("Buscar una canción en internet")))
        internet.connect("clicked", lambda *_: self.editor.cargar(None, busqueda=" "))
        lista.append(internet)

        self.buscador = Gtk.SearchEntry(placeholder_text=_("Buscar en tus canciones…"), margin_top=6)
        self.buscador.connect("search-changed", lambda *_: self._llenar_canciones())
        lista.append(self.buscador)
        self.canciones = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        self.canciones.add_css_class("navigation-sidebar")
        self.canciones.connect("row-activated", lambda _l, fila: self.editor.cargar(fila.cancion))
        desplazable = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        desplazable.set_child(self.canciones)
        lista.append(desplazable)

        copias = Gtk.Box(spacing=6, homogeneous=True)
        for texto, icono, accion in ((_("Importar"), "document-open-symbolic", "importar"),
                                     (_("Guardar copia"), "document-save-symbolic", "exportar")):
            boton = Gtk.Button(tooltip_text=_("Importar canciones…") if accion == "importar"
                               else _("Guardar copia de las canciones…"))
            boton.set_child(Adw.ButtonContent(icon_name=icono, label=texto))
            boton.connect("clicked", lambda _b, a=accion: self.ventana.get_application().activate_action(a, None))
            copias.append(boton)
        lista.append(copias)
        caja.append(lista)
        caja.append(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL))

        self.editor = EditorCancion(self.biblioteca, lambda: int(self.ajustes["max_lineas"]), self.ventana._avisar)
        self.editor.set_hexpand(True)
        self.editor.connect("guardada", lambda _e, c: self.marcar_cancion(c))
        caja.append(self.editor)
        self._llenar_canciones()
        return caja

    def marcar_cancion(self, cancion):
        fila = self.canciones.get_first_child()
        while fila is not None:
            if getattr(fila, "cancion", None) is not None and cancion is not None and fila.cancion.id == cancion.id:
                self.canciones.select_row(fila)
                return
            fila = fila.get_next_sibling()
        self.canciones.unselect_all()

    def _llenar_canciones(self):
        consulta = self.buscador.get_text() if hasattr(self, "buscador") else ""
        self.canciones.remove_all()
        actual = self.editor.cancion.id if getattr(self, "editor", None) and self.editor.cancion else None
        for cancion in self.biblioteca.buscar(consulta):
            fila = Gtk.ListBoxRow()
            fila.cancion = cancion
            textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin_top=4, margin_bottom=4)
            titulo = Gtk.Label(label=cancion.titulo, xalign=0, ellipsize=3)
            titulo.add_css_class("heading")
            textos.append(titulo)
            if cancion.autor:
                autor = Gtk.Label(label=cancion.autor, xalign=0, ellipsize=3)
                autor.add_css_class("caption")
                autor.add_css_class("dim-label")
                textos.append(autor)
            fila.set_child(textos)
            self.canciones.append(fila)
            if cancion.id == actual:
                self.canciones.select_row(fila)

    # ================================================================ Biblias

    def _pagina_ajustes(self):
        """Biblias, pantalla e idioma juntos, en una columna amplia y con letra más grande."""
        columna = _Columna()
        self._pagina_biblias(columna)
        self._pagina_pantalla(columna)
        self._pagina_idioma(columna)
        ajuste = Adw.Clamp(maximum_size=920, tightening_threshold=760, child=columna)
        desplazable = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER, vexpand=True, hexpand=True)
        desplazable.set_child(ajuste)
        return desplazable

    def _pagina_biblias(self, pagina):
        grupo = Adw.PreferencesGroup(title=_("Biblias para el culto"),
                                     description=_("La segunda se muestra debajo de la principal, en otro color."))
        self.fila_principal = Adw.ComboRow(title=_("Biblia principal"))
        self.fila_segunda = Adw.ComboRow(title=_("Segunda Biblia"), subtitle=_("Opcional"))
        self.fila_principal.connect("notify::selected", self._cambio_biblias)
        self.fila_segunda.connect("notify::selected", self._cambio_biblias)
        grupo.add(self.fila_principal)
        grupo.add(self.fila_segunda)
        fila_importar = Adw.ActionRow(title=_("Importar Biblia…"), activatable=True,
                                      subtitle=_("De MySword (.bbl.mybible), e-Sword (.bblx, .bbli) o XML "
                                                 "(Zefania, OSIS)"))
        fila_importar.add_prefix(Gtk.Image(icon_name="document-open-symbolic"))
        fila_importar.add_suffix(Gtk.Image(icon_name="go-next-symbolic"))
        fila_importar.connect("activated", lambda *_: self._elegir_biblia())
        grupo.add(fila_importar)
        pagina.add(grupo)

        self.grupo_importadas = Adw.PreferencesGroup(title=_("Biblias que importaste"))
        self._filas_importadas = []
        pagina.add(self.grupo_importadas)
        self._llenar_biblias()

    def _llenar_biblias(self):
        self._ids_biblias = [v.id for v in biblia.versiones()]
        nombres = [f"{v.nombre} ({v.idioma})" for v in biblia.versiones()]
        self._llenando = True
        self.fila_principal.set_model(Gtk.StringList.new(nombres))
        self.fila_segunda.set_model(Gtk.StringList.new([_("Ninguna")] + nombres))
        ids = self._ids_biblias
        self.fila_principal.set_selected(ids.index(self.ajustes["biblia_a"]) if self.ajustes["biblia_a"] in ids else 0)
        self.fila_segunda.set_selected(ids.index(self.ajustes["biblia_b"]) + 1 if self.ajustes["biblia_b"] in ids
                                       else 0)
        self._llenando = False

        for fila in self._filas_importadas:
            self.grupo_importadas.remove(fila)
        self._filas_importadas = []
        importadas = [v for v in biblia.versiones() if v.carpeta.parent == rutas.USUARIO_BIBLIAS]
        self.grupo_importadas.set_visible(bool(importadas))
        for version in importadas:
            fila = Adw.ActionRow(title=GLib.markup_escape_text(version.nombre),
                                 subtitle=GLib.markup_escape_text(_("{n} libros").format(n=len(version.libros))))
            quitar = Gtk.Button(icon_name="user-trash-symbolic", valign=Gtk.Align.CENTER,
                                tooltip_text=_("Quitar esta Biblia"))
            quitar.add_css_class("flat")
            quitar.connect("clicked", lambda _b, v=version: self._confirmar_quitar_biblia(v))
            fila.add_suffix(quitar)
            self.grupo_importadas.add(fila)
            self._filas_importadas.append(fila)

    def _cambio_biblias(self, *_):
        if getattr(self, "_llenando", False) or not self._ids_biblias:
            return
        ids = self._ids_biblias
        self.ajustes["biblia_a"] = ids[min(self.fila_principal.get_selected(), len(ids) - 1)]
        indice = self.fila_segunda.get_selected()
        self.ajustes["biblia_b"] = ids[indice - 1] if 0 < indice <= len(ids) else ""
        self.ventana.panel_biblia.recargar()

    def _elegir_biblia(self):
        from .importar_biblia import EXTENSIONES
        filtro = Gtk.FileFilter(name=_("Biblias (MySword, e-Sword o XML)"))
        for extension in EXTENSIONES:
            filtro.add_pattern("*" + extension)
            filtro.add_pattern("*" + extension.upper())
        filtros = Gio.ListStore.new(Gtk.FileFilter)
        filtros.append(filtro)
        dialogo = Gtk.FileDialog(title=_("Importar una Biblia"), filters=filtros)

        def elegido(dialogo, resultado):
            try:
                ruta = dialogo.open_finish(resultado).get_path()
            except GLib.Error:
                return
            self.ventana._avisar(_("Importando la Biblia…"))

            def trabajo():
                from .importar_biblia import importar_biblia
                try:
                    nombre, falla = importar_biblia(ruta), None
                except Exception as error:
                    nombre, falla = None, error
                GLib.idle_add(listo, nombre, falla)

            threading.Thread(target=trabajo, daemon=True).start()

        def listo(nombre, falla):
            if falla is not None:
                self.ventana._avisar(_("No se pudo importar: ese archivo no es una Biblia que Lumbrera pueda leer."))
                return GLib.SOURCE_REMOVE
            self._llenar_biblias()
            self.ventana.panel_biblia.recargar()
            self.ventana._avisar(_("Se agregó «{nombre}». Ya puedes elegirla arriba.").format(nombre=nombre))
            return GLib.SOURCE_REMOVE

        dialogo.open(self.get_root(), None, elegido)

    def _confirmar_quitar_biblia(self, version):
        dialogo = Adw.AlertDialog(heading=_("¿Quitar «{nombre}»?").format(nombre=version.nombre),
                                  body=_("Se borra de Lumbrera. El archivo original que importaste no se toca."))
        dialogo.add_response("no", _("Cancelar"))
        dialogo.add_response("si", _("Quitar"))
        dialogo.set_response_appearance("si", Adw.ResponseAppearance.DESTRUCTIVE)
        dialogo.set_close_response("no")

        def respuesta(_d, opcion):
            if opcion != "si":
                return
            from .importar_biblia import quitar_biblia
            quitar_biblia(version.id)
            if self.ajustes["biblia_a"] == version.id:
                self.ajustes["biblia_a"] = ""
            if self.ajustes["biblia_b"] == version.id:
                self.ajustes["biblia_b"] = ""
            self._llenar_biblias()
            self.ventana.panel_biblia.recargar()

        dialogo.connect("response", respuesta)
        dialogo.present(self)

    # ================================================================ pantalla

    def _pagina_pantalla(self, pagina):

        grupo = Adw.PreferencesGroup(title=_("Proyección"))
        self._monitores = monitores()
        opciones = [_("Automática (la otra pantalla)")] + [nombre_monitor(m) for m in self._monitores]
        fila_pantalla = Adw.ComboRow(title=_("Pantalla para proyectar"),
                                     subtitle=_("Dónde se abre la ventana que ve la congregación"),
                                     model=Gtk.StringList.new(opciones))
        ids = [id_monitor(m) for m in self._monitores]
        fila_pantalla.set_selected(ids.index(self.ajustes["pantalla"]) + 1 if self.ajustes["pantalla"] in ids else 0)

        def cambio_pantalla(fila, *_):
            indice = fila.get_selected()
            self.ajustes["pantalla"] = id_monitor(self._monitores[indice - 1]) if indice > 0 else "auto"
            self.ventana._colocar_proyeccion()

        fila_pantalla.connect("notify::selected", cambio_pantalla)
        grupo.add(fila_pantalla)
        automatica = Adw.SwitchRow(title=_("Proyectar sola al conectar el televisor o proyector"),
                                   subtitle=_("Con las pantallas en modo «extender». Si se desconecta, la proyección "
                                              "queda como ventana pequeña."),
                                   active=bool(self.ajustes["proyectar_al_conectar"]))
        automatica.connect("notify::active",
                           lambda f, *_: self.ajustes.__setitem__("proyectar_al_conectar", f.get_active()))
        grupo.add(automatica)
        pagina.add(grupo)

        grupo = Adw.PreferencesGroup(title=_("Letra en pantalla"))
        fila_fuente = Adw.ActionRow(title=_("Tipo de letra"))
        boton_fuente = Gtk.FontDialogButton(dialog=Gtk.FontDialog(title=_("Elegir tipo de letra")),
                                            level=Gtk.FontLevel.FACE, valign=Gtk.Align.CENTER)
        boton_fuente.set_font_desc(Pango.FontDescription.from_string(self.ajustes["fuente"]))
        boton_fuente.connect("notify::font-desc", self._cambio_fuente)
        fila_fuente.add_suffix(boton_fuente)
        grupo.add(fila_fuente)

        tamano = Adw.SpinRow.new_with_range(3, 14, 0.5)
        tamano.set_title(_("Tamaño de la letra"))
        tamano.set_subtitle(_("También se cambia en vivo, en la ventana principal"))
        tamano.set_value(float(self.ajustes["tamano"]))
        tamano.connect("notify::value", lambda fila, *_: self.ventana.escala_tamano.set_value(fila.get_value()))
        grupo.add(tamano)

        lineas = Adw.SpinRow.new_with_range(0, 12, 1)
        lineas.set_title(_("Máximo de líneas por pantalla"))
        lineas.set_subtitle(_("Las estrofas largas se reparten en varias pantallas. 0 = sin límite"))
        lineas.set_value(int(self.ajustes["max_lineas"]))

        def cambio_lineas(fila, *_):
            self.ajustes["max_lineas"] = int(fila.get_value())
            self.ventana.lineas_cambiaron()

        lineas.connect("notify::value", cambio_lineas)
        grupo.add(lineas)

        for clave, titulo, subtitulo in (
                ("mayusculas", _("Todo en mayúsculas"), None),
                ("mostrar_referencia", _("Mostrar la cita bíblica"), _("Abajo, en letra pequeña")),
                ("transicion", _("Cambio suave entre pantallas"), None)):
            fila = Adw.SwitchRow(title=titulo, subtitle=subtitulo or "", active=bool(self.ajustes[clave]))
            fila.connect("notify::active", lambda f, _p, c=clave: self._guardar_estilo(c, f.get_active()))
            grupo.add(fila)
        pagina.add(grupo)

    def _cambio_fuente(self, boton, *_):
        descripcion = boton.get_font_desc()
        if descripcion:
            descripcion.unset_fields(Pango.FontMask.SIZE)
            self._guardar_estilo("fuente", descripcion.to_string())

    def _guardar_estilo(self, clave, valor):
        self.ajustes[clave] = valor
        self.escena.estilo_cambiado()

    # ================================================================ idioma

    def _pagina_idioma(self, pagina):
        grupo = Adw.PreferencesGroup(title=_("Idioma"))
        codigos = list(idioma.IDIOMAS)
        fila = Adw.ComboRow(title=_("Idioma del programa"),
                            subtitle=_("Se aplica la próxima vez que abras el programa"),
                            model=Gtk.StringList.new([idioma.IDIOMAS[c] for c in codigos]))
        fila.set_selected(codigos.index(idioma.actual()))
        fila.connect("notify::selected", lambda f, *_: self.ajustes.__setitem__("idioma", codigos[f.get_selected()]))
        grupo.add(fila)
        pagina.add(grupo)


class _Columna(Gtk.Box):
    """Columna de grupos de ajustes (como una página de preferencias, pero más ancha y legible)."""

    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=30, margin_top=28, margin_bottom=40,
                         margin_start=28, margin_end=28)
        self.add_css_class("ajustes-grandes")

    def add(self, grupo):
        self.append(grupo)

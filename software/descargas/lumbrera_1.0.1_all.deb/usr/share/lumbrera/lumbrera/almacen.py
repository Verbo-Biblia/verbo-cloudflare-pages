"""Guardado local: canciones, ajustes y orden del culto (archivos JSON)."""

import json
import os
import shutil

from . import rutas
from .cancion import Cancion, sin_acentos


def leer_json(ruta, defecto):
    try:
        with open(ruta, encoding="utf-8") as archivo:
            return json.load(archivo)
    except (OSError, ValueError):
        return defecto


def escribir_json(ruta, datos, respaldo=False):
    ruta.parent.mkdir(parents=True, exist_ok=True)
    if respaldo and ruta.exists():
        shutil.copy2(ruta, ruta.with_suffix(ruta.suffix + ".anterior"))
    temporal = ruta.with_suffix(ruta.suffix + ".tmp")
    with open(temporal, "w", encoding="utf-8") as archivo:
        json.dump(datos, archivo, ensure_ascii=False, indent=1)
    os.replace(temporal, ruta)


class Biblioteca:
    """Las canciones del usuario más las compartidas del equipo. Avisa a quien escuche cuando algo cambia.

    Las compartidas (rutas.COMPARTIDAS) no se tocan desde aquí: si el usuario cambia una, su versión queda en su
    propio archivo y tapa a la compartida; si la borra, se anota como «eliminado» para no volver a mostrarla."""

    def __init__(self, ruta=None, compartidas=None):
        self.ruta = ruta or rutas.CANCIONES
        self.ruta_compartidas = rutas.COMPARTIDAS if compartidas is None else compartidas
        self.canciones = {}
        self.compartidas = {}
        self.ocultas = set()  # compartidas que el usuario borró
        self._oyentes = []
        self.cargar()

    def al_cambiar(self, funcion):
        self._oyentes.append(funcion)

    def quitar_oyente(self, funcion):
        if funcion in self._oyentes:
            self._oyentes.remove(funcion)

    def _avisar(self):
        for funcion in self._oyentes:
            funcion()

    @staticmethod
    def _leer(ruta):
        datos = leer_json(ruta, {})
        lista = datos.get("canciones", []) if isinstance(datos, dict) else datos
        return [r for r in (lista if isinstance(lista, list) else []) if isinstance(r, dict)]

    def cargar(self):
        self.compartidas = {}
        if self.ruta_compartidas:
            for registro in self._leer(self.ruta_compartidas):
                if not registro.get("eliminado"):
                    cancion = Cancion.desde_dict(registro)
                    self.compartidas[cancion.id] = cancion
        # Copias: así un cambio del usuario no altera el original con el que se compara al guardar.
        self.canciones = {i: Cancion.desde_dict(c.a_dict()) for i, c in self.compartidas.items()}
        self.ocultas = set()
        for registro in self._leer(self.ruta):
            if registro.get("eliminado"):
                if registro.get("id") in self.compartidas:
                    self.ocultas.add(registro["id"])
                    self.canciones.pop(registro["id"], None)
                continue
            cancion = Cancion.desde_dict(registro)
            self.canciones[cancion.id] = cancion

    def es_compartida(self, identificador):
        return identificador in self.compartidas

    def guardar(self):
        # Al archivo del usuario van solo sus canciones y las compartidas que cambió.
        propias = [c.a_dict() for c in self.ordenadas()
                   if c.id not in self.compartidas or c.a_dict() != self.compartidas[c.id].a_dict()]
        propias += [{"id": i, "eliminado": True} for i in sorted(self.ocultas)]
        escribir_json(self.ruta, {"version": 2, "canciones": propias}, respaldo=True)
        self._avisar()

    def ordenadas(self):
        return sorted(self.canciones.values(), key=lambda c: sin_acentos(c.titulo))

    def obtener(self, identificador):
        return self.canciones.get(identificador)

    def poner(self, cancion):
        self.canciones[cancion.id] = cancion
        self.guardar()

    def quitar(self, identificador):
        if self.canciones.pop(identificador, None):
            if identificador in self.compartidas:
                self.ocultas.add(identificador)
            self.guardar()

    def buscar(self, consulta):
        palabras = sin_acentos(consulta).split()
        if not palabras:
            return self.ordenadas()
        en_titulo, en_letra = [], []
        for cancion in self.ordenadas():
            cabecera = sin_acentos(f"{cancion.titulo} {cancion.autor}")
            if all(p in cabecera for p in palabras):
                en_titulo.append(cancion)
            elif all(p in cabecera or p in sin_acentos(cancion.letra) for p in palabras):
                en_letra.append(cancion)
        return en_titulo + en_letra

    def exportar(self, ruta):
        """Mismo formato que el proyector web, más la letra completa."""
        canciones = []
        for cancion in self.ordenadas():
            registro = cancion.a_respaldo_web()
            registro["letra"] = cancion.letra
            canciones.append(registro)
        escribir_json(ruta, {"version": 1, "programa": "Lumbrera", "canciones": canciones})
        return len(canciones)

    def importar(self, ruta):
        """Agrega o actualiza canciones desde un respaldo. Devuelve cuántas entraron."""
        with open(ruta, encoding="utf-8") as archivo:
            datos = json.load(archivo)
        lista = datos.get("canciones") if isinstance(datos, dict) else datos
        if not isinstance(lista, list):
            raise ValueError("formato no reconocido")
        cantidad = 0
        for registro in lista:
            if isinstance(registro, dict) and not registro.get("eliminado") and registro.get("titulo"):
                cancion = Cancion.desde_dict(registro)
                self.canciones[cancion.id] = cancion
                cantidad += 1
        if cantidad:
            self.guardar()
        return cantidad


AJUSTES_POR_DEFECTO = {
    "idioma": "",
    "pantalla": "auto",
    "proyectar_al_conectar": True,
    "fuente": "Noto Sans Semi-Bold",
    "tamano": 7.0,
    "max_lineas": 0,
    "mostrar_referencia": True,
    "transicion": True,
    "mayusculas": False,
    "fondo": {"tipo": "color", "valor": "#000000"},
    "biblia_a": "rv-verbo",
    "biblia_b": "",
    "biblia_libro": 43,
    "biblia_capitulo": 1,
    "volumen": 0.8,
}


class Ajustes:
    def __init__(self, ruta=None):
        self.ruta = ruta or rutas.AJUSTES
        datos = leer_json(self.ruta, {})
        self.valores = dict(AJUSTES_POR_DEFECTO)
        if isinstance(datos, dict):
            self.valores.update({k: v for k, v in datos.items() if k in AJUSTES_POR_DEFECTO})

    def __getitem__(self, clave):
        return self.valores.get(clave, AJUSTES_POR_DEFECTO.get(clave))

    def __setitem__(self, clave, valor):
        self.valores[clave] = valor
        escribir_json(self.ruta, self.valores)

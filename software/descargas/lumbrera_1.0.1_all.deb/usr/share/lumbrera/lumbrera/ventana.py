"""Ventana principal, en tres columnas:

    ┌ Canciones / Biblia ┬ orden del culto ──────┬ pantallas del elemento elegido ┬ ▼ ▲ ┐
    │ (todo el alto)     ├ controles: negro,     ├ vista previa grande ──────────────────┤
    │                    │ letra, fondo, medios  │                                       │
"""

from pathlib import Path

import cairo
from gi.repository import Adw, Gdk, GdkPixbuf, Gio, GLib, Gtk

from . import NOMBRE
from .biblia import rangos
from .escena import FONDOS, color_rgb, fondos_de_imagen
from .idioma import _
from .lienzo import Encuadre, Lienzo
from .panel_biblia import PanelBiblia
from .panel_canciones import PanelCanciones
from .panel_orden import EXTENSIONES, PanelOrden
from .configuracion import Configuracion
from .proyeccion import VentanaProyeccion, es_interno, id_monitor, monitores, nombre_monitor
from .vista_diapositivas import VistaDiapositivas

TECLAS_SIGUIENTE = {Gdk.KEY_Right, Gdk.KEY_space, Gdk.KEY_Page_Down, Gdk.KEY_KP_Right, Gdk.KEY_KP_Page_Down}
TECLAS_ANTERIOR = {Gdk.KEY_Left, Gdk.KEY_Page_Up, Gdk.KEY_KP_Left, Gdk.KEY_KP_Page_Up, Gdk.KEY_BackSpace}
TECLAS_NEGRO = {Gdk.KEY_b, Gdk.KEY_B, Gdk.KEY_period}


class VentanaPrincipal(Adw.ApplicationWindow):
    def __init__(self, aplicacion):
        super().__init__(application=aplicacion, title=NOMBRE, default_width=1400, default_height=860)
        self.ajustes = aplicacion.ajustes
        self.biblioteca = aplicacion.biblioteca
        self.escena = aplicacion.escena
        self.proyeccion = None
        self.mostrado = {"diapositivas": [], "titulo": "", "subtitulo": "", "cancion": None, "orden": -1}
        self.vivo = None  # {"diapositivas", "indice", "orden"}

        self.avisos = Adw.ToastOverlay()
        vista = Adw.ToolbarView()
        self.avisos.set_child(vista)
        self.set_content(self.avisos)
        vista.add_top_bar(self._barra_superior())

        self.panel_canciones = PanelCanciones(self.biblioteca)
        self.panel_biblia = PanelBiblia(self.ajustes)
        self.vista = VistaDiapositivas()
        self.orden = PanelOrden(self.biblioteca, self)

        paginas = Adw.ViewStack()
        paginas.add_titled_with_icon(self.panel_canciones, "canciones", _("Canciones"), "eb-musica-symbolic")
        paginas.add_titled_with_icon(self.panel_biblia, "biblia", _("Biblia"), "eb-biblia-symbolic")
        self.paginas = paginas
        selector = Adw.ViewSwitcher(stack=paginas, policy=Adw.ViewSwitcherPolicy.WIDE)
        selector.set_margin_top(8)
        selector.set_margin_bottom(8)
        selector.set_margin_start(10)
        selector.set_margin_end(10)
        columna1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        columna1.add_css_class("columna-biblioteca")
        columna1.append(selector)
        columna1.append(paginas)
        paginas.set_vexpand(True)

        orden = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin_start=10, margin_end=10, margin_top=10,
                        margin_bottom=8)
        orden.append(self.orden)
        self.orden.set_vexpand(True)
        orden.append(self._botones_agregar())
        controles = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
        controles.set_child(self._panel_controles())
        columna2 = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL, start_child=orden, end_child=controles,
                             shrink_start_child=False, shrink_end_child=False)
        columna2.add_css_class("columna-orden")

        pantallas = Gtk.Box()
        pantallas.append(self.vista)
        self.vista.set_hexpand(True)
        columna3 = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL, start_child=pantallas,
                             end_child=self._zona_previa(), shrink_start_child=False, shrink_end_child=False)

        derecha = Gtk.Paned(start_child=columna2, end_child=columna3, resize_start_child=False,
                            shrink_start_child=False, shrink_end_child=False, position=310)
        principal = Gtk.Paned(start_child=columna1, end_child=derecha, resize_start_child=False,
                              shrink_start_child=False, shrink_end_child=False, position=400)
        # Dos modos que ocupan toda la ventana: el culto y la configuración.
        self.modos = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE)
        self.modos.add_named(principal, "culto")
        self.panel_configuracion = Configuracion(self)
        self.modos.add_named(self.panel_configuracion, "configuracion")
        vista.set_content(self.modos)

        def posiciones():
            columna2.set_position(int(columna2.get_height() * 0.38))
            columna3.set_position(int(columna3.get_height() * 0.5))
            return GLib.SOURCE_REMOVE

        GLib.idle_add(posiciones)

        # ---------------- conexiones
        self.panel_canciones.connect("abrir", lambda _p, c: self.abrir_cancion(c))
        self.panel_canciones.connect("agregar", lambda _p, c: self._agregar_cancion(c))
        self.panel_canciones.connect("buscar-web", lambda _p, texto: self.editar_cancion(None, busqueda=texto))
        self.panel_biblia.connect("agregar", lambda _p, titulo, diapositivas: self._agregar_pasaje(titulo, diapositivas))
        self.vista.connect("proyectar", lambda _v, i: self.proyectar_indice(i))
        self.vista.connect("agregar-todo", lambda *_: self._agregar_mostrado())
        self.vista.connect("agregar", lambda _v, indices: self._agregar_partes(indices))
        self.vista.connect("editar", lambda *_: self.editar_cancion(self.biblioteca.obtener(self.mostrado["cancion"])))
        # Clic en el orden: canciones y pasajes muestran sus pantallas; imagen, video y audio salen al instante.
        self.orden.connect("elegir", lambda _o, i: self.elegir_orden(i))
        self.orden.al_soltar_texto = self._soltado_en_orden
        self.biblioteca.al_cambiar(self._biblioteca_cambio)
        self.escena.connect("cambio", self._escena_cambio)
        monitores_lista = Gdk.Display.get_default().get_monitors()
        monitores_lista.connect("items-changed", self._monitores_cambiaron)

        self._acciones()
        teclas = Gtk.EventControllerKey(propagation_phase=Gtk.PropagationPhase.CAPTURE)
        teclas.connect("key-pressed", self._tecla)
        self.add_controller(teclas)
        self.connect("close-request", self._al_cerrar)
        self._actualizar_estado()
        if not self.biblioteca.canciones:
            GLib.idle_add(lambda: self.panel_canciones.buscador.grab_focus() and False)
        self._monitor_proyeccion = None
        self._revision_pendiente = GLib.timeout_add(1500, self._revisar_pantallas)

    # ================================================================ armado

    def _barra_superior(self):
        barra = Adw.HeaderBar()

        self.titulo = Adw.WindowTitle(title=NOMBRE, subtitle=_("Proyector para iglesias"))
        barra.set_title_widget(self.titulo)

        menu = Gio.Menu()
        seccion = Gio.Menu()
        seccion.append(_("Configuración"), "app.preferencias")
        seccion.append(_("Atajos de teclado"), "app.atajos")
        menu.append_section(None, seccion)
        seccion = Gio.Menu()
        seccion.append(_("Acerca de {app}").format(app=NOMBRE), "app.acerca")
        menu.append_section(None, seccion)
        barra.pack_end(Gtk.MenuButton(icon_name="open-menu-symbolic", menu_model=menu, primary=True,
                                      tooltip_text=_("Menú")))
        self.boton_configurar = Gtk.Button(tooltip_text=_("Cancionero, Biblias, pantalla e idioma"))
        self.boton_configurar.set_child(Adw.ButtonContent(icon_name="eb-ajustes-symbolic", label=_("Configuración")))
        self.boton_configurar.set_action_name("app.preferencias")
        barra.pack_end(self.boton_configurar)
        self.boton_volver = Gtk.Button(visible=False, tooltip_text=_("Volver a la pantalla del culto"))
        self.boton_volver.set_child(Adw.ButtonContent(icon_name="go-previous-symbolic", label=_("Volver al culto")))
        self.boton_volver.add_css_class("suggested-action")
        self.boton_volver.connect("clicked", lambda *_: self.volver_al_culto())
        barra.pack_start(self.boton_volver)
        return barra

    def _botonera(self):
        """Siguiente y Anterior al lado de las pantallas."""
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_start=4, margin_end=10,
                       margin_top=10, margin_bottom=10)
        caja.add_css_class("botonera")
        siguiente = self._boton_vertical(_("Siguiente"), "go-down-symbolic", "win.siguiente")
        siguiente.add_css_class("suggested-action")
        caja.append(siguiente)
        caja.append(self._boton_vertical(_("Anterior"), "go-up-symbolic", "win.anterior"))
        return caja

    def _boton_vertical(self, texto, icono, accion):
        boton = Gtk.Button(action_name=accion, tooltip_text=texto)
        contenido = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        contenido.append(Gtk.Image(icon_name=icono, pixel_size=20))
        etiqueta = Gtk.Label(label=texto, wrap=True, justify=Gtk.Justification.CENTER, max_width_chars=9)
        etiqueta.add_css_class("caption")
        contenido.append(etiqueta)
        boton.set_child(contenido)
        boton.add_css_class("boton-vertical")
        return boton

    def _zona_previa(self):
        caja = Gtk.Box(margin_start=12, margin_end=12, margin_top=10, margin_bottom=12)
        previa = Gtk.Overlay()
        previa.set_child(Lienzo(self.escena))
        self.insignia = Gtk.Label(halign=Gtk.Align.START, valign=Gtk.Align.START, margin_start=8, margin_top=8)
        self.insignia.add_css_class("insignia")
        previa.add_overlay(self.insignia)
        previa.add_css_class("vista-previa")
        caja.append(Encuadre(previa))
        return caja

    def _panel_controles(self):
        """Columna 2, abajo: lo que se usa en vivo sin ir a Preferencias."""
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin_start=10, margin_end=10,
                       margin_top=8, margin_bottom=10)
        caja.add_css_class("panel-controles")

        pantalla = Gtk.Box(spacing=6, homogeneous=True)
        self.boton_negro = self._boton_grande(_("Pantalla negra"), "eb-negro-symbolic", "win.negro")
        pantalla.append(self.boton_negro)
        pantalla.append(self._boton_grande(_("Quitar texto"), "edit-clear-symbolic", "win.limpiar"))
        caja.append(pantalla)

        tamano = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        etiqueta = Gtk.Label(label=_("Cambiar el tamaño de la letra"), xalign=0)
        etiqueta.add_css_class("heading")
        tamano.append(etiqueta)
        fila = Gtk.Box(spacing=8)
        fila.append(Gtk.Label(label="A", tooltip_text=_("Más pequeña")))
        self.escala_tamano = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 3, 14, 0.5)
        self.escala_tamano.set_hexpand(True)
        self.escala_tamano.add_css_class("fader")
        self.escala_tamano.set_value(float(self.ajustes["tamano"]))
        self.escala_tamano.connect("value-changed", self._cambio_tamano)
        fila.append(self.escala_tamano)
        grande = Gtk.Label(label="A", tooltip_text=_("Más grande"))
        grande.add_css_class("title-2")
        fila.append(grande)
        tamano.append(fila)
        caja.append(tamano)

        caja.append(self._selector_fondo())

        medio = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        medio.add_css_class("fila-medio")
        etiqueta = Gtk.Label(label=_("Audio y video"), xalign=0)
        etiqueta.add_css_class("heading")
        medio.append(etiqueta)
        arriba = Gtk.Box(spacing=8)
        self.boton_reproducir = Gtk.Button(icon_name="media-playback-start-symbolic", tooltip_text=_("Reproducir"))
        self.boton_reproducir.add_css_class("circular")
        self.boton_reproducir.connect("clicked", lambda *_: self._alternar_reproduccion())
        arriba.append(self.boton_reproducir)
        self.nombre_medio = Gtk.Label(xalign=0, ellipsize=3, hexpand=True, label=_("Nada sonando"))
        self.nombre_medio.add_css_class("caption")
        arriba.append(self.nombre_medio)
        medio.append(arriba)
        etiqueta = Gtk.Label(label=_("Volumen"), xalign=0, margin_top=4)
        etiqueta.add_css_class("heading")
        medio.append(etiqueta)
        abajo = Gtk.Box(spacing=6)
        abajo.append(Gtk.Image(icon_name="audio-volume-low-symbolic"))
        volumen = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 1, 0.05)
        volumen.set_value(float(self.ajustes["volumen"]))
        volumen.set_hexpand(True)
        volumen.add_css_class("fader")
        volumen.connect("value-changed", lambda escala: self.escena.poner_volumen(escala.get_value()))
        abajo.append(volumen)
        abajo.append(Gtk.Image(icon_name="audio-volume-high-symbolic"))
        medio.append(abajo)
        caja.append(medio)

        # Botón grande para abrir o cerrar la pantalla que ve la congregación.
        self.boton_proyectar = Gtk.Button(action_name="win.proyectar", tooltip_text=_("Atajo: F5"))
        self.boton_proyectar.add_css_class("boton-proyectar")
        contenido = Gtk.Box(spacing=12, halign=Gtk.Align.CENTER)
        contenido.append(Gtk.Image(icon_name="eb-proyectar-symbolic", pixel_size=26))
        self.texto_proyectar = Gtk.Label()
        contenido.append(self.texto_proyectar)
        self.boton_proyectar.set_child(contenido)
        caja.append(self.boton_proyectar)
        self.controles_medio = medio
        return caja

    def _botones_agregar(self):
        """Debajo del orden del culto: agregar MP3, video o imagen."""
        agregar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_top=8)
        etiqueta = Gtk.Label(label=_("Agregar al orden"), xalign=0)
        etiqueta.add_css_class("heading")
        agregar.append(etiqueta)
        botones = Gtk.Box(spacing=6, homogeneous=True)
        for texto, icono, tipo in ((_("MP3"), "eb-audio-symbolic", "audio"), (_("Video"), "eb-video-symbolic", "video"),
                                   (_("Imagen"), "eb-imagen-symbolic", "imagen")):
            boton = Gtk.Button()
            boton.set_child(Adw.ButtonContent(icon_name=icono, label=texto))
            boton.connect("clicked", lambda _b, t=tipo: self._elegir_archivos_orden(t))
            botones.append(boton)
        agregar.append(botones)
        return agregar

    def _cambio_tamano(self, escala):
        self.ajustes["tamano"] = round(escala.get_value(), 1)
        self.escena.estilo_cambiado()

    def _boton_grande(self, texto, icono, accion):
        boton = Gtk.Button(action_name=accion)
        boton.set_child(Adw.ButtonContent(icon_name=icono, label=texto))
        boton.add_css_class("boton-control")
        return boton

    def _selector_fondo(self):
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        etiqueta = Gtk.Label(label=_("Fondo de color"), xalign=0)
        etiqueta.add_css_class("heading")
        caja.append(etiqueta)
        colores = Gtk.Box(spacing=4)
        self._muestras = {}
        for clave, nombre, fondo in FONDOS:
            boton = Gtk.Button(tooltip_text=_(nombre), valign=Gtk.Align.CENTER)
            boton.add_css_class("muestra-fondo")
            dibujo = Gtk.DrawingArea(content_width=22, content_height=22)
            dibujo.set_draw_func(self._dibujar_muestra, fondo)
            boton.set_child(dibujo)
            boton.connect("clicked", lambda _b, f=fondo: self.escena.poner_fondo(f))
            self._muestras[clave] = (boton, fondo)
            colores.append(boton)
        caja.append(colores)

        imagenes = fondos_de_imagen()
        if imagenes:
            fila = Gtk.Box(spacing=4)
            for clave, nombre, fondo in imagenes:
                boton = Gtk.Button(tooltip_text=_(nombre), valign=Gtk.Align.CENTER)
                boton.add_css_class("muestra-imagen")
                # Miniatura ya reducida: así no pide el tamaño completo de la foto.
                miniatura = GdkPixbuf.Pixbuf.new_from_file_at_scale(fondo["valor"], 64, 36, True)
                foto = Gtk.Picture(content_fit=Gtk.ContentFit.COVER, can_shrink=True,
                                   paintable=Gdk.Texture.new_for_pixbuf(miniatura))
                foto.set_size_request(40, 24)
                foto.set_overflow(Gtk.Overflow.HIDDEN)
                boton.set_child(foto)
                boton.connect("clicked", lambda _b, f=fondo: self.escena.poner_fondo(f))
                self._muestras[clave] = (boton, fondo)
                fila.append(boton)
            etiqueta = Gtk.Label(label=_("Fondo con imagen"), xalign=0, margin_top=4)
            etiqueta.add_css_class("heading")
            caja.append(etiqueta)
            caja.append(fila)
        archivo = Gtk.Button(tooltip_text=_("Usar una foto o un video tuyo como fondo"))
        archivo.set_child(Adw.ButtonContent(icon_name="document-open-symbolic",
                                            label=_("Cargar imagen o video de la computadora")))
        archivo.connect("clicked", lambda *_: self._elegir_fondo_archivo())
        caja.append(archivo)
        self._marcar_fondo()
        return caja

    @staticmethod
    def _dibujar_muestra(_area, cr, ancho, alto, fondo):
        if fondo["tipo"] == "degradado":
            degradado = cairo.LinearGradient(0, 0, ancho, alto)
            degradado.add_color_stop_rgb(0, *color_rgb(fondo["valor"][0]))
            degradado.add_color_stop_rgb(1, *color_rgb(fondo["valor"][1]))
            cr.set_source(degradado)
        else:
            cr.set_source_rgb(*color_rgb(fondo["valor"]))
        cr.arc(ancho / 2, alto / 2, min(ancho, alto) / 2, 0, 6.2832)
        cr.fill()

    def _marcar_fondo(self):
        for boton, fondo in self._muestras.values():
            if fondo == self.escena.fondo:
                boton.add_css_class("elegida")
            else:
                boton.remove_css_class("elegida")

    # ================================================================ acciones

    def _acciones(self):
        for nombre, funcion in (("siguiente", self.siguiente), ("anterior", self.anterior),
                                ("negro", self.alternar_negro), ("limpiar", self.quitar_texto),
                                ("proyectar", self.alternar_proyeccion), ("nueva-cancion", lambda: self.editar_cancion(None)),
                                ("buscar", self._enfocar_busqueda), ("culto-nuevo", self._culto_nuevo),
                                ("culto-abrir", self._culto_abrir), ("culto-guardar", self._culto_guardar),
                                ("culto-guardar-como", self._culto_guardar_como),
                                ("orden-agregar-archivo", self._elegir_archivos_orden)):
            accion = Gio.SimpleAction.new(nombre, None)
            accion.connect("activate", lambda _a, _p, f=funcion: f())
            self.add_action(accion)

    def _escribiendo(self):
        widget = self.get_focus()
        while widget is not None:
            if isinstance(widget, (Gtk.Editable, Gtk.TextView, Gtk.Popover, Gtk.DropDown)):
                return True
            widget = widget.get_parent()
        return False

    def _tecla(self, _controlador, tecla, _codigo, estado):
        if estado & (Gdk.ModifierType.CONTROL_MASK | Gdk.ModifierType.ALT_MASK):
            return False
        if self.modos.get_visible_child_name() == "configuracion":
            return False  # en Configuración las teclas son para escribir
        if tecla in (Gdk.KEY_Page_Down, Gdk.KEY_Page_Up):  # los controles de presentación usan estas
            return self.tecla_operador(tecla, estado)
        if self._escribiendo():
            return False
        if tecla in (Gdk.KEY_Down, Gdk.KEY_Up) and self._foco_en(self.vista):
            # Como en VideoPsalm: ↓ y ↑ recorren las pantallas cuando se está en esa lista.
            self.siguiente() if tecla == Gdk.KEY_Down else self.anterior()
            return True
        return self.tecla_operador(tecla, estado)

    def _foco_en(self, contenedor):
        widget = self.get_focus()
        while widget is not None:
            if widget is contenedor:
                return True
            widget = widget.get_parent()
        return False

    def tecla_operador(self, tecla, _estado=None):
        if tecla in TECLAS_SIGUIENTE:
            self.siguiente()
        elif tecla in TECLAS_ANTERIOR:
            self.anterior()
        elif tecla in TECLAS_NEGRO:
            self.alternar_negro()
        elif tecla == Gdk.KEY_Escape:
            self.quitar_texto()
        elif tecla == Gdk.KEY_F5:
            self.alternar_proyeccion()
        else:
            return False
        return True

    def _enfocar_busqueda(self):
        self.paginas.set_visible_child_name("canciones")
        self.panel_canciones.buscador.grab_focus()

    # ================================================================ contenido

    def _max_lineas(self):
        return int(self.ajustes["max_lineas"])

    def abrir_cancion(self, cancion, orden=-1):
        self.mostrado = {"diapositivas": cancion.diapositivas(self._max_lineas()), "titulo": cancion.titulo,
                         "subtitulo": cancion.autor, "cancion": cancion.id, "orden": orden}
        self.vista.mostrar(self.mostrado["diapositivas"], cancion.titulo, cancion.autor, es_cancion=True,
                           se_puede_agregar=orden < 0)
        self._marcar_vivo()

    def _agregar_cancion(self, cancion):
        self.orden.agregar_cancion(cancion)
        self._avisar(_("«{titulo}» se agregó al orden del culto.").format(titulo=cancion.titulo))

    def _agregar_pasaje(self, titulo, diapositivas):
        self.orden.agregar_pasaje(titulo, diapositivas)
        self._avisar(_("«{titulo}» se agregó al orden del culto.").format(titulo=titulo))

    def _agregar_mostrado(self):
        if self.mostrado["cancion"]:
            cancion = self.biblioteca.obtener(self.mostrado["cancion"])
            if cancion:
                self._agregar_cancion(cancion)
        elif self.mostrado["diapositivas"]:
            self._agregar_pasaje(self.mostrado["titulo"], self.mostrado["diapositivas"])

    def _agregar_partes(self, indices):
        """Agrega al orden algunas pantallas de lo que se ve al centro, juntas en un solo elemento."""
        lista = self.mostrado["diapositivas"]
        elegidas = [lista[i] for i in indices if 0 <= i < len(lista)]
        if not elegidas:
            return
        if self.mostrado["cancion"]:
            titulo = self.mostrado["titulo"]
            if len(elegidas) < len(lista):
                titulo += " (" + ", ".join(d.etiqueta for d in elegidas) + ")"
            self._agregar_pasaje(titulo, elegidas)
            return
        # Versículos: «Juan 3:16-18, 20» a partir de la cita de cada uno.
        base = elegidas[0].referencia.split(" · ")[0].rsplit(":", 1)[0]
        numeros = [int(d.etiqueta.split()[-1]) for d in elegidas if d.etiqueta.split()[-1].isdigit()]
        titulo = f"{base}:{rangos(numeros)}" if numeros else self.mostrado["titulo"]
        self._agregar_pasaje(titulo, elegidas)

    def _soltado_en_orden(self, texto):
        """Algo se soltó sobre el orden del culto: versículos marcados o una canción."""
        if texto == "lumbrera:pasaje":
            actual = self.panel_biblia.seleccion()
            if actual:
                self._agregar_pasaje(*actual)
                return True
        elif texto.startswith("lumbrera:cancion:"):
            cancion = self.biblioteca.obtener(texto.split(":", 2)[2])
            if cancion:
                self._agregar_cancion(cancion)
                return True
        return False

    def editar_cancion(self, cancion, busqueda=""):
        self.configuracion("cancionero")
        self.panel_configuracion.editor.cargar(cancion, busqueda)
        self.panel_configuracion.marcar_cancion(cancion)

    def _biblioteca_cambio(self):
        identificador = self.mostrado["cancion"]
        if not identificador:
            return
        cancion = self.biblioteca.obtener(identificador)
        if cancion is None:
            self.mostrado = {"diapositivas": [], "titulo": "", "subtitulo": "", "cancion": None, "orden": -1}
            self.vista.mostrar([], "", "")
            return
        anterior = self.mostrado["diapositivas"]
        self.abrir_cancion(cancion, self.mostrado["orden"])
        if self.vivo and self.vivo["diapositivas"] is anterior:
            self.vivo["diapositivas"] = self.mostrado["diapositivas"]
            self.vivo["indice"] = min(self.vivo["indice"], len(self.mostrado["diapositivas"]) - 1)
            self._marcar_vivo()
        self.orden.actualizar()

    def lineas_cambiaron(self):
        if self.mostrado["cancion"]:
            self._biblioteca_cambio()

    # ================================================================ orden del culto

    def elegir_orden(self, indice, proyectar=None):
        if not 0 <= indice < len(self.orden.elementos):
            return
        elemento = self.orden.elementos[indice]
        self.orden.marcar_actual(indice)
        tipo = elemento["tipo"]
        if tipo in ("cancion", "pasaje"):
            diapositivas = self.orden.diapositivas(indice, self._max_lineas())
            self.mostrado = {"diapositivas": diapositivas, "titulo": elemento.get("titulo", ""),
                             "subtitulo": elemento.get("subtitulo", ""),
                             "cancion": elemento.get("cancion") if tipo == "cancion" else None, "orden": indice}
            self.vista.mostrar(diapositivas, self.mostrado["titulo"], self.mostrado["subtitulo"],
                               es_cancion=tipo == "cancion", se_puede_agregar=False)
            if diapositivas and proyectar == "primera":
                self.proyectar_indice(0)
            elif diapositivas and proyectar == "ultima":
                self.proyectar_indice(len(diapositivas) - 1)
            else:
                self._marcar_vivo()
            return
        try:
            if tipo == "audio":
                self.escena.reproducir_audio(elemento["ruta"])
            else:
                self.escena.mostrar_medio(elemento["ruta"], tipo)
        except GLib.Error:
            self._avisar(_("No se pudo abrir «{nombre}».").format(nombre=elemento.get("titulo", "")))
            return
        self.vivo = {"diapositivas": [], "indice": -1, "orden": indice, "titulo": elemento.get("titulo", ""),
                     "subtitulo": elemento.get("subtitulo", "")}
        self._marcar_vivo()

    def _elegir_archivos_orden(self, tipo=None):
        titulos = {"audio": _("Agregar MP3 o audio"), "video": _("Agregar video"), "imagen": _("Agregar imagen")}
        dialogo = Gtk.FileDialog(title=titulos.get(tipo, _("Agregar imagen, video o audio")))
        filtro = Gtk.FileFilter(name=titulos.get(tipo, _("Imágenes, videos y audios")))
        for clave, extensiones in EXTENSIONES.items():
            if tipo in (None, clave):
                for patron in extensiones:
                    filtro.add_suffix(patron[2:])
        filtros = Gio.ListStore.new(Gtk.FileFilter)
        filtros.append(filtro)
        dialogo.set_filters(filtros)

        def elegidos(dialogo, resultado):
            try:
                archivos = dialogo.open_multiple_finish(resultado)
            except GLib.Error:
                return
            for i in range(archivos.get_n_items()):
                self.orden.agregar_archivo(archivos.get_item(i).get_path())

        dialogo.open_multiple(self, None, elegidos)

    # ================================================================ guardar y abrir cultos

    @staticmethod
    def _carpeta_cultos():
        documentos = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOCUMENTS) or GLib.get_home_dir()
        carpeta = Path(documentos) / "Lumbrera"
        carpeta.mkdir(parents=True, exist_ok=True)
        return carpeta

    def _filtro_cultos(self):
        filtro = Gtk.FileFilter(name=_("Cultos de Lumbrera"))
        filtro.add_suffix("lumbrera")
        filtros = Gio.ListStore.new(Gtk.FileFilter)
        filtros.append(filtro)
        return filtros

    def _culto_guardar(self):
        if self.modos.get_visible_child_name() == "configuracion":
            self.panel_configuracion.editor._guardar()  # Ctrl + S en el editor guarda la canción
            return
        ruta = Path(self.orden.ruta) if self.orden.ruta else None
        if ruta is None or not ruta.parent.is_dir():
            nombre = _("Culto {fecha}").format(fecha=GLib.DateTime.new_now_local().format("%Y-%m-%d"))
            ruta = self._carpeta_cultos() / f"{nombre}.lumbrera"
            numero = 2
            while ruta.exists():
                ruta = self._carpeta_cultos() / f"{nombre} ({numero}).lumbrera"
                numero += 1
        try:
            self.orden.guardar_en(ruta, self.orden.nombre or ruta.stem)
        except OSError as error:
            self._avisar(_("No se pudo guardar: {error}").format(error=error.strerror or error))
            return
        self._avisar(_("Culto guardado en {lugar}.").format(lugar=self._ruta_corta(ruta)))

    def _culto_guardar_como(self):
        nombre = self.orden.nombre or _("Culto {fecha}").format(fecha=GLib.DateTime.new_now_local().format("%Y-%m-%d"))
        dialogo = Gtk.FileDialog(title=_("Guardar el culto como…"), filters=self._filtro_cultos(),
                                 initial_name=f"{nombre}.lumbrera",
                                 initial_folder=Gio.File.new_for_path(str(self._carpeta_cultos())))

        def elegido(dialogo, resultado):
            try:
                ruta = Path(dialogo.save_finish(resultado).get_path())
            except GLib.Error:
                return
            if ruta.suffix.lower() != ".lumbrera":
                ruta = ruta.with_name(ruta.name + ".lumbrera")
            try:
                self.orden.guardar_en(ruta, ruta.stem)
            except OSError as error:
                self._avisar(_("No se pudo guardar: {error}").format(error=error.strerror or error))
                return
            self._avisar(_("Culto guardado en {lugar}.").format(lugar=self._ruta_corta(ruta)))

        dialogo.save(self, None, elegido)

    def _culto_abrir(self):
        dialogo = Gtk.FileDialog(title=_("Abrir un culto"), filters=self._filtro_cultos(),
                                 initial_folder=Gio.File.new_for_path(str(self._carpeta_cultos())))

        def elegido(dialogo, resultado):
            try:
                ruta = dialogo.open_finish(resultado).get_path()
            except GLib.Error:
                return
            try:
                self.orden.abrir(ruta)
            except Exception:
                self._avisar(_("Ese archivo no es un culto de Lumbrera."))
                return
            self._avisar(_("Se abrió «{nombre}».").format(nombre=self.orden.nombre))

        dialogo.open(self, None, elegido)

    def _culto_nuevo(self):
        if not self.orden.elementos:
            self.orden.nuevo()
            return
        dialogo = Adw.AlertDialog(heading=_("¿Empezar un culto nuevo?"),
                                  body=_("La lista actual se vacía. Si la guardaste, puedes volver a abrirla. "
                                         "Tus canciones no se borran."))
        dialogo.add_response("no", _("Cancelar"))
        dialogo.add_response("guardar", _("Guardar y empezar"))
        dialogo.add_response("si", _("Empezar sin guardar"))
        dialogo.set_response_appearance("guardar", Adw.ResponseAppearance.SUGGESTED)
        dialogo.set_response_appearance("si", Adw.ResponseAppearance.DESTRUCTIVE)
        dialogo.set_close_response("no")

        def respuesta(_d, opcion):
            if opcion == "guardar":
                self._culto_guardar()
            if opcion in ("guardar", "si"):
                self.orden.nuevo()

        dialogo.connect("response", respuesta)
        dialogo.present(self)

    @staticmethod
    def _ruta_corta(ruta):
        casa = Path.home()
        try:
            return str(Path(ruta).relative_to(casa))
        except ValueError:
            return str(ruta)

    # ================================================================ en pantalla

    def proyectar_indice(self, indice):
        lista = self.mostrado["diapositivas"]
        if not 0 <= indice < len(lista):
            return
        self.vivo = {"diapositivas": lista, "indice": indice, "orden": self.mostrado["orden"],
                     "titulo": self.mostrado["titulo"], "subtitulo": self.mostrado["subtitulo"]}
        self.escena.mostrar(lista[indice])
        self._marcar_vivo()

    def _mostrar_vivo(self, indice):
        self.vivo["indice"] = indice
        self.escena.mostrar(self.vivo["diapositivas"][indice])
        self._marcar_vivo()

    def siguiente(self):
        vivo = self.vivo
        mostrado = self.mostrado["diapositivas"]
        # Nada en vivo todavía, o se eligió otra cosa y la pantalla está sin texto: empieza lo que se ve al centro.
        if vivo is None or (self.escena.modo == "vacio" and mostrado and vivo["diapositivas"] is not mostrado):
            if mostrado:
                self.proyectar_indice(0)
            elif self.orden.elementos:
                self.elegir_orden(min(self.orden.actual + 1, len(self.orden.elementos) - 1), proyectar="primera")
            return
        # Después de «Pantalla negra» o «Quitar texto», la primera pulsación vuelve a mostrar la misma pantalla.
        if self.escena.modo in ("negro", "vacio") and 0 <= vivo["indice"] < len(vivo["diapositivas"]):
            self._mostrar_vivo(vivo["indice"])
            return
        if vivo["indice"] + 1 < len(vivo["diapositivas"]):
            self._mostrar_vivo(vivo["indice"] + 1)
        elif 0 <= vivo["orden"] < len(self.orden.elementos) - 1:
            self.elegir_orden(vivo["orden"] + 1, proyectar="primera")

    def anterior(self):
        vivo = self.vivo
        if vivo is None:
            return
        if vivo["indice"] > 0:
            self._mostrar_vivo(vivo["indice"] - 1)
        elif vivo["orden"] > 0:
            self.elegir_orden(vivo["orden"] - 1, proyectar="ultima")

    def alternar_negro(self):
        if self.escena.modo == "negro":
            if self.vivo and 0 <= self.vivo["indice"] < len(self.vivo["diapositivas"]):
                self.escena.mostrar(self.vivo["diapositivas"][self.vivo["indice"]])
            else:
                self.escena.vaciar()
        else:
            self.escena.negro()

    def quitar_texto(self):
        self.escena.vaciar()
        self._marcar_vivo()

    def _marcar_vivo(self):
        en_pantalla = self.escena.modo == "texto"
        if self.vivo and en_pantalla and self.vivo["diapositivas"] is self.mostrado["diapositivas"]:
            self.vista.marcar_en_vivo(self.vivo["indice"])
        else:
            self.vista.marcar_en_vivo(-1)

    def _escena_cambio(self, _escena, que):
        if que == "fondo":
            self._marcar_fondo()
        self._marcar_vivo()
        self._actualizar_estado()

    def _actualizar_estado(self):
        modo = self.escena.modo
        proyectando = self.proyeccion is not None
        if modo == "negro":
            texto, clase = _("PANTALLA NEGRA"), "negro"
        elif not proyectando:
            texto, clase = _("VISTA PREVIA"), "apagado"
        elif modo in ("texto", "medio"):
            texto, clase = _("EN VIVO"), "vivo"
        else:
            texto, clase = _("SIN TEXTO"), "apagado"
        self.insignia.set_label(texto)
        for c in ("negro", "apagado", "vivo"):
            self.insignia.remove_css_class(c)
        self.insignia.add_css_class(clase)
        if modo == "negro":
            self.boton_negro.add_css_class("activo")
        else:
            self.boton_negro.remove_css_class("activo")

        self.texto_proyectar.set_label(_("Dejar de proyectar") if proyectando else _("Proyectar"))
        if proyectando:
            self.boton_proyectar.remove_css_class("suggested-action")
            self.boton_proyectar.add_css_class("proyectando")
        else:
            self.boton_proyectar.add_css_class("suggested-action")
            self.boton_proyectar.remove_css_class("proyectando")

        flujo = self.escena.flujo_activo()
        self.boton_reproducir.set_sensitive(flujo is not None)
        if flujo is None:
            self.nombre_medio.set_label(_("Nada sonando"))
        else:
            nombre = self.escena.medio_ruta if isinstance(self.escena.medio, Gtk.MediaStream) else self.escena.audio_ruta
            self.nombre_medio.set_label(GLib.path_get_basename(nombre or ""))
            if getattr(self, "_flujo_vigilado", None) is not flujo:
                flujo.connect("notify::playing", lambda *_: self._icono_reproduccion())
                self._flujo_vigilado = flujo
            self._icono_reproduccion()

    def _icono_reproduccion(self):
        flujo = self.escena.flujo_activo()
        sonando = bool(flujo and flujo.get_playing())
        self.boton_reproducir.set_icon_name("media-playback-pause-symbolic" if sonando
                                            else "media-playback-start-symbolic")
        self.boton_reproducir.set_tooltip_text(_("Pausa") if sonando else _("Reproducir"))

    def _alternar_reproduccion(self):
        flujo = self.escena.flujo_activo()
        if flujo is None:
            return
        if flujo.get_playing():
            flujo.pause()
        else:
            if flujo.get_ended():
                flujo.seek(0)
            flujo.play()

    def _elegir_fondo_archivo(self):
        dialogo = Gtk.FileDialog(title=_("Elegir imagen o video de fondo"))
        filtro = Gtk.FileFilter(name=_("Imágenes y videos"))
        for patron in EXTENSIONES["imagen"] + EXTENSIONES["video"]:
            filtro.add_suffix(patron[2:])
        filtros = Gio.ListStore.new(Gtk.FileFilter)
        filtros.append(filtro)
        dialogo.set_filters(filtros)

        def elegido(dialogo, resultado):
            try:
                ruta = dialogo.open_finish(resultado).get_path()
            except GLib.Error:
                return
            tipo = "video" if "*." + ruta.rsplit(".", 1)[-1].lower() in EXTENSIONES["video"] else "imagen"
            self.escena.poner_fondo({"tipo": tipo, "valor": ruta})

        dialogo.open(self, None, elegido)

    # ================================================================ proyección

    def alternar_proyeccion(self):
        if self.proyeccion is not None:
            self.proyeccion.destroy()
            self.proyeccion = None
            self._monitor_proyeccion = None
            self.titulo.set_subtitle(_("Proyector para iglesias"))
            self._actualizar_estado()
            return
        self.proyeccion = VentanaProyeccion(self.get_application(), self.escena, self.tecla_operador)
        self.proyeccion.connect("close-request", self._proyeccion_cerrada)
        self._colocar_proyeccion()
        self._actualizar_estado()

    def _proyeccion_cerrada(self, *_):
        self.proyeccion = None
        self._monitor_proyeccion = None
        self.titulo.set_subtitle(_("Proyector para iglesias"))
        self._actualizar_estado()
        return False

    def _monitor_destino(self):
        """La pantalla para proyectar: la elegida en Ajustes o, si no, otra que no sea la del operador.

        Con las pantallas en «duplicar» el sistema ve una sola, así que devuelve None (ventana pequeña).
        """
        lista = monitores()
        preferida = self.ajustes["pantalla"]
        if preferida != "auto":
            elegido = next((m for m in lista if id_monitor(m) == preferida), None)
            if elegido is not None:
                return elegido
        if len(lista) < 2:
            return None
        superficie = self.get_surface()
        actual = Gdk.Display.get_default().get_monitor_at_surface(superficie) if superficie else None
        otros = [m for m in lista if m != actual]
        externos = [m for m in otros if not es_interno(m)]
        return (externos or otros or [None])[0]

    def _colocar_proyeccion(self):
        if self.proyeccion is None:
            return
        monitor = self._monitor_destino()
        self.proyeccion.colocar(monitor)
        self._monitor_proyeccion = id_monitor(monitor) if monitor is not None else None
        if monitor is None:
            self.titulo.set_subtitle(_("Una sola pantalla: la proyección quedó en una ventana pequeña"))
        else:
            self.titulo.set_subtitle(_("Proyectando en {pantalla}").format(pantalla=nombre_monitor(monitor)))
        GLib.idle_add(lambda: self.present() and False)

    def _monitores_cambiaron(self, *_):
        # Se espera un momento: al conectar un televisor el sistema tarda en terminar de configurarlo.
        if getattr(self, "_revision_pendiente", 0):
            GLib.source_remove(self._revision_pendiente)
        self._revision_pendiente = GLib.timeout_add(900, self._revisar_pantallas)

    def _revisar_pantallas(self):
        """Proyección automática: se abre sola en la otra pantalla y vuelve a ventana pequeña si esa se apaga."""
        self._revision_pendiente = 0
        destino = self._monitor_destino()
        if self.proyeccion is None:
            if destino is not None and self.ajustes["proyectar_al_conectar"]:
                self.alternar_proyeccion()
                self._avisar(_("Se detectó otra pantalla: la proyección se abrió allí."))
            return GLib.SOURCE_REMOVE
        conectadas = [id_monitor(m) for m in monitores()]
        anterior = getattr(self, "_monitor_proyeccion", None)
        if anterior and anterior not in conectadas:
            self._monitor_proyeccion = None
            if destino is None:
                self.proyeccion.ventana_pequena()
                self.titulo.set_subtitle(_("Una sola pantalla: la proyección quedó en una ventana pequeña"))
                self._avisar(_("Se desconectó la pantalla de proyección: quedó como ventana pequeña."))
                return GLib.SOURCE_REMOVE
        if destino is not None and id_monitor(destino) != self._monitor_proyeccion:
            self._colocar_proyeccion()
            self._avisar(_("La proyección pasó a {pantalla}.").format(pantalla=nombre_monitor(destino)))
        return GLib.SOURCE_REMOVE

    def configuracion(self, pagina=None):
        """Toda la ventana pasa a Configuración."""
        if pagina:
            self.panel_configuracion.ir_a(pagina)
        self.modos.set_visible_child_name("configuracion")
        self.boton_volver.set_visible(True)
        self.boton_configurar.set_visible(False)
        self.titulo.set_subtitle(_("Configuración"))

    def volver_al_culto(self):
        def volver():
            self.modos.set_visible_child_name("culto")
            self.boton_volver.set_visible(False)
            self.boton_configurar.set_visible(True)
            self._actualizar_subtitulo()

        self.panel_configuracion.editor.confirmar_cambios(volver)

    def _actualizar_subtitulo(self):
        if self.modos.get_visible_child_name() == "configuracion":
            return
        if self.proyeccion is None:
            self.titulo.set_subtitle(_("Proyector para iglesias"))
            return
        monitor = next((m for m in monitores() if id_monitor(m) == self._monitor_proyeccion), None)
        if monitor is not None:
            self.titulo.set_subtitle(_("Proyectando en {pantalla}").format(pantalla=nombre_monitor(monitor)))
        else:
            self.titulo.set_subtitle(_("Una sola pantalla: la proyección quedó en una ventana pequeña"))

    # ================================================================ varios

    def _avisar(self, texto):
        self.avisos.add_toast(Adw.Toast(title=texto, timeout=3))

    def _al_cerrar(self, *_):
        if self.proyeccion is not None:
            self.proyeccion.destroy()
            self.proyeccion = None
        for flujo in (self.escena.medio, self.escena.audio, self.escena.fondo_imagen):
            if isinstance(flujo, Gtk.MediaStream):
                flujo.pause()
        return False

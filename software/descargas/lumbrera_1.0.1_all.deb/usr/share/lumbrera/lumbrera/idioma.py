"""Traducciones sencillas: el texto en español es la clave.

Cada idioma extra es un JSON en datos/idiomas/<código>.json que traduce
el texto en español al otro idioma. Lo que falte se muestra en español.
"""

import json
import os

from . import rutas

IDIOMAS = {"es": "Español", "en": "English", "pt": "Português"}

_actual = "es"
_traducciones = {}


def idioma_del_sistema():
    for variable in ("LANGUAGE", "LC_ALL", "LC_MESSAGES", "LANG"):
        valor = os.environ.get(variable, "")
        for parte in valor.split(":"):
            codigo = parte[:2].lower()
            if codigo in IDIOMAS:
                return codigo
        if valor and valor not in ("C", "POSIX", "C.UTF-8"):
            return "en"
    return "es"


def iniciar(codigo=None):
    global _actual, _traducciones
    _actual = codigo if codigo in IDIOMAS else idioma_del_sistema()
    _traducciones = {}
    if _actual != "es":
        try:
            with open(rutas.IDIOMAS / f"{_actual}.json", encoding="utf-8") as archivo:
                _traducciones = json.load(archivo)
        except (OSError, ValueError):
            _traducciones = {}


def actual():
    return _actual


def _(texto):
    return _traducciones.get(texto) or texto

"""Importar Biblias de otros programas: MySword, e-Sword y XML (Zefania, OSIS y «Holy Bible XML»).

Cada formato guarda el texto con «ruido» que no se debe proyectar: números Strong, morfología, notas al pie,
títulos de sección y formato (RTF o HTML). Aquí se deja solo el texto del versículo y se guarda en el formato
de Lumbrera (manifest.json + un JSON por libro) en ~/.local/share/lumbrera/biblias/.
"""

import html
import json
import re
import sqlite3
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path

from . import biblia, rutas
from .biblia import NOMBRES_PT

CODIGOS = ["GEN", "EXO", "LEV", "NUM", "DEU", "JOS", "JDG", "RUT", "1SA", "2SA", "1KI", "2KI", "1CH", "2CH", "EZR",
           "NEH", "EST", "JOB", "PSA", "PRO", "ECC", "SNG", "ISA", "JER", "LAM", "EZK", "DAN", "HOS", "JOL", "AMO",
           "OBA", "JON", "MIC", "NAM", "HAB", "ZEP", "HAG", "ZEC", "MAL", "MAT", "MRK", "LUK", "JHN", "ACT", "ROM",
           "1CO", "2CO", "GAL", "EPH", "PHP", "COL", "1TH", "2TH", "1TI", "2TI", "TIT", "PHM", "HEB", "JAS", "1PE",
           "2PE", "1JN", "2JN", "3JN", "JUD", "REV"]
OSIS = ["Gen", "Exod", "Lev", "Num", "Deut", "Josh", "Judg", "Ruth", "1Sam", "2Sam", "1Kgs", "2Kgs", "1Chr", "2Chr",
        "Ezra", "Neh", "Esth", "Job", "Ps", "Prov", "Eccl", "Song", "Isa", "Jer", "Lam", "Ezek", "Dan", "Hos", "Joel",
        "Amos", "Obad", "Jonah", "Mic", "Nah", "Hab", "Zeph", "Hag", "Zech", "Mal", "Matt", "Mark", "Luke", "John",
        "Acts", "Rom", "1Cor", "2Cor", "Gal", "Eph", "Phil", "Col", "1Thess", "2Thess", "1Tim", "2Tim", "Titus",
        "Phlm", "Heb", "Jas", "1Pet", "2Pet", "1John", "2John", "3John", "Jude", "Rev"]
EXTENSIONES = (".bbl.mybible", ".mybible", ".bblx", ".bbli", ".xml", ".osis", ".zefania")


# ================================================================ limpieza común

# Números Strong escritos como texto, con su morfología («amó G25 VAAI3S Dios»). La morfología son códigos con
# dos o más mayúsculas («VAAI3S», «NCcSMN») o una sola letra de código («C», «P», «T»); no se tocan palabras como
# «Dios» ni las preposiciones «A», «Y», «O», «E».
_STRONG_TEXTO = re.compile(
    r"\s*(?<![\w])[GH]\d{1,5}[a-z]?\b"
    r"(?:\s+(?:[GH]\d{1,5}[a-z]?|(?=[A-Za-z0-9-]*[A-Z][A-Za-z0-9-]*[A-Z0-9])[A-Za-z0-9-]{2,12}|[BCDIKNPRSTVX])"
    r"(?=[\s,.;:!?»”)]|$))*")


def _final(texto):
    texto = html.unescape(texto)
    texto = _STRONG_TEXTO.sub("", texto)
    texto = re.sub(r"\s*[*†‡]+(?=\s|[,.;:!?»”)]|$)", "", texto)  # marcas de notas al pie
    texto = texto.replace("•", " ")  # viñetas que algunos módulos usan como separador
    texto = re.sub(r"\s+([,.;:!?»”)])", r"\1", texto)
    texto = re.sub(r"([«“(])\s+", r"\1", texto)
    return " ".join(texto.split())


def _quitar_bloques(texto, etiquetas):
    for abre, cierra in etiquetas:
        texto = re.sub(rf"<{abre}\b[^>]*>.*?<{cierra}>", " ", texto, flags=re.S)
    return texto


# ================================================================ MySword (.bbl.mybible)

def limpiar_mysword(texto):
    texto = texto or ""
    # Notas (<RF>…<Rf>), títulos (<TS>…<Ts>) y superíndices se quitan con su contenido.
    texto = _quitar_bloques(texto, [("RF", "Rf"), ("TS", "Ts"), ("RX", "Rx"), ("sup", "/sup"), ("SUP", "/SUP")])
    texto = re.sub(r"<(?:CM|CL|PF\d*|PI\d*|br\s*/?)>", " ", texto, flags=re.I)
    texto = re.sub(r"<[^>]+>", "", texto)
    return _final(texto)


# ================================================================ e-Sword (.bblx en RTF, .bbli en HTML)

def _grupos_rtf_sin(texto, controles):
    """Quita los grupos {…} que empiezan con alguno de esos controles (títulos centrados, superíndices)."""
    salida, i = [], 0
    while i < len(texto):
        if texto[i] == "{" and re.match(r"\{\s*(?:\\cf\d+\s*)?\\(" + "|".join(controles) + r")\b", texto[i:]):
            profundidad = 0
            while i < len(texto):
                if texto[i] == "{":
                    profundidad += 1
                elif texto[i] == "}":
                    profundidad -= 1
                    if profundidad == 0:
                        i += 1
                        break
                i += 1
            salida.append(" ")
            continue
        salida.append(texto[i])
        i += 1
    return "".join(salida)


def limpiar_esword_rtf(texto):
    texto = texto or ""
    texto = _grupos_rtf_sin(texto, ["qc", "super"])
    texto = re.sub(r"\\'([0-9a-fA-F]{2})", lambda m: bytes([int(m.group(1), 16)]).decode("cp1252", "replace"), texto)
    texto = re.sub(r"\\u(-?\d+)\??", lambda m: chr(int(m.group(1)) % 65536), texto)
    texto = re.sub(r"\\(par|line|tab)\b ?", " ", texto)
    texto = re.sub(r"\\bullet ?", " ", texto)
    texto = re.sub(r"\\[a-zA-Z]+-?\d* ?", "", texto)
    texto = texto.replace("{", "").replace("}", "")
    return _final(texto)


def limpiar_esword_html(texto):
    texto = texto or ""
    texto = re.sub(r"<p[^>]*align=\"?center\"?[^>]*>.*?</p>", " ", texto, flags=re.S | re.I)
    texto = _quitar_bloques(texto, [("sup", "/sup"), ("SUP", "/SUP")])
    texto = re.sub(r"<[^>]+>", " ", texto)
    return _final(texto)


# ================================================================ SQLite (MySword y e-Sword)

def _desde_sqlite(ruta):
    con = sqlite3.connect(f"file:{ruta}?mode=ro&immutable=1", uri=True)
    try:
        cur = con.cursor()
        tablas = {r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "Bible" not in tablas:
            raise ValueError("no es una Biblia de MySword ni de e-Sword")
        detalles = {}
        if "Details" in tablas:
            columnas = [r[1] for r in cur.execute("PRAGMA table_info(Details)")]
            fila = cur.execute("SELECT * FROM Details LIMIT 1").fetchone()
            detalles = dict(zip(columnas, fila)) if fila else {}
        nombre_archivo = Path(ruta).name.lower()
        if nombre_archivo.endswith(".bblx"):
            limpiar = limpiar_esword_rtf
        elif nombre_archivo.endswith(".bbli"):
            limpiar = limpiar_esword_html
        else:
            limpiar = limpiar_mysword
        libros = {}
        for libro, capitulo, versiculo, texto in cur.execute(
                "SELECT Book, Chapter, Verse, Scripture FROM Bible ORDER BY Book, Chapter, Verse"):
            if not 1 <= int(libro) <= 66:
                continue
            limpio = limpiar(texto)
            if limpio:
                libros.setdefault(int(libro), {}).setdefault(str(capitulo), {})[str(versiculo)] = limpio
    finally:
        con.close()
    nombre = detalles.get("Description") or detalles.get("Title") or Path(ruta).name.split(".")[0]
    sigla = detalles.get("Abbreviation") or nombre
    return str(nombre).strip(), str(sigla).strip(), libros, {}


# ================================================================ XML

def _texto_elemento(elemento, excluir):
    """Texto de un elemento y sus hijos, sin los hijos que son notas o títulos."""
    partes = [elemento.text or ""]
    for hijo in elemento:
        etiqueta = hijo.tag.split("}")[-1].lower()
        if etiqueta not in excluir:
            partes.append(_texto_elemento(hijo, excluir))
        partes.append(hijo.tail or "")
    return "".join(partes)


def _desde_zefania(raiz):
    libros, nombres = {}, {}
    for libro in raiz.iter("BIBLEBOOK"):
        numero = int(libro.get("bnumber") or 0)
        if not 1 <= numero <= 66:
            continue
        if libro.get("bname"):
            nombres[numero] = libro.get("bname")
        for capitulo in libro.iter("CHAPTER"):
            for verso in capitulo.iter("VERS"):
                texto = _final(_texto_elemento(verso, {"note", "br", "xref"}))
                if texto:
                    libros.setdefault(numero, {}).setdefault(str(int(capitulo.get("cnumber"))), {})[
                        str(int(verso.get("vnumber")))] = texto
    titulo = raiz.findtext("INFORMATION/title") or raiz.get("biblename") or ""
    sigla = raiz.findtext("INFORMATION/identifier") or titulo
    return titulo, sigla, libros, nombres


def _desde_beblia(raiz):
    libros = {}
    for libro in raiz.iter("book"):
        numero = int(libro.get("number") or 0)
        if not 1 <= numero <= 66:
            continue
        for capitulo in libro.iter("chapter"):
            for verso in capitulo.iter("verse"):
                texto = _final(_texto_elemento(verso, {"note"}))
                if texto:
                    libros.setdefault(numero, {}).setdefault(str(int(capitulo.get("number"))), {})[
                        str(int(verso.get("number")))] = texto
    titulo = raiz.get("translation") or raiz.get("name") or ""
    return titulo, titulo, libros, {}


def _desde_osis(raiz):
    """OSIS: versículos como contenedor (<verse osisID>) o como hitos (<verse sID/> … <verse eID/>)."""
    libros = {}
    excluir = {"note", "title", "reference", "rdg"}
    actual = None
    partes = []

    def guardar():
        if actual and partes:
            libro, capitulo, versiculo = actual
            texto = _final("".join(partes))
            if texto:
                libros.setdefault(libro, {}).setdefault(capitulo, {})[versiculo] = texto

    def ubicar(osis_id):
        trozos = (osis_id or "").split()[0].split(".")
        if len(trozos) < 3 or trozos[0] not in OSIS:
            return None
        return OSIS.index(trozos[0]) + 1, str(int(trozos[1])), str(int(trozos[2]))

    def recorrer(elemento):
        nonlocal actual, partes
        etiqueta = elemento.tag.split("}")[-1]
        if etiqueta == "verse":
            if elemento.get("sID") or (elemento.get("osisID") and len(elemento) == 0 and not elemento.text):
                guardar()
                actual, partes = ubicar(elemento.get("osisID") or elemento.get("sID")), []
            elif elemento.get("eID"):
                guardar()
                actual, partes = None, []
            elif elemento.get("osisID"):
                guardar()
                actual, partes = ubicar(elemento.get("osisID")), [_texto_elemento(elemento, excluir)]
                guardar()
                actual, partes = None, []
            if elemento.tail and actual:
                partes.append(elemento.tail)
            return
        if etiqueta in excluir:
            if elemento.tail and actual:
                partes.append(elemento.tail)
            return
        if elemento.text and actual:
            partes.append(elemento.text)
        for hijo in elemento:
            recorrer(hijo)
        if elemento.tail and actual:
            partes.append(elemento.tail)

    recorrer(raiz)
    guardar()
    encabezado = next((e for e in raiz.iter() if e.tag.split("}")[-1] == "work"), None)
    titulo = ""
    if encabezado is not None:
        titulo = next((e.text for e in encabezado if e.tag.split("}")[-1] == "title" and e.text), "")
    texto_div = next((e for e in raiz.iter() if e.tag.split("}")[-1] == "osisText"), None)
    sigla = (texto_div.get("osisIDWork") if texto_div is not None else "") or titulo
    return titulo, sigla, libros, {}


def _desde_xml(ruta):
    raiz = ET.parse(ruta).getroot()
    etiqueta = raiz.tag.split("}")[-1].lower()
    if etiqueta == "xmlbible":
        return _desde_zefania(raiz)
    if etiqueta in ("osis", "osistext"):
        return _desde_osis(raiz)
    if etiqueta == "bible":
        return _desde_beblia(raiz)
    raise ValueError("formato XML no reconocido")


# ================================================================ guardar en formato Lumbrera

def _idioma(libros):
    muestra = " ".join(list(libros.get(43, {}).get("1", {}).values())[:10]
                       or [v for c in list(libros.values())[:1] for cap in list(c.values())[:1] for v in cap.values()])
    palabras = re.findall(r"[a-záéíóúãõâêôçñ]+", muestra.lower())
    puntos = {"es": {"el", "y", "que", "los", "las", "del", "en", "por"},
              "pt": {"o", "e", "que", "os", "as", "do", "da", "não", "em"},
              "en": {"the", "and", "of", "that", "he", "was", "in", "to"}}
    cuentas = {codigo: sum(1 for p in palabras if p in lista) for codigo, lista in puntos.items()}
    return max(cuentas, key=cuentas.get) if any(cuentas.values()) else "es"


def _nombres_libros(idioma):
    if idioma == "pt":
        return dict(enumerate(NOMBRES_PT, start=1))
    for version in biblia.versiones():
        if version.idioma == idioma and len(version.libros) == 66:
            return {libro.numero: libro.nombre for libro in version.libros}
    return dict(enumerate(CODIGOS, start=1))


def _identificador(texto):
    base = unicodedata.normalize("NFD", texto.lower())
    base = re.sub(r"[^a-z0-9]+", "-", "".join(c for c in base if unicodedata.category(c) != "Mn")).strip("-")
    return f"importada-{base or 'biblia'}"[:60]


def importar_biblia(ruta):
    """Importa el archivo y devuelve el nombre de la Biblia. Lanza ValueError si no se puede leer."""
    ruta = Path(ruta)
    nombre_archivo = ruta.name.lower()
    if nombre_archivo.endswith((".xml", ".osis", ".zefania")):
        nombre, sigla, libros, nombres = _desde_xml(ruta)
    else:
        nombre, sigla, libros, nombres = _desde_sqlite(ruta)
    versiculos = sum(len(c) for capitulos in libros.values() for c in capitulos.values())
    if versiculos < 100:
        raise ValueError("el archivo no tiene versículos que se puedan leer")
    nombre = nombre or ruta.name.split(".")[0]
    idioma = _idioma(libros)
    nombres = {**_nombres_libros(idioma), **nombres}

    destino = rutas.USUARIO_BIBLIAS / _identificador(sigla or nombre)
    (destino / "books").mkdir(parents=True, exist_ok=True)
    lista = []
    for numero in sorted(libros):
        codigo = CODIGOS[numero - 1]
        with open(destino / "books" / f"{codigo}.json", "w", encoding="utf-8") as archivo:
            json.dump({"chapters": libros[numero]}, archivo, ensure_ascii=False, separators=(",", ":"))
        lista.append({"id": codigo, "name": nombres.get(numero, codigo), "number": numero,
                      "file": f"books/{codigo}.json"})
    manifiesto = {"schemaVersion": 2, "id": destino.name, "type": "bible", "name": nombre,
                  "abbreviation": sigla if len(sigla) <= 14 else nombre[:14], "language": idioma,
                  "license": "Importada por el usuario", "source": ruta.name, "verseCount": versiculos,
                  "bookCount": len(lista), "books": lista}
    with open(destino / "manifest.json", "w", encoding="utf-8") as archivo:
        json.dump(manifiesto, archivo, ensure_ascii=False, indent=2)
    olvidar_biblias()
    return nombre


def olvidar_biblias():
    """Borra lo que el programa tenía en memoria, para que vea las Biblias nuevas o quitadas."""
    biblia.versiones.cache_clear()
    biblia._indice_nombres.cache_clear()
    biblia._capitulos.cache_clear()


def quitar_biblia(identificador):
    import shutil
    carpeta = rutas.USUARIO_BIBLIAS / identificador
    if carpeta.is_dir() and carpeta.parent == rutas.USUARIO_BIBLIAS:
        shutil.rmtree(carpeta)
    olvidar_biblias()

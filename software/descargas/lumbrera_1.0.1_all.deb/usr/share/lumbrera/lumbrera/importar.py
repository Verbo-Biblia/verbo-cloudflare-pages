"""Importar canciones de otros programas, sin los acordes.

- SongbookPro: copia de seguridad «.sbp» o «.sbpbackup» (un ZIP con dataFile.txt: una línea con la versión y luego
  JSON con la lista «songs»; la letra está en «content», en formato ChordPro).
  Las canciones que en SongbookPro son un PDF (type 2) vienen en «pdf/<nombre>.pdf» dentro del ZIP: se saca el texto
  con pdftotext, respetando las dos columnas si las hay.
- Archivos ChordPro sueltos (.cho, .chopro, .chordpro, .pro, .crd).

En ChordPro los acordes van entre corchetes dentro de la letra («Amazing[D] Grace»), así que se quitan con
seguridad. Las secciones ({c: Verse 1}, {soc}…{eoc}) pasan a ser etiquetas de Lumbrera (Estrofa, Coro, Puente).
"""

import html
import json
import re
import subprocess
import zipfile
from pathlib import Path

from .cancion import Cancion, sin_acentos
from .idioma import _
from .letras_web import normalizar_letra, parece_linea_de_acordes, pdf_disponible, quitar_acordes

EXTENSIONES_CHORDPRO = {".cho", ".chopro", ".chordpro", ".pro", ".crd"}
EXTENSIONES_SONGBOOKPRO = {".sbp", ".sbpbackup"}

_DIRECTIVA = re.compile(r"^\s*\{\s*([a-zA-Z_]+)\s*(?::\s*(.*?))?\s*\}\s*$")
_ACORDE = re.compile(r"\[[^\]\n]*\]")


_SECCIONES_CREADAS = set()


def _nombre_seccion(texto):
    """«Verse 1» → «Estrofa 1», «Chorus» → «Coro», etc. (en el idioma del programa)."""
    nombre = _traducir_seccion(texto)
    if nombre:
        _SECCIONES_CREADAS.add(nombre)
    return nombre


def _traducir_seccion(texto):
    texto = texto.strip()
    equivalencias = [
        (r"pre[- ]?chorus|pre[- ]?coro|pr[ée][- ]?refr[aã]o", _("Pre-coro")),
        (r"chorus|coro|estribillo|refr[aã]o|refrain", _("Coro")),
        (r"verse|verso|estrofa|strophe", _("Estrofa")),
        (r"bridge|brithge|puente|ponte", _("Puente")),
        (r"intro(?:ducci[oó]n|du[cç][aã]o)?", _("Intro")),
        (r"outro|ending|final", _("Final")),
        (r"tag|coda", _("Final")),
    ]
    for patron, nombre in equivalencias:
        coincidencia = re.match(rf"^(?:{patron})\b\s*(.*)$", texto, re.IGNORECASE)
        if coincidencia:
            # Solo el número («Verse 1 - Muted» → «Estrofa 1»); las notas para músicos no se proyectan.
            numero = re.match(r"^(\d+)", coincidencia.group(1).strip())
            return f"{nombre} {numero.group(1)}" if numero else nombre
    return None  # comentario que no es una sección («Repetir 2 veces», «Capo 3»…): no se proyecta


def desde_chordpro(texto):
    """Devuelve (titulo, autor, letra sin acordes)."""
    titulo = autor = ""
    salida = []
    en_tablatura = False
    for linea in str(texto or "").replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        directiva = _DIRECTIVA.match(linea)
        if directiva:
            nombre = directiva.group(1).lower()
            valor = (directiva.group(2) or "").strip()
            if nombre in ("title", "t"):
                titulo = titulo or valor
            elif nombre in ("artist", "subtitle", "st", "author", "composer", "lyricist"):
                autor = autor or valor
            elif nombre in ("c", "comment", "ci", "comment_italic", "cb", "comment_box", "highlight"):
                seccion = _nombre_seccion(valor)
                if seccion:
                    salida += ["", seccion]
            elif nombre in ("soc", "start_of_chorus"):
                salida += ["", _nombre_seccion(valor or "Chorus")]
            elif nombre in ("sob", "start_of_bridge"):
                salida += ["", _nombre_seccion(valor or "Bridge")]
            elif nombre in ("sov", "start_of_verse"):
                salida += ["", _nombre_seccion(valor)] if valor and _nombre_seccion(valor) else [""]
            elif nombre in ("sot", "start_of_tab", "sog", "start_of_grid"):
                en_tablatura = True
            elif nombre in ("eot", "end_of_tab", "eog", "end_of_grid"):
                en_tablatura = False
            elif nombre.startswith("eo") or nombre.startswith("end_of"):
                salida.append("")
            continue  # key, capo, tempo, etc. no se proyectan
        if en_tablatura or linea.lstrip().startswith("#"):
            continue
        tenia_acordes = bool(_ACORDE.search(linea))
        limpia = " ".join(_ACORDE.sub("", re.sub(r"\{[^}\n]*\}", "", linea)).replace("]", " ").split())
        if (tenia_acordes and not limpia) or parece_linea_de_acordes(limpia):
            continue  # línea solo de acordes (por ejemplo, una introducción instrumental)
        if tenia_acordes:
            # «for - given», «be - cause»: sílabas separadas para alinear acordes; se vuelven a unir.
            # Solo si sigue una minúscula (continúa la palabra); «Santo - Santo» no se toca.
            limpia = re.sub(r"(?<=\w) - (?=[a-záéíóúüñç])", "", limpia)
        salida.append(limpia)
    return titulo.strip(), autor.strip(), normalizar_letra("\n".join(_sin_secciones_vacias(salida)))


def _sin_secciones_vacias(lineas):
    """Quita los nombres de sección que no tienen letra (por ejemplo, una «Intro» solo de acordes)."""
    resultado = []
    pendiente = None  # nombre de sección que todavía no tiene letra
    for linea in lineas:
        if linea and _es_seccion(linea):
            pendiente = linea
            continue
        if linea and pendiente:
            resultado += ["", pendiente]
            pendiente = None
        resultado.append(linea)
    return resultado


def _es_seccion(linea):
    return linea in _SECCIONES_CREADAS


def desde_songbookpro(ruta):
    """Lista de Cancion a partir de una copia de seguridad de SongbookPro."""
    with zipfile.ZipFile(ruta) as archivo:
        nombre = next((n for n in archivo.namelist() if n.lower().endswith("datafile.txt")), None)
        if nombre is None:
            raise ValueError("no es una copia de SongbookPro")
        crudo = archivo.read(nombre).decode("utf-8-sig", errors="replace")
        datos = json.loads(crudo[crudo.find("{"):])
        pdfs = {Path(n).name: n for n in archivo.namelist() if n.lower().endswith(".pdf")}
        canciones = []
        for registro in datos.get("songs") or []:
            if not isinstance(registro, dict) or str(registro.get("Deleted")).lower() == "true":
                continue
            contenido = (registro.get("content") or "").strip()
            if contenido in pdfs:
                titulo, autor = "", ""
                letra = letra_de_pdf(archivo.read(pdfs[contenido]), registro.get("name") or "")
            else:
                titulo, autor, letra = desde_chordpro(contenido)
            cancion = _cancion_de_registro(registro, titulo, autor, letra)
            if cancion:
                canciones.append(cancion)
    return canciones


def _cancion_de_registro(registro, titulo, autor, letra):
    titulo = (registro.get("name") or titulo or "").strip()
    letra = _sin_notas_para_musicos(letra, titulo)
    if not titulo or not letra.strip():
        return None
    cancion = Cancion(titulo=titulo, autor=(registro.get("author") or autor or "").strip(), letra=letra)
    if registro.get("SyncId"):
        cancion.id = f"sbp-{registro['SyncId']}"
    return cancion


def _sin_notas_para_musicos(letra, titulo):
    """Quita lo que en SongbookPro se escribe para la banda y no se proyecta: «capo VIII», «Tonalidad E»,
    «Instrumental 2», «PUENTE Instrumental II»."""
    lineas = []
    for linea in letra.split("\n"):
        linea = re.sub(r"\s*\b(tonalidad|tono|key)\s*:?\s*[A-G](#|b)?m?\s*$", "", linea, flags=re.I)
        if re.match(r"^\s*(tonalidad|tono|key)\b", linea, re.I) or re.search(r"(?i)\b(capo|intermedio)\b", linea):
            continue
        if re.search(r"(?i)\b(instrumental|interlude|interludio)\b", linea) and len(linea.split()) <= 4:
            continue
        if not lineas and titulo and sin_acentos(linea) == sin_acentos(titulo):
            continue  # el título repetido como primer renglón
        lineas.append(linea)
    return normalizar_letra("\n".join(lineas))


def letra_de_pdf(contenido, titulo=""):
    """Letra sin acordes de un PDF de canción (en bytes). Si va a dos columnas, primero la izquierda."""
    if not pdf_disponible():
        return ""
    proceso = subprocess.run(["pdftotext", "-bbox", "-enc", "UTF-8", "-", "-"], input=contenido,
                             capture_output=True, timeout=60)
    if proceso.returncode != 0:
        return ""
    lineas = []
    for numero, pagina in enumerate(re.findall(r"<page width=\"([\d.]+)\" height=\"([\d.]+)\">(.*?)</page>",
                             proceso.stdout.decode("utf-8", "replace"), re.S)):
        palabras = [(float(x0), float(y0), float(x1), html.unescape(texto)) for x0, y0, x1, texto in re.findall(
            r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="[\d.]+">(.*?)</word>', pagina[2])]
        # En la primera página, el título y el autor van a lo ancho: quedan con la primera columna.
        cabecera = float(pagina[1]) * 0.1 if numero == 0 else 0
        corte = _corte_de_columnas(palabras, float(pagina[0]), cabecera)
        columnas = [palabras] if corte is None else [[p for p in palabras if p[0] < corte or p[1] <= cabecera],
                                                     [p for p in palabras if p[0] >= corte and p[1] > cabecera]]
        for columna in columnas:
            lineas += _renglones(columna) + [""]
    # Cabecera de SongbookPro: título, autor (hasta el primer renglón vacío) y «Tonalidad: X».
    lineas = [re.sub(r"\s*\b(tonalidad|tono|tom|key|capo)\s*:\s*\S+", "", linea, flags=re.I).strip()
              for linea in lineas]
    while lineas and not lineas[0]:
        lineas.pop(0)
    comparar = lambda texto: sin_acentos(re.sub(r"[/_]", " ", texto)).split()  # noqa: E731
    primera, nombre = comparar(lineas[0]) if lineas else [], comparar(titulo)
    if primera and nombre and (primera[:len(nombre)] == nombre or nombre[:len(primera)] == primera):
        lineas.pop(0)
        while lineas and not lineas[0]:
            lineas.pop(0)
        if lineas and len(lineas[0].split()) <= 4 and not _traducir_seccion(lineas[0]):
            lineas.pop(0)  # autor
    limpias = []
    for linea in lineas:
        if re.fullmatch(r"\d+", linea):
            continue  # número de página
        seccion = _traducir_seccion(linea) if len(linea.split()) <= 3 else None
        if seccion:
            _SECCIONES_CREADAS.add(seccion)
            limpias += ["", seccion]
        else:
            limpias.append(linea)
    letra = quitar_acordes("\n".join(limpias))
    letra = re.sub(r"(?<=\w) - (?=[a-záéíóúüñç])", "", letra)  # «D - ios» (sílabas separadas por acordes)
    return normalizar_letra("\n".join(_sin_secciones_vacias(letra.split("\n"))))


def _corte_de_columnas(palabras, ancho, cabecera):
    """Dónde empieza la segunda columna, o None si la página va a una sola columna.

    Hay dos columnas si una vertical por el centro casi no cruza palabras (sin contar la cabecera, que suele ser
    ancha) y deja texto a ambos lados. Se elige la que menos cruza y, entre esas, la del hueco más ancho."""
    cuerpo = [p for p in palabras if p[1] > cabecera]
    if len(cuerpo) < 20:
        return None
    candidatos = []
    for x in range(int(ancho * 0.35), int(ancho * 0.65), 2):
        cruzan = sum(1 for x0, _y, x1, _t in cuerpo if x0 < x < x1)
        izquierda = sum(1 for p in cuerpo if p[2] <= x)
        if cruzan <= 2 and min(izquierda, len(cuerpo) - izquierda) >= max(8, len(cuerpo) * 0.1):
            candidatos.append((cruzan, x))
    if not candidatos:
        return None
    menos = min(c for c, _x in candidatos)
    xs = [x for c, x in candidatos if c == menos]
    tramos, inicio = [], xs[0]
    for previo, x in zip(xs, xs[1:] + [None]):
        if x != previo + 2:
            tramos.append((previo - inicio, (inicio + previo) // 2))
            inicio = x
    return max(tramos)[1]


def _renglones(palabras):
    """Agrupa las palabras en renglones por su altura y deja un renglón vacío donde hay un salto grande."""
    renglones = []
    for palabra in sorted(palabras, key=lambda p: (p[1], p[0])):
        if renglones and abs(renglones[-1][0] - palabra[1]) < 3:
            renglones[-1][1].append(palabra)
        else:
            renglones.append((palabra[1], [palabra]))
    # Los renglones de acordes no cuentan: así el salto entre estrofas se mide solo entre renglones de letra.
    renglones = [r for r in renglones if not parece_linea_de_acordes(" ".join(t for *_r, t in r[1]))]
    lineas, anterior, alto = [], None, None
    pasos = [b[0] - a[0] for a, b in zip(renglones, renglones[1:])]
    if pasos:
        alto = sorted(pasos)[len(pasos) // 2]  # paso normal entre renglones
    for y, grupo in renglones:
        if anterior is not None and alto and y - anterior > alto * 1.6:
            lineas.append("")
        lineas.append(" ".join(t for *_r, t in sorted(grupo)))
        anterior = y
    return lineas


def desde_archivo_chordpro(ruta):
    texto = Path(ruta).read_text(encoding="utf-8", errors="replace")
    titulo, autor, letra = desde_chordpro(texto)
    return [Cancion(titulo=titulo or Path(ruta).stem, autor=autor, letra=letra)] if letra.strip() else []


def importar_archivo(biblioteca, ruta):
    """Importa según el tipo de archivo. Devuelve cuántas canciones entraron o se actualizaron."""
    extension = Path(ruta).suffix.lower()
    if extension in EXTENSIONES_SONGBOOKPRO:
        canciones = desde_songbookpro(ruta)
        # SongbookPro puede tener varias versiones con el mismo título y autor (otro tono, bilingüe…): se
        # reconocen por su número de sincronización y solo se juntan si la letra es idéntica.
        clave = lambda c: (sin_acentos(c.titulo), sin_acentos(c.autor), c.letra)  # noqa: E731
    elif extension in EXTENSIONES_CHORDPRO:
        canciones = desde_archivo_chordpro(ruta)
        clave = lambda c: (sin_acentos(c.titulo), sin_acentos(c.autor))  # noqa: E731
    else:
        return biblioteca.importar(ruta)  # copia de Lumbrera o del proyector web (JSON)
    # Si ya existe la misma canción, se actualiza en vez de duplicarla.
    existentes = {clave(c): c for c in biblioteca.canciones.values()}
    for cancion in canciones:
        igual = biblioteca.canciones.get(cancion.id) or existentes.get(clave(cancion))
        if igual is not None:
            cancion.id = igual.id
            cancion.creada = igual.creada
        biblioteca.canciones[cancion.id] = cancion
        existentes[clave(cancion)] = cancion
    if canciones:
        biblioteca.guardar()
    return len(canciones)


def importar_para_todos(ruta):
    """Agrega las canciones de un archivo al cancionero de todos los usuarios (necesita ser administrador).

    Devuelve (cuántas entraron o se actualizaron, cuántas hay en total)."""
    from . import almacen, rutas
    compartida = almacen.Biblioteca(ruta=rutas.COMPARTIDAS, compartidas="")
    cantidad = importar_archivo(compartida, ruta)
    rutas.COMPARTIDAS.parent.chmod(0o755)
    rutas.COMPARTIDAS.chmod(0o644)  # que todos la puedan leer, aunque sudo tenga otra umask
    return cantidad, len(compartida.canciones)

"""Editor de canciones: un solo cuadro de texto, vista de las pantallas y búsqueda en internet."""

import threading
import time

from gi.repository import Adw, Gio, GLib, GObject, Gtk, Pango

from . import letras_web
from .cancion import Cancion, diapositivas
from .idioma import _


def texto_de_ayuda():
    return _("Escribe o pega la letra. Deja una línea en blanco entre cada estrofa. "
             "Para repetir el coro, escribe «Coro» en una línea sola.")


class EditorCancion(Gtk.Box):
    """Panel de edición (dentro de Configuración › Cancionero). Muestra una canción a la vez."""

    __gsignals__ = {
        "guardada": (GObject.SignalFlags.RUN_FIRST, None, (object,)),
        "borrada": (GObject.SignalFlags.RUN_FIRST, None, ()),
    }

    def __init__(self, biblioteca, max_lineas, avisar):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.add_css_class("editor-cancion")
        self.biblioteca = biblioteca
        self.max_lineas = max_lineas  # función que da el máximo de líneas actual
        self._avisar_fuera = avisar
        self.cancion = None
        self._busqueda_actual = 0
        self._vista_pendiente = 0
        self._modificada = False

        # ---------------- barra del editor
        barra = Gtk.Box(spacing=8, margin_start=18, margin_end=18, margin_top=12)
        self.encabezado = Gtk.Label(xalign=0, hexpand=True, ellipsize=3)
        self.encabezado.add_css_class("title-2")
        barra.append(self.encabezado)
        self.boton_borrar = Gtk.Button(tooltip_text=_("Borrar esta canción"))
        self.boton_borrar.set_child(Adw.ButtonContent(icon_name="user-trash-symbolic", label=_("Borrar")))
        self.boton_borrar.add_css_class("flat")
        self.boton_borrar.connect("clicked", lambda *_: self._confirmar_borrar())
        barra.append(self.boton_borrar)
        self.boton_descartar = Gtk.Button(label=_("Descartar cambios"))
        self.boton_descartar.connect("clicked", lambda *_: self.cargar(self.cancion, forzar=True))
        barra.append(self.boton_descartar)
        guardar = Gtk.Button(tooltip_text=_("Guardar (Ctrl + S)"))
        guardar.set_child(Adw.ButtonContent(icon_name="document-save-symbolic", label=_("Guardar")))
        guardar.add_css_class("suggested-action")
        guardar.connect("clicked", lambda *_: self._guardar())
        barra.append(guardar)
        self.append(barra)

        # ---------------- izquierda: datos y letra
        izquierda = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin_start=18, margin_end=12,
                            margin_top=12, margin_bottom=18)
        datos = Gtk.Box(spacing=12)
        self.titulo = Gtk.Entry(placeholder_text=_("Título de la canción"), hexpand=True)
        self.titulo.add_css_class("entrada-titulo")
        self.autor = Gtk.Entry(placeholder_text=_("Autor o intérprete (opcional)"), hexpand=True)
        datos.append(self.titulo)
        datos.append(self.autor)
        izquierda.append(datos)

        # Si no caben en una línea, los botones pasan a la siguiente (así la ventana no se ensancha).
        herramientas = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, column_spacing=6, row_spacing=6,
                                   min_children_per_line=1, max_children_per_line=8)
        self.boton_buscar = self._boton(_("Buscar en internet"), "system-search-symbolic", self._mostrar_buscador)
        self.boton_buscar.add_css_class("suggested-action")
        herramientas.append(self.boton_buscar)
        boton_pdf = self._boton(_("Desde un PDF"), "eb-pdf-symbolic", self._elegir_pdf)
        boton_pdf.set_sensitive(letras_web.pdf_disponible())
        if not letras_web.pdf_disponible():
            boton_pdf.set_tooltip_text(_("Falta el programa pdftotext (paquete poppler-utils o poppler-tools)."))
        herramientas.append(boton_pdf)
        herramientas.append(self._boton(_("Pegar"), "edit-paste-symbolic", self._pegar))
        herramientas.append(self._boton(_("Quitar acordes"), "edit-clear-symbolic", self._quitar_acordes,
                                        _("Borra los acordes de la letra (por ejemplo [G] o líneas solo con acordes)")))
        herramientas.append(self._boton(_("Ordenar estrofas"), "eb-ordenar-symbolic", self._ordenar,
                                        _("Quita espacios de más y separa en estrofas de 4 líneas si todo está junto")))
        izquierda.append(herramientas)

        ayuda = Gtk.Label(label=texto_de_ayuda(), xalign=0, wrap=True)
        ayuda.add_css_class("dim-label")
        ayuda.add_css_class("caption")
        izquierda.append(ayuda)

        self.texto = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR, top_margin=14, bottom_margin=14,
                                  left_margin=16, right_margin=16, pixels_inside_wrap=2)
        self.texto.add_css_class("texto-letra")
        self.texto.get_buffer().connect("changed", self._letra_cambio)
        marco = Gtk.ScrolledWindow(vexpand=True)
        marco.add_css_class("marco-letra")
        marco.set_child(self.texto)
        izquierda.append(marco)

        # ---------------- derecha: pantallas o búsqueda
        self.lado = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, hexpand=True)
        self.lado.add_named(self._crear_vista_previa(), "pantallas")
        self.lado.add_named(self._crear_buscador(), "buscar")
        derecha = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, margin_start=6, margin_end=18, margin_top=12,
                          margin_bottom=18)
        derecha.append(self.lado)

        division = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL, wide_handle=False,
                             shrink_start_child=False, shrink_end_child=False)
        # La letra ocupa algo más de la mitad; «Así se verá en pantalla», el resto.
        division.connect("map", lambda d: GLib.idle_add(lambda: d.set_position(int(d.get_width() * 0.58)) and False))
        division.set_start_child(izquierda)
        division.set_end_child(derecha)
        division.set_vexpand(True)
        self.append(division)

        for entrada in (self.titulo, self.autor):
            entrada.connect("changed", lambda *_: self._marcar_cambios())

        teclas = Gtk.ShortcutController()
        teclas.add_shortcut(Gtk.Shortcut.new(Gtk.ShortcutTrigger.parse_string("<Control>s"),
                                             Gtk.CallbackAction.new(lambda *_: self._guardar() or True)))
        self.add_controller(teclas)
        self.cargar(None, forzar=True)

    # ------------------------------------------------------------ cargar

    def tiene_cambios(self):
        return self._modificada

    def cargar(self, cancion, busqueda="", forzar=False):
        """Muestra una canción (o una nueva). Si hay cambios sin guardar, pregunta antes."""
        if self._modificada and not forzar:
            self.confirmar_cambios(lambda: self.cargar(cancion, busqueda, forzar=True))
            return
        self.cancion = cancion
        self.encabezado.set_label(_("Editar canción") if cancion else _("Nueva canción"))
        self.boton_borrar.set_visible(cancion is not None)
        self._cargando = True
        self.titulo.set_text(cancion.titulo if cancion else "")
        self.autor.set_text(cancion.autor if cancion else "")
        self.texto.get_buffer().set_text(cancion.letra if cancion else "")
        self._cargando = False
        self._modificada = False
        self.boton_descartar.set_sensitive(False)
        self.lado.set_visible_child_name("pantallas")
        self._actualizar_vista()
        if busqueda and busqueda.strip():
            self.consulta.set_text(busqueda.strip())
            self._mostrar_buscador()
            self._buscar()
        elif busqueda:
            self.consulta.set_text("")
            self._mostrar_buscador()
        elif not cancion:
            GLib.idle_add(lambda: self.titulo.grab_focus() and False)

    def _marcar_cambios(self):
        if getattr(self, "_cargando", False):
            return
        self._modificada = True
        self.boton_descartar.set_sensitive(True)

    def confirmar_cambios(self, seguir):
        """Si hay cambios sin guardar, pregunta; después llama a seguir()."""
        if not self._modificada:
            seguir()
            return
        dialogo = Adw.AlertDialog(heading=_("¿Guardar los cambios?"),
                                  body=_("Hiciste cambios en esta canción que todavía no están guardados."))
        dialogo.add_response("cancelar", _("Cancelar"))
        dialogo.add_response("descartar", _("No guardar"))
        dialogo.add_response("guardar", _("Guardar"))
        dialogo.set_response_appearance("descartar", Adw.ResponseAppearance.DESTRUCTIVE)
        dialogo.set_response_appearance("guardar", Adw.ResponseAppearance.SUGGESTED)
        dialogo.set_default_response("guardar")
        dialogo.set_close_response("cancelar")

        def respuesta(_d, opcion):
            if opcion == "guardar" and self._guardar():
                seguir()
            elif opcion == "descartar":
                self._modificada = False
                seguir()

        dialogo.connect("response", respuesta)
        dialogo.present(self)

    # ------------------------------------------------------------ piezas

    def _boton(self, texto, icono, accion, ayuda=None):
        boton = Gtk.Button(tooltip_text=ayuda)
        boton.set_child(Adw.ButtonContent(icon_name=icono, label=texto))
        boton.connect("clicked", lambda *_: accion())
        return boton

    def _crear_vista_previa(self):
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        cabecera = Gtk.Box(spacing=6)
        titulo = Gtk.Label(label=_("Así se verá en pantalla"), xalign=0, hexpand=True)
        titulo.add_css_class("heading")
        cabecera.append(titulo)
        self.cuenta = Gtk.Label()
        self.cuenta.add_css_class("dim-label")
        cabecera.append(self.cuenta)
        caja.append(cabecera)
        self.pantallas = Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True, max_children_per_line=2,
                                     min_children_per_line=1, column_spacing=10, row_spacing=10,
                                     valign=Gtk.Align.START)
        desplazable = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        desplazable.set_child(self.pantallas)
        caja.append(desplazable)
        return caja

    def _crear_buscador(self):
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        cabecera = Gtk.Box(spacing=6)
        volver = Gtk.Button(icon_name="go-previous-symbolic", tooltip_text=_("Volver a la vista de pantallas"))
        volver.add_css_class("flat")
        volver.connect("clicked", lambda *_: self.lado.set_visible_child_name("pantallas"))
        cabecera.append(volver)
        titulo = Gtk.Label(label=_("Buscar letra en internet"), xalign=0, hexpand=True)
        titulo.add_css_class("heading")
        cabecera.append(titulo)
        caja.append(cabecera)

        fila = Gtk.Box(spacing=6)
        self.consulta = Gtk.SearchEntry(placeholder_text=_("Nombre de la canción y artista"), hexpand=True)
        self.consulta.connect("activate", lambda *_: self._buscar())
        fila.append(self.consulta)
        boton = Gtk.Button(label=_("Buscar"))
        boton.add_css_class("suggested-action")
        boton.connect("clicked", lambda *_: self._buscar())
        fila.append(boton)
        caja.append(fila)

        estado = Gtk.Box(spacing=8)
        self.girando = Gtk.Spinner()
        estado.append(self.girando)
        self.estado = Gtk.Label(xalign=0, wrap=True, hexpand=True,
                                label=_("Busca en varias páginas de letras al mismo tiempo."))
        self.estado.add_css_class("dim-label")
        estado.append(self.estado)
        caja.append(estado)

        self.resultados = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE, valign=Gtk.Align.START)
        self.resultados.add_css_class("boxed-list")
        self.resultados.connect("row-activated", lambda _l, fila: self._elegir_resultado(fila))
        desplazable = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        desplazable.set_child(self.resultados)
        caja.append(desplazable)
        return caja

    # ------------------------------------------------------------ letra y vista previa

    @property
    def letra(self):
        buffer = self.texto.get_buffer()
        return buffer.get_text(buffer.get_start_iter(), buffer.get_end_iter(), False)

    def _poner_letra(self, letra):
        self.texto.get_buffer().set_text(letra)
        self.texto.get_buffer().place_cursor(self.texto.get_buffer().get_start_iter())

    def _letra_cambio(self, *_):
        self._marcar_cambios()
        if self._vista_pendiente:
            GLib.source_remove(self._vista_pendiente)
        self._vista_pendiente = GLib.timeout_add(250, self._actualizar_vista)

    def _actualizar_vista(self):
        self._vista_pendiente = 0
        self.pantallas.remove_all()
        lista = diapositivas(self.letra, self.max_lineas())
        for diapositiva in lista:
            tarjeta = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            tarjeta.add_css_class("mini-pantalla")
            etiqueta = Gtk.Label(label=diapositiva.etiqueta.upper(), xalign=0.5)
            etiqueta.add_css_class("etiqueta-mini")
            tarjeta.append(etiqueta)
            texto = Gtk.Label(label=diapositiva.texto, justify=Gtk.Justification.CENTER, wrap=True,
                              vexpand=True, valign=Gtk.Align.CENTER)
            texto.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
            tarjeta.append(texto)
            self.pantallas.append(tarjeta)
        cantidad = len(lista)
        self.cuenta.set_label(_("1 pantalla") if cantidad == 1 else _("{n} pantallas").format(n=cantidad))
        return GLib.SOURCE_REMOVE

    def _pegar(self):
        portapapeles = self.get_clipboard()

        def recibido(origen, resultado):
            try:
                texto = origen.read_text_finish(resultado)
            except GLib.Error:
                texto = None
            if not texto:
                self._avisar(_("No hay texto copiado para pegar."))
                return
            limpio = letras_web.normalizar_letra(texto)
            if self.letra.strip():
                self._preguntar_reemplazo(limpio)
            else:
                self._poner_letra(limpio)

        portapapeles.read_text_async(None, recibido)

    def _quitar_acordes(self):
        from .importar import desde_chordpro
        texto = self.letra
        if "[" in texto or "{" in texto:
            limpio = desde_chordpro(texto)[2]
        else:
            limpio = letras_web.normalizar_letra(letras_web.quitar_acordes(texto))
        if limpio.strip() == texto.strip():
            self._avisar(_("No encontré acordes en esta letra."))
            return
        self._poner_letra(limpio)
        self._avisar(_("Acordes quitados. Si algo no quedó bien, usa «Descartar cambios»."))

    def _ordenar(self):
        self._poner_letra(letras_web.normalizar_letra(self.letra))

    def _avisar(self, texto):
        self._avisar_fuera(texto)

    # ------------------------------------------------------------ PDF

    def _elegir_pdf(self):
        dialogo = Gtk.FileDialog(title=_("Elegir un PDF con la letra"))
        filtro = Gtk.FileFilter(name=_("Documentos PDF"))
        filtro.add_suffix("pdf")
        filtros = Gio.ListStore.new(Gtk.FileFilter)
        filtros.append(filtro)
        dialogo.set_filters(filtros)

        def elegido(dialogo, resultado):
            try:
                archivo = dialogo.open_finish(resultado)
            except GLib.Error:
                return
            try:
                titulo, autor, letra = letras_web.texto_de_pdf(archivo.get_path())
            except ValueError:
                self._avisar(_("Ese PDF no tiene texto que se pueda copiar (quizás es una imagen escaneada)."))
                return
            except Exception as error:
                self._avisar(_("No se pudo leer el PDF: {error}").format(error=error))
                return
            if not self.titulo.get_text().strip():
                self.titulo.set_text(titulo or archivo.get_basename().rsplit(".", 1)[0])
            if autor and not self.autor.get_text().strip():
                self.autor.set_text(autor)
            if self.letra.strip():
                self._preguntar_reemplazo(letra)
            else:
                self._poner_letra(letra)
            self._avisar(_("Letra importada. Revísala antes de guardar."))

        dialogo.open(self, None, elegido)

    # ------------------------------------------------------------ internet

    def _mostrar_buscador(self):
        if not self.consulta.get_text().strip():
            self.consulta.set_text(" ".join(t for t in (self.titulo.get_text().strip(),
                                                        self.autor.get_text().strip()) if t))
        self.lado.set_visible_child_name("buscar")
        self.consulta.grab_focus()

    def _buscar(self):
        consulta = self.consulta.get_text().strip()
        if not consulta:
            self.estado.set_label(_("Escribe el nombre de la canción y, si lo sabes, el artista."))
            return
        self._busqueda_actual += 1
        numero = self._busqueda_actual
        self.resultados.remove_all()
        self.girando.start()
        self.estado.set_label(_("Buscando «{consulta}»…").format(consulta=consulta))

        def trabajo():
            try:
                resultados, errores = letras_web.buscar(consulta)
                falla = None
            except Exception as error:
                resultados, errores, falla = [], [], error
            GLib.idle_add(self._mostrar_resultados, numero, resultados, errores, falla)

        threading.Thread(target=trabajo, daemon=True).start()

    def _mostrar_resultados(self, numero, resultados, errores, falla):
        if numero != self._busqueda_actual:
            return GLib.SOURCE_REMOVE
        self.girando.stop()
        if falla or (not resultados and len(errores) >= len(letras_web.FUENTES)):
            self.estado.set_label(_("No hay conexión con las páginas de letras. Revisa tu internet e "
                                    "inténtalo de nuevo."))
            return GLib.SOURCE_REMOVE
        if not resultados:
            self.estado.set_label(_("No se encontró nada. Prueba solo con el nombre de la canción, o "
                                    "agrega el artista."))
            return GLib.SOURCE_REMOVE
        self.estado.set_label(_("Elige la versión que quieras. La letra aparece a la izquierda para "
                                "que la revises."))
        for resultado in resultados:
            fila = Adw.ActionRow(activatable=True, title=GLib.markup_escape_text(resultado.titulo),
                                 subtitle=GLib.markup_escape_text(
                                     " · ".join(t for t in (resultado.artista, resultado.album) if t)))
            fila.set_title_lines(2)
            fila.set_subtitle_lines(1)
            fila.resultado = resultado
            fuente = Gtk.Label(label=resultado.fuente, valign=Gtk.Align.CENTER)
            fuente.add_css_class("insignia-fuente")
            if resultado.letra:
                fuente.add_css_class("con-letra")
            fila.add_suffix(fuente)
            if resultado.solo_navegador:
                fila.set_subtitle(GLib.markup_escape_text(_("{artista} · se abre en el navegador").format(
                    artista=resultado.artista)))
            self.resultados.append(fila)
        return GLib.SOURCE_REMOVE

    def _elegir_resultado(self, fila):
        resultado = fila.resultado
        if resultado.solo_navegador:
            Gtk.UriLauncher.new(resultado.url).launch(self, None, None)
            self.estado.set_label(_("Se abrió la página en tu navegador. Copia la letra y vuelve aquí para "
                                    "usar el botón «Pegar»."))
            return
        self.girando.start()
        self.estado.set_label(_("Descargando «{titulo}»…").format(titulo=resultado.titulo))
        self.resultados.set_sensitive(False)
        numero = self._busqueda_actual

        def trabajo():
            try:
                letra = resultado.obtener_letra()
                falla = None if letra.strip() else _("no se encontró la letra de esta versión en ninguna página")
            except letras_web.SinConexion:
                letra, falla = "", _("no hay conexión a internet")
            except Exception:
                letra, falla = "", _("no se encontró la letra de esta versión en ninguna página")
            GLib.idle_add(self._letra_descargada, numero, resultado, letra, falla)

        threading.Thread(target=trabajo, daemon=True).start()

    def _letra_descargada(self, numero, resultado, letra, falla):
        self.resultados.set_sensitive(True)
        self.girando.stop()
        if numero != self._busqueda_actual:
            return GLib.SOURCE_REMOVE
        if falla:
            self.estado.set_label(_("No se pudo traer esa letra ({motivo}). Elige otra opción.").format(motivo=falla))
            return GLib.SOURCE_REMOVE
        self.estado.set_label(_("Listo. Revisa la letra a la izquierda."))
        if not self.titulo.get_text().strip():
            self.titulo.set_text(letras_web.limpiar_titulo(resultado.titulo))
        if not self.autor.get_text().strip():
            self.autor.set_text(resultado.artista)
        if self.letra.strip():
            self._preguntar_reemplazo(letra, volver=True)
        else:
            self._poner_letra(letra)
            self.lado.set_visible_child_name("pantallas")
        return GLib.SOURCE_REMOVE

    def _preguntar_reemplazo(self, letra, volver=False):
        dialogo = Adw.AlertDialog(heading=_("¿Qué hago con la letra que ya escribiste?"),
                                  body=_("Puedes cambiarla por la nueva o poner la nueva al final."))
        dialogo.add_response("cancelar", _("Cancelar"))
        dialogo.add_response("final", _("Poner al final"))
        dialogo.add_response("reemplazar", _("Cambiar"))
        dialogo.set_response_appearance("reemplazar", Adw.ResponseAppearance.SUGGESTED)
        dialogo.set_default_response("reemplazar")
        dialogo.set_close_response("cancelar")

        def respuesta(_dialogo, opcion):
            if opcion == "reemplazar":
                self._poner_letra(letra)
            elif opcion == "final":
                self._poner_letra(self.letra.rstrip() + "\n\n" + letra)
            if opcion != "cancelar" and volver:
                self.lado.set_visible_child_name("pantallas")

        dialogo.connect("response", respuesta)
        dialogo.present(self)

    # ------------------------------------------------------------ guardar y borrar

    def _guardar(self):
        titulo = self.titulo.get_text().strip()
        if not titulo:
            self._avisar(_("Escribe el título de la canción."))
            self.titulo.grab_focus()
            return False
        if not self.letra.strip():
            self._avisar(_("La canción no tiene letra todavía."))
            self.texto.grab_focus()
            return False
        cancion = self.cancion or Cancion(titulo=titulo)
        cancion.titulo = titulo
        cancion.autor = self.autor.get_text().strip()
        cancion.letra = self.letra.strip()
        cancion.modificada = time.time()
        self.cancion = cancion
        self._modificada = False
        self.boton_descartar.set_sensitive(False)
        self.boton_borrar.set_visible(True)
        self.encabezado.set_label(_("Editar canción"))
        self.biblioteca.poner(cancion)
        self._avisar(_("Canción guardada."))
        self.emit("guardada", cancion)
        return True

    def _confirmar_borrar(self):
        dialogo = Adw.AlertDialog(heading=_("¿Borrar «{titulo}»?").format(titulo=self.cancion.titulo),
                                  body=_("Se quitará de tu lista de canciones."))
        dialogo.add_response("no", _("Cancelar"))
        dialogo.add_response("si", _("Borrar"))
        dialogo.set_response_appearance("si", Adw.ResponseAppearance.DESTRUCTIVE)
        dialogo.set_close_response("no")

        def respuesta(_d, opcion):
            if opcion == "si":
                self.biblioteca.quitar(self.cancion.id)
                self.cargar(None, forzar=True)
                self.emit("borrada")

        dialogo.connect("response", respuesta)
        dialogo.present(self)

"""Columna 1, pestaña Biblia: Antiguo/Nuevo Testamento → libros → capítulos → versículos.

Las dos versiones (la principal y la que va debajo) se eligen en Preferencias.
Los versículos se marcan haciendo clic y arrastrando hacia abajo; luego la selección se arrastra al
orden del culto (o se usa el botón «Al orden»). Queda como una sola cita: «Juan 1:1-10».
"""

from gi.repository import Adw, Gdk, GLib, GObject, Gtk

from . import biblia
from .idioma import _

ULTIMO_LIBRO_AT = 39
CONTENIDO_PASAJE = "lumbrera:pasaje"


class PanelBiblia(Gtk.Box):
    __gsignals__ = {
        # titulo, diapositivas
        "agregar": (GObject.SignalFlags.RUN_FIRST, None, (str, object)),
    }

    def __init__(self, ajustes):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.ajustes = ajustes
        self.set_margin_start(10)
        self.set_margin_end(10)
        self.set_margin_bottom(10)
        self.numero_libro = int(ajustes["biblia_libro"] or 43)
        self.capitulo = int(ajustes["biblia_capitulo"] or 1)
        self._diapositivas = []
        self._modo_arrastre = None
        self._ancla = None
        self._fila_inicio = None

        self.cita = Gtk.SearchEntry(placeholder_text=_("Cita, por ejemplo: Juan 3:16"))
        self.cita.connect("activate", self._ir_a_cita)
        self.append(self.cita)
        self.aviso = Gtk.Label(xalign=0, wrap=True, visible=False)
        self.aviso.add_css_class("caption")
        self.aviso.add_css_class("error")
        self.append(self.aviso)

        testamentos = Gtk.Box(homogeneous=True)
        testamentos.add_css_class("linked")
        self.boton_at = Gtk.ToggleButton(label=_("Antiguo Testamento"))
        self.boton_nt = Gtk.ToggleButton(label=_("Nuevo Testamento"), group=self.boton_at)
        for boton, nuevo in ((self.boton_at, False), (self.boton_nt, True)):
            # «clicked» y no «toggled»: así tocar el Testamento que ya está elegido vuelve a mostrar sus libros.
            boton.connect("clicked", lambda _b, n=nuevo: self._mostrar_libros(n))
            testamentos.append(boton)
        self.append(testamentos)

        camino = Gtk.Box(spacing=6)
        self.boton_volver = Gtk.Button(icon_name="go-previous-symbolic", tooltip_text=_("Volver"))
        self.boton_volver.add_css_class("flat")
        self.boton_volver.connect("clicked", lambda *_: self._volver())
        camino.append(self.boton_volver)
        self.camino = Gtk.Label(xalign=0, hexpand=True, ellipsize=3)
        self.camino.add_css_class("heading")
        camino.append(self.camino)
        self.append(camino)

        self.paginas = Gtk.Stack(vexpand=True, transition_type=Gtk.StackTransitionType.CROSSFADE)
        self.libros = self._rejilla(2, 3)
        self.capitulos = self._rejilla(5, 8)
        self.paginas.add_named(self._desplazable(self.libros), "libros")
        self.paginas.add_named(self._desplazable(self.capitulos), "capitulos")
        self.paginas.add_named(self._crear_versiculos(), "versiculos")
        self.append(self.paginas)

        if not biblia.versiones():
            self.aviso.set_label(_("No se encontraron Biblias instaladas."))
            self.aviso.set_visible(True)
            return
        self._abrir_capitulo(self.numero_libro, self.capitulo)

    # ------------------------------------------------------------ armado

    @staticmethod
    def _rejilla(minimo, maximo):
        return Gtk.FlowBox(selection_mode=Gtk.SelectionMode.NONE, homogeneous=True, min_children_per_line=minimo,
                           max_children_per_line=maximo, column_spacing=6, row_spacing=6, valign=Gtk.Align.START)

    @staticmethod
    def _desplazable(hijo):
        desplazable = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        desplazable.set_child(hijo)
        return desplazable

    def _crear_versiculos(self):
        caja = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.lista = Gtk.ListBox(selection_mode=Gtk.SelectionMode.MULTIPLE, activate_on_single_click=False)
        self.lista.add_css_class("lista-versiculos")
        self.lista.connect("selected-rows-changed", lambda *_: self._seleccion_cambio())
        self.lista.connect("row-activated", lambda *_: self._agregar_seleccion())

        # Clic y arrastrar sobre versículos sin marcar = marcar un tramo.
        marcar = Gtk.GestureDrag(propagation_phase=Gtk.PropagationPhase.CAPTURE)
        marcar.connect("drag-begin", self._arrastre_inicio)
        marcar.connect("drag-update", self._arrastre_mueve)
        self.lista.add_controller(marcar)
        # Clic y arrastrar sobre versículos ya marcados = llevarlos al orden del culto.
        llevar = Gtk.DragSource(actions=Gdk.DragAction.COPY)
        llevar.connect("prepare", self._preparar_llevar)
        llevar.connect("drag-begin", self._icono_llevar)
        self.lista.add_controller(llevar)

        self.desplazable_versiculos = self._desplazable(self.lista)
        caja.append(self.desplazable_versiculos)

        barra = Gtk.Box(spacing=8)
        barra.add_css_class("barra-seleccion")
        textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True)
        self.referencia = Gtk.Label(xalign=0, ellipsize=3)
        self.referencia.add_css_class("heading")
        textos.append(self.referencia)
        ayuda = Gtk.Label(xalign=0, wrap=True, label=_("Arrastra hacia abajo para marcar. Arrastra lo marcado hacia "
                                                         "la derecha para llevarlo al orden del culto."))
        ayuda.add_css_class("dim-label")
        ayuda.add_css_class("caption")
        textos.append(ayuda)
        barra.append(textos)
        self.boton_agregar = Gtk.Button(valign=Gtk.Align.CENTER, tooltip_text=_("Agregar al orden del culto"))
        self.boton_agregar.set_child(Adw.ButtonContent(icon_name="list-add-symbolic", label=_("Al orden")))
        self.boton_agregar.add_css_class("suggested-action")
        self.boton_agregar.connect("clicked", lambda *_: self._agregar_seleccion())
        barra.append(self.boton_agregar)
        caja.append(barra)
        return caja

    # ------------------------------------------------------------ versiones

    @property
    def ver_a(self):
        lista = biblia.versiones()
        return biblia.version(self.ajustes["biblia_a"]) or (lista[0] if lista else None)

    @property
    def ver_b(self):
        segunda = biblia.version(self.ajustes["biblia_b"]) if self.ajustes["biblia_b"] else None
        return segunda if segunda and segunda is not self.ver_a else None

    def recargar(self):
        """Se llama al cambiar las Biblias en Preferencias."""
        if self.paginas.get_visible_child_name() == "versiculos":
            self._abrir_capitulo(self.numero_libro, self.capitulo)
        else:
            self._mostrar_libros(self.boton_nt.get_active())

    def _nombre_libro(self, numero):
        libro = self.ver_a.libro(numero) if self.ver_a else None
        return libro.nombre if libro else ""

    # ------------------------------------------------------------ navegación

    def _marcar_testamento(self, nuevo):
        (self.boton_nt if nuevo else self.boton_at).set_active(True)

    def _mostrar_libros(self, nuevo):
        self.libros.remove_all()
        for libro in self.ver_a.libros if self.ver_a else []:
            if (libro.numero > ULTIMO_LIBRO_AT) != nuevo:
                continue
            boton = Gtk.Button(label=libro.nombre)
            boton.add_css_class("boton-libro")
            boton.get_child().set_ellipsize(3)
            boton.connect("clicked", lambda _b, n=libro.numero: self._mostrar_capitulos(n))
            self.libros.append(boton)
        self.camino.set_label(_("Nuevo Testamento") if nuevo else _("Antiguo Testamento"))
        self.boton_volver.set_visible(False)
        self.paginas.set_visible_child_name("libros")

    def _mostrar_capitulos(self, numero_libro):
        self.numero_libro = numero_libro
        self.capitulos.remove_all()
        for numero in range(1, biblia.cantidad_capitulos(self.ver_a, numero_libro) + 1):
            boton = Gtk.Button(label=str(numero))
            boton.add_css_class("boton-capitulo")
            boton.connect("clicked", lambda _b, c=numero: self._abrir_capitulo(self.numero_libro, c))
            self.capitulos.append(boton)
        self.camino.set_label(self._nombre_libro(numero_libro))
        self.boton_volver.set_visible(True)
        self.paginas.set_visible_child_name("capitulos")

    def _abrir_capitulo(self, numero_libro, capitulo):
        if not self.ver_a:
            return
        cantidad = biblia.cantidad_capitulos(self.ver_a, numero_libro)
        if not cantidad:
            numero_libro, capitulo, cantidad = 43, 1, biblia.cantidad_capitulos(self.ver_a, 43)
        capitulo = min(max(capitulo, 1), cantidad)
        self.numero_libro, self.capitulo = numero_libro, capitulo
        self.ajustes["biblia_libro"] = numero_libro
        self.ajustes["biblia_capitulo"] = capitulo
        self._marcar_testamento(numero_libro > ULTIMO_LIBRO_AT)
        self._diapositivas = biblia.diapositivas_capitulo(self.ver_a, self.ver_b, numero_libro, capitulo)
        self.lista.remove_all()
        for diapositiva in self._diapositivas:
            self.lista.append(self._fila(diapositiva))
        self.camino.set_label(f"{self._nombre_libro(numero_libro)} {capitulo}")
        self.boton_volver.set_visible(True)
        self.paginas.set_visible_child_name("versiculos")
        self.desplazable_versiculos.get_vadjustment().set_value(0)
        self._seleccion_cambio()

    def _volver(self):
        if self.paginas.get_visible_child_name() == "versiculos":
            self._mostrar_capitulos(self.numero_libro)
        else:
            self._mostrar_libros(self.numero_libro > ULTIMO_LIBRO_AT)

    def _fila(self, diapositiva):
        fila = Gtk.ListBoxRow()
        fila.numero = int(diapositiva.etiqueta.split()[-1])
        caja = Gtk.Box(spacing=8)
        caja.add_css_class("fila-versiculo")
        numero = Gtk.Label(label=str(fila.numero), yalign=0, width_chars=3, xalign=1)
        numero.add_css_class("numero-versiculo")
        caja.append(numero)
        textos = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, hexpand=True)
        texto = Gtk.Label(label=diapositiva.texto, xalign=0, wrap=True)
        texto.set_wrap_mode(2)
        textos.append(texto)
        if diapositiva.texto2:
            segundo = Gtk.Label(label=diapositiva.texto2, xalign=0, wrap=True)
            segundo.set_wrap_mode(2)
            segundo.add_css_class("dim-label")
            segundo.add_css_class("caption")
            textos.append(segundo)
        caja.append(textos)
        fila.set_child(caja)
        return fila

    # ------------------------------------------------------------ marcar arrastrando

    def _arrastre_inicio(self, _gesto, _x, y):
        # Todavía no se sabe qué quiere hacer: se decide con la dirección del arrastre.
        self._fila_inicio = self.lista.get_row_at_y(int(y))
        self._modo_arrastre = None

    def _arrastre_mueve(self, gesto, dx, dy):
        if self._fila_inicio is None:
            return
        if self._modo_arrastre is None:
            if max(abs(dx), abs(dy)) < 5:
                return
            if abs(dx) > abs(dy) and self._fila_inicio.is_selected():
                # Hacia el costado sobre lo marcado: llevarlo al orden (lo hace el Gtk.DragSource).
                self._modo_arrastre = "llevar"
                return
            # Hacia arriba o abajo: un tramo nuevo desde donde empezó, aunque ya estuviera marcado.
            self._modo_arrastre = "marcar"
            self._ancla = self._fila_inicio.get_index()
        if self._modo_arrastre != "marcar":
            return
        gesto.set_state(Gtk.EventSequenceState.CLAIMED)
        _ok, _x0, y0 = gesto.get_start_point()
        self.marcar_hasta_y(y0 + dy)

    def marcar_hasta_y(self, y):
        fila = self.lista.get_row_at_y(int(y))
        if fila is None:
            fila = self.lista.get_row_at_index(len(self._diapositivas) - 1 if y > 0 else 0)
        if fila is None or self._ancla is None:
            return
        desde, hasta = sorted((self._ancla, fila.get_index()))
        self.lista.unselect_all()
        for i in range(desde, hasta + 1):
            self.lista.select_row(self.lista.get_row_at_index(i))
        # Si se llega al borde, la lista se desplaza sola.
        ajuste = self.desplazable_versiculos.get_vadjustment()
        if y > ajuste.get_value() + ajuste.get_page_size() - 40:
            ajuste.set_value(ajuste.get_value() + 24)
        elif y < ajuste.get_value() + 40:
            ajuste.set_value(ajuste.get_value() - 24)

    def _preparar_llevar(self, _fuente, _x, _y):
        if self._modo_arrastre != "llevar" or not self.lista.get_selected_rows():
            return None
        return Gdk.ContentProvider.new_for_value(CONTENIDO_PASAJE)

    def _icono_llevar(self, fuente, _arrastre):
        fuente.set_icon(Gtk.WidgetPaintable.new(self.referencia), 0, 0)

    # ------------------------------------------------------------ selección

    def seleccion(self):
        """(cita, diapositivas) de lo marcado, o None."""
        filas = sorted(self.lista.get_selected_rows(), key=lambda f: f.get_index())
        if not filas:
            return None
        diapositivas = [self._diapositivas[f.get_index()] for f in filas]
        cita = f"{self._nombre_libro(self.numero_libro)} {self.capitulo}:{biblia.rangos([f.numero for f in filas])}"
        return cita, diapositivas

    def _seleccion_cambio(self):
        actual = self.seleccion()
        self.referencia.set_label(actual[0] if actual else _("Marca los versículos"))
        self.boton_agregar.set_sensitive(actual is not None)

    def _agregar_seleccion(self):
        actual = self.seleccion()
        if actual:
            self.emit("agregar", *actual)

    # ------------------------------------------------------------ cita rápida

    def _ir_a_cita(self, *_):
        cita = biblia.leer_cita(self.cita.get_text())
        if not cita or not self.ver_a or not self.ver_a.libro(cita[0]):
            self.aviso.set_label(_("No entendí la cita. Prueba así: Juan 3:16, Salmos 23 o 1 Corintios 13:4-7."))
            self.aviso.set_visible(True)
            return
        self.aviso.set_visible(False)
        numero_libro, capitulo, desde, hasta = cita
        self._abrir_capitulo(numero_libro, capitulo)
        if not desde:
            return
        primera = None
        for fila in self._filas():
            if desde <= fila.numero <= (hasta or desde):
                self.lista.select_row(fila)
                primera = primera or fila
        if primera is not None:
            GLib.idle_add(lambda: primera.grab_focus() and False)

    def _filas(self):
        fila = self.lista.get_first_child()
        while fila is not None:
            if isinstance(fila, Gtk.ListBoxRow):
                yield fila
            fila = fila.get_next_sibling()

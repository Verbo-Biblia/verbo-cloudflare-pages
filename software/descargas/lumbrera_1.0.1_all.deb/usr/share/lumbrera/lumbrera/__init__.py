"""Lumbrera: proyector de letras y pasajes bíblicos para la iglesia."""

NOMBRE = "Lumbrera"
VERSION = "1.0.1"
ID_APP = "com.verbobiblia.Lumbrera"
